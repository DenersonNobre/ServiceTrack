# dnolib

Único pacote Pub exposto. A facade `dnolib.dart` exporta todos os módulos
(`core`, `rest`, `sqlite`, `widgets`, `brlib`, `synapx`) e o consumidor controla a
visibilidade com `show`/`hide` no próprio import, conforme a conveniência do
app.

## Objetivo

A `dnolib` serve como infraestrutura reutilizável para projetos de software, sem saber nada sobre o domínio do aplicativo.

## APIs públicas

Importe a facade completa:

```dart
import 'package:dnolib/dnolib.dart';
```

Ou recorte o que o app usa com `show`/`hide` (o padrão recomendado quando o
app quer só parte da inteligência da lib):

```dart
import 'package:dnolib/dnolib.dart' show CpfValidator, Money, RestClient;
import 'package:dnolib/dnolib.dart' hide Money, MoneyCurrencyMismatch;
```

Também é possível importar a biblioteca de um módulo diretamente:

```dart
import 'package:dnolib/core/core.dart';
import 'package:dnolib/brlib/brlib.dart';
```

Esses arquivos são barrels públicos independentes dentro do pacote
`dnolib`; não são pacotes Pub separados. `dnolib` é o único pacote
Publicável/exposto.

Ela deve fornecer:

- utilitários e padrões gerais
- abstrações para REST
- persistência SQLite
- widgets reutilizáveis
- contratos e convenções de desenvolvimento

## Estrutura

```text
dnolib/
  lib/
    dnolib.dart
    brlib/
      brlib.dart
      src/
        formatters/
          cpf_formatter.dart
          cnpj_formatter.dart
          cep_formatter.dart
          phone_br_formatter.dart
          mask_utils.dart
        input_formatters/
          digit_mask_input_formatter.dart
          cpf_input_formatter.dart
          cnpj_input_formatter.dart
          cep_input_formatter.dart
          phone_br_input_formatter.dart
          date_input_formatter.dart
          money_input_formatter.dart
          number_input_formatter.dart
          currency_input_formatter.dart
        validators/
          cpf_validator.dart
          cnpj_validator.dart
          cep_validator.dart
          uf_validator.dart
          phone_br_validator.dart
          validator_utils.dart
    core/
      core.dart
      models/
        mappable.dart
        money.dart
      patterns/
        command.dart
        observable.dart
      validator/
        date.dart
        email.dart
        password.dart
    rest/
      rest.dart
    sqlite/
      sqlite.dart
    synapx/
      synapx.dart
    widgets/
      widgets.dart
  test/
    brlib/
    core/
    rest/
    sqlite/
    synapx/
    widgets/
```

## Regras

- agnóstica ao domínio do projeto
- sem acoplamento a regras específicas do app
- sem estado de negócio embutido
- app define estado, navegação e regras de negócio
- módulos mantêm bibliotecas públicas próprias; implementações ficam sob `lib/`
- `core` permanece sem dependência de Flutter e de regras do app
- textos, identidade visual, schemas e copy pertencem ao consumidor

## Módulos

- `core`: utilitários, contracts, validators, patterns e tipos base — Dart puro,
  sem Flutter. Inclui `Observable` (GoF Observer com valor corrente), `Command`,
  validators genéricos (`ValidEmail`, `ValidPassword` + `PasswordPolicy`,
  `ValidDate`/`ValidDateTime`) e o value object `Money` (BigInt, moeda e
  escala explícitos, parsing por separadores informados, sem locale nem
  símbolo monetário).
- `rest`: cliente HTTP, retry, timeout e abstrações de transporte
- `sqlite`: provider, migrations, repository e transações
- `widgets`: componentes visuais reutilizáveis e neutros, e o adaptador
  `ObservableAdapter` que expõe um `Observable` do core como `ValueListenable`
- `brlib`: convenções brasileiras (CPF, CNPJ, CEP, UF, telefone) — validadores,
  funções puras de formatação e `TextInputFormatter`s
- `synapx`: reatividade estendida (`SynapxList`, `SynapxMap`, workers
  `SynapxEffect.ever`/`once`/`debounce`/`interval`, `SynapxTracker` por `Zone`,
  `SynapxScope`), ciclo de vida determinístico (`SynapxDisposable`,
  `SynapxCompositeDisposable`, `SynapxModuleScope`, `SynapxProvider`,
  `SynapxRouteObserver`) e adapter modular de rotas com guards assíncronos
  (`SynapxRouteGuardRunner`, `SynapxRouteScope`)

Não existe `presentation`: `Command` é um padrão neutro de orquestração e mora em
`core`. O que depende de Flutter para observar o `Command` — `ValueListenable`,
`AsyncButton`, `NotifierBuilder` — vive em `widgets`, que é a camada legítima
para acoplar ao framework.

## Módulo regional (`brlib`)

`lib/brlib` concentra o regional brasileiro: valida CPF, CNPJ, CEP, UF e
telefone e oferece funções para formatar valores completos mais os
`TextInputFormatter`s. O validador de CNPJ suporta identificadores
alfanuméricos conforme o cálculo de dígito verificador publicado pela
[Receita Federal](https://www.gov.br/receitafederal/pt-br/centrais-de-conteudo/publicacoes/documentos-tecnicos/cnpj).
Ele é exportado pela facade como os demais módulos; apps que não precisam do
regional cortam com `show`/`hide`.

Histórico: os pacotes Pub independentes (`packages/dnolib_br`,
`packages/dnolib_br_flutter`, `packages/dnolib_money`) foram fundidos nestes
módulos e o diretório `packages/` foi removido; `Money` foi fundido em
`core/models/money.dart` (módulo de arquivo único não justifica residência
própria).

## Dependências

O pacote completo depende de Flutter, `http` e `sqflite`. Projetos que
importarem `core.dart` consomem APIs sem dependência de Flutter no código da
biblioteca; porém a resolução Pub do pacote único `dnolib` ainda inclui as
dependências de Flutter e dos outros módulos.
