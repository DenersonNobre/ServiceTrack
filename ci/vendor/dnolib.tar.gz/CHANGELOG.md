# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [Não publicado]

> Note: breaking change no módulo `synapx` — identificadores públicos renomeados
> para o prefixo `Synapx` (extensions com sufixo `Extension`), **sem aliases** de
> compatibilidade.

- **BREAKING**(synapx): identidade canônica dos componentes:
  - `SynapxList`/`SynapxMap` (antes `RxList`/`RxMap`), `SynapxComputed`/`synapxComputed` (antes `Computed`/`computed`), `SynapxTracker`, `SynapxCallback`.
  - Workers migrados para a fachada estática `SynapxEffect.ever/once/debounce/interval` (antes funções top-level `ever`/`once`/`debounceRx`/`intervalRx`).
  - Ciclo de vida: `SynapxDisposable`/`SynapxCompositeDisposable`; DI: `SynapxModuleScope`, `SynapxBinder`, `SynapxProvider`, `SynapxRouteObserver`, `SynapxRouteScope`.
  - Guards: `SynapxRouteContext`, `SynapxRouteGuard`, `SynapxGuardResult/Allow/Reject/Redirect`, `SynapxRouteGuardRunner`.
  - Extensions: `SynapxContextExtension`/`SynapxDialogsExtension` (antes `SynapxContextX`/`SynapxDialogsX`).
- **TEST**(synapx): gates mecânicos de identidade (prefixo `Synapx` em declaração pública) e de ausência de legado, ambos com prova negativa.
- **FEAT**(synapx): ergonomia E1–E3:
  - Coleções: `SynapxList.assign` e `SynapxMap.assign` (substituição atômica em uma única notificação, com snapshot seguro para auto-atribuição).
  - Controller: helpers rastreados `obs`, `list`, `map`, `derived`, `onEver`, `onOnce`, `debounce`, `interval`, além de `isActive` e `runIfActive`.
  - UI reativa: `SynapxObserver<T>` (assinatura explícita sem `Zone`), `SynapxReactivePage<T>` (`buildReactive` sob `SynapxScope`) e `SynapxApp.appBuilder` (`SynapxObserverAppBuilder`, sem placeholders de escopo).
- **BREAKING**(widgets): consolidação semântica, renomeações e remoção de duplicidades (mantendo `widgets` independente de `synapx`):
  - `ObservableListenable` renomeado para `ObservableAdapter` (arquivo `observable_adapter.dart`), com extensões unificadas em `ObservableAdapterExtension` (`asListenable`/`watch`, convenção `*Extension`).
  - `SearchPanel` unifica `DebouncedSearch` + `SearchPanel` (suporte opcional a `Debouncer`, `icon` e `action`).
  - `SectionTitle` (absorvendo `TitleBar`) e `TitlePanel` + `TitlePanel.text` (absorvendo `TitlePage`) consolidados em `titles.dart`.
  - `DetailItem` + `DetailItem.keyValue` substituem `DetailLine`, `DetailColumn` e `KeyValueText`.
  - `ModalHeader` e `ModalSheet` substituem `TitleModal`; removidos `NoRecordMessage`, `ModalDialog` e `RefreshView` (wrapper fino de `RefreshIndicator`); `dialogs.dart` renomeado para `modals.dart`.
- **DOCS**: `README.md`, `example/README.md`, `LEARNINGS.md` e plano de ergonomia/identidade atualizados; `example/` migrado para os nomes canônicos e APIs E1–E3.

## 0.7.0 — 2026-11-18

> Note: minor bump — novo módulo `synapx` integrado à facade e utilitários
> adicionais em `core`/`brlib`/`widgets`, sem breaking changes.

- **FEAT**(synapx): módulo `lib/synapx` integrado à facade `dnolib.dart` (`0.1a`–`0.2`):
  - Reatividade: `RxList`, `RxMap` (com `batch`), workers puros (`ever`, `once`, `debounceRx`, `intervalRx`), `RxTracker` por `Zone` e `SynapxScope`, além de `ObservableToken.onCancel` e isolamento de erro em `Observable._notify`.
  - Ciclo de vida: `Disposable`, `CompositeDisposable`, `ModuleScope` hierárquico com qualificador `(Type, name?)` e ownership explícito, `ScopeWidget` e `ScopeRouteObserver`.
  - Roteamento modular: `RouteContext`, `GuardResult`, `RouteGuardRunner` (timeout, cancelamento por geração e detecção de loop `A → B → A`) e adapter `ScopeRouteBuilder`.
- **DOCS**: documentação conceitual, plano de implementação, `README.md`, `HANDOFF.md` e `LEARNINGS.md` atualizados (`413` testes verdes).

## 0.6.0 — 2026-10-14

> Note: minor bump — new backward-compatible feature, no breaking changes.

- **FEAT**(brlib): `Document` promovido do `.modelo` (Jornada A) — extension type
  de custo zero unindo validadores e formatters de CPF/CNPJ (parse normalizador,
  `isValid`/`isCpf`/`isCnpj`, `formatted`).

## 0.5.0 — 2026-10-14

> Note: minor bump — new backward-compatible features (`FailureCode` taxonomy
> now emitted by `restFailure`), no breaking changes.

- **FEAT**(rest): `restFailure` emite subtipo `FailureCode` por status HTTP
  (401→`Unauthorized`, 404→`NotFound`, 409→`Conflict`).
- **FEAT**(core): introduz `FailureCode` e `UnexpectedFailure` tipado, sem strings mágicas.
- **FIX**(rest): `ClientStack` com ordem canônica fixa de composição.
- **FIX**(rest): `RetryClient` não retenta `CircuitOpenException` — o backoff consumia o fast-fail do circuito.
- **DOCS**: handoff e aprendizados da sessão; corrige teste flaky de log.
- **DOCS**: alinha baseline de testes e reescreve o CHANGELOG.
- **DOCS**: renomeia `Docs/` para `docs/` conforme convenção de pastas.
- **DOCS**: registra estado da wiki no Gitea.
- **DOCS**: análise de gaps em `docs/analise-2026-10-13.md`.

## 0.4.1 — 2026-10-11

- **FIX**(rest): respeita o charset do `Content-Type` ao decodificar o corpo, com fallback
  para UTF-8 quando ausente ou desconhecido. Corrige quebra em API legada `iso-8859-1`.

## 0.4.0 — 2026-10-11

> Note: This release has breaking changes.

- **BREAKING** **FEAT**(adapters): datasource CRUD devolve `IResult` em vez de `Future` crua.
- **BREAKING** **REFACTOR**(core): `UserSessionData` com identificadores em inglês.
- **FEAT**(rest): `RestClient` com timeout configurável e causa tipada.
- **FEAT**(rest): `AuthClient` injeta Bearer token por requisição.
- **FEAT**(rest): suporte a PATCH (atualização parcial).
- **FIX**(core): valida email com plus-addressing e TLD longo.
- **FIX**(core): `PasswordPolicy` aceita qualquer não-alfanumérico como símbolo.
- **FIX**(core): `UserSession.isAuthenticated` checa `expiraEm`.
- **FIX**(example): `Customer` usa `IMappable` em vez de `Mappable`.
