library;

/// Módulo Synapx: reatividade, ciclo de vida, roteamento modular e widgets
/// declarativos integrados à facade única da `dnolib`.

export 'src/lifecycle/synapx_lifecycle.dart';
export 'src/reactive/synapx_reactive.dart';
export 'src/routing/synapx_routing.dart';
export 'src/widgets/synapx_widgets.dart';
