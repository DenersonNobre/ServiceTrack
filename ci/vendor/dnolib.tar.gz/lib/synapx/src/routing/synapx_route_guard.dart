// Contratos e executor de guards assíncronos de rota (slice 0.2, Green).
//
// Suporta execução sequencial, timeout configurável, isolamento de exceções,
// cancelamento por geração (concorrência / pop durante await) e detecção de
// loop de redirect (A -> B -> A).
//
// Dependências: [SynapxModuleScope] (synapx) e SDK (`dart:async`).

import 'dart:async';

import 'package:dnolib/synapx/src/lifecycle/synapx_lifecycle.dart';

/// Contexto imutável entregue aos [SynapxRouteGuard]s durante a avaliação da rota.
class SynapxRouteContext {
  const SynapxRouteContext({
    required this.uri,
    this.pathParameters = const {},
    this.queryParameters = const {},
    this.extra,
    this.scope,
  });

  final Uri uri;
  final Map<String, String> pathParameters;
  final Map<String, String> queryParameters;
  final Object? extra;
  final SynapxModuleScope? scope;

  /// Cria uma cópia deste contexto apontando para [uri] com [scope] opcional.
  SynapxRouteContext copyWith({Uri? uri, SynapxModuleScope? scope}) {
    return SynapxRouteContext(
      uri: uri ?? this.uri,
      pathParameters: pathParameters,
      queryParameters: queryParameters,
      extra: extra,
      scope: scope ?? this.scope,
    );
  }
}

/// Resultado da avaliação de um [SynapxRouteGuard].
sealed class SynapxGuardResult {
  const SynapxGuardResult();
}

/// Autoriza a ativação da rota.
final class SynapxGuardAllow extends SynapxGuardResult {
  const SynapxGuardAllow();
}

/// Nega a ativação da rota com [reason] opcional.
final class SynapxGuardReject extends SynapxGuardResult {
  const SynapxGuardReject([this.reason]);
  final String? reason;
}

/// Redireciona a navegação para [target].
final class SynapxGuardRedirect extends SynapxGuardResult {
  const SynapxGuardRedirect(this.target);
  final Uri target;
}

/// Contrato de interceptação assíncrona pré-ativação de rota.
abstract interface class SynapxRouteGuard {
  Future<SynapxGuardResult> canActivate(SynapxRouteContext context);
}

/// Executor sequencial de [SynapxRouteGuard]s com timeout, cancelamento seguro por
/// geração e detecção de loop de redirect.
class SynapxRouteGuardRunner {
  SynapxRouteGuardRunner({this.timeout, this.maxRedirects = 5});

  /// Tempo máximo por guard individual; `null` desabilita timeout.
  final Duration? timeout;

  /// Limite máximo de redirecionamentos encadeados em [resolveRedirectChain].
  final int maxRedirects;

  int _generation = 0;

  /// Cancela qualquer avaliação em voo (ex.: `pop` durante `await`).
  void cancel() => _generation++;

  /// Avalia [guards] sequencialmente para [context].
  ///
  /// Execuções sobrepostas por nova chamada a [evaluate] ou por [cancel]
  /// retornam `SynapxGuardReject('cancelled')`. Exceções e timeouts retornam
  /// [SynapxGuardReject] sem propagar falha não tratada.
  Future<SynapxGuardResult> evaluate(
    SynapxRouteContext context,
    List<SynapxRouteGuard> guards,
  ) async {
    final generation = ++_generation;

    for (final guard in guards) {
      if (generation != _generation) {
        return const SynapxGuardReject('cancelled');
      }
      final result = await _runSingle(guard, context);
      if (generation != _generation) {
        return const SynapxGuardReject('cancelled');
      }
      if (result is! SynapxGuardAllow) {
        return result;
      }
    }

    return const SynapxGuardAllow();
  }

  /// Resolve uma cadeia de redirecionamentos seguindo `SynapxGuardRedirect`s e
  /// interrompendo loops (`A -> B -> A`) ou excesso de saltos.
  Future<SynapxGuardResult> resolveRedirectChain({
    required SynapxRouteContext initialContext,
    required List<SynapxRouteGuard> Function(Uri uri) guardsForUri,
  }) async {
    final visited = <Uri>{initialContext.uri};
    var currentContext = initialContext;

    for (var hop = 0; hop <= maxRedirects; hop++) {
      final result = await evaluate(
        currentContext,
        guardsForUri(currentContext.uri),
      );
      if (result is! SynapxGuardRedirect) {
        return result;
      }
      if (!visited.add(result.target)) {
        return SynapxGuardReject('redirect_loop: ${result.target}');
      }
      currentContext = currentContext.copyWith(uri: result.target);
    }

    return SynapxGuardReject(
      'redirect_loop: maxRedirects ($maxRedirects) excedido',
    );
  }

  Future<SynapxGuardResult> _runSingle(
    SynapxRouteGuard guard,
    SynapxRouteContext context,
  ) async {
    try {
      final future = guard.canActivate(context);
      final limit = timeout;
      if (limit != null) {
        return await future.timeout(limit);
      }
      return await future;
    } on TimeoutException {
      return const SynapxGuardReject('timeout');
    } catch (error) {
      return SynapxGuardReject('error: $error');
    }
  }
}
