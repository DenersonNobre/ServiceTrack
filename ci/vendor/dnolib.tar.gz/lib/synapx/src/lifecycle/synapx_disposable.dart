// Contratos de descarte determinístico do Synapx (slice 0.1c, Green).
//
// Dependências: [ObservableToken] (core) e SDK (`dart:async`).

import 'dart:async';

import 'package:dnolib/core/core.dart';

/// Contrato para objetos que retêm recursos descartáveis (timers, tokens,
/// controladores).
abstract interface class SynapxDisposable {
  void dispose();
}

/// Agrupa [SynapxDisposable]s, [ObservableToken]s, [Timer]s e callbacks para descarte
/// atômico, idempotente e em ordem reversa de registro.
class SynapxCompositeDisposable implements SynapxDisposable {
  final List<void Function()> _callbacks = [];
  bool _disposed = false;

  /// `true` após [dispose] ter sido chamado.
  bool get isDisposed => _disposed;

  /// Registra um [SynapxDisposable] para descarte.
  void add(SynapxDisposable disposable) => addCallback(disposable.dispose);

  /// Registra um [ObservableToken] para cancelamento.
  void addToken(ObservableToken<dynamic> token) => addCallback(token.cancel);

  /// Registra um [Timer] para cancelamento.
  void addTimer(Timer timer) => addCallback(timer.cancel);

  /// Registra uma função de limpeza arbitrária.
  ///
  /// Se o composto já estiver descartado, [callback] é executado imediatamente.
  void addCallback(void Function() callback) {
    if (_disposed) {
      _safeRun(callback);
      return;
    }
    _callbacks.add(callback);
  }

  @override
  void dispose() {
    if (_disposed) {
      return;
    }
    _disposed = true;
    final pending = _callbacks.reversed.toList();
    _callbacks.clear();
    for (final callback in pending) {
      _safeRun(callback);
    }
  }

  void _safeRun(void Function() callback) {
    try {
      callback();
    } catch (error, stackTrace) {
      Zone.current.handleUncaughtError(error, stackTrace);
    }
  }
}
