// Controller base opcional do Synapx (Dart puro, sem dependência de Flutter).
//
// Elimina o boilerplate de [SynapxCompositeDisposable], guarda `isDisposed` e
// descarte manual de [Observable]s, [ObservableToken]s, [Command]s e [Timer]s,
// integrando-se automaticamente ao `SynapxModuleScope` via [SynapxDisposable].
//
// Dependências: [Command], [Observable], [ObservableToken] (core),
// [SynapxDisposable], [SynapxCompositeDisposable] (synapx) e SDK (`dart:async`).

import 'dart:async';

import 'package:dnolib/core/core.dart';
import 'package:dnolib/synapx/src/lifecycle/synapx_disposable.dart';
import 'package:dnolib/synapx/src/reactive/synapx_reactive.dart';

/// Base opcional para controllers do Synapx com gerenciamento automático de
/// ciclo de vida via [SynapxCompositeDisposable].
abstract class SynapxController implements SynapxDisposable {
  final SynapxCompositeDisposable _disposables = SynapxCompositeDisposable();
  bool _disposed = false;

  /// `true` após [dispose] ter sido executado.
  bool get isDisposed => _disposed;

  /// `true` enquanto o controller ainda não foi descartado.
  bool get isActive => !_disposed;

  /// Cria um [Observable] com [initial], registra para descarte e o devolve.
  Observable<T> obs<T>(T initial) => trackObservable(Observable<T>(initial));

  /// Cria um [SynapxList], registra para descarte e a devolve.
  SynapxList<E> list<E>([Iterable<E>? initial]) => trackObservable(
    SynapxList<E>(initial == null ? null : List<E>.of(initial)),
  );

  /// Cria um [SynapxMap], registra para descarte e o devolve.
  SynapxMap<K, V> map<K, V>([Map<K, V>? initial]) =>
      trackObservable(SynapxMap<K, V>(initial));

  /// Cria um [SynapxComputed], registra para descarte e o devolve.
  SynapxComputed<T> derived<T>(T Function() compute) =>
      trackObservable(synapxComputed<T>(compute));

  /// Registra worker [SynapxEffect.ever] vinculado ao ciclo do controller.
  ObservableToken<T> onEver<T>(
    Observable<T> observable,
    SynapxCallback<T> callback,
  ) => trackToken(SynapxEffect.ever<T>(observable, callback));

  /// Registra worker [SynapxEffect.once] vinculado ao ciclo do controller.
  ObservableToken<T> onOnce<T>(
    Observable<T> observable,
    SynapxCallback<T> callback,
  ) => trackToken(SynapxEffect.once<T>(observable, callback));

  /// Registra worker [SynapxEffect.debounce] vinculado ao ciclo do controller.
  ObservableToken<T> debounce<T>(
    Observable<T> observable,
    SynapxCallback<T> callback, {
    required Duration duration,
  }) => trackToken(
    SynapxEffect.debounce<T>(observable, callback, duration: duration),
  );

  /// Registra worker [SynapxEffect.interval] vinculado ao ciclo do controller.
  ObservableToken<T> interval<T>(
    Observable<T> observable,
    SynapxCallback<T> callback, {
    required Duration duration,
  }) => trackToken(
    SynapxEffect.interval<T>(observable, callback, duration: duration),
  );

  /// Executa [action] se o controller ainda estiver ativo e descarta o retorno
  /// caso seja descartado durante a espera. Não cancela `await` já em curso.
  Future<T?> runIfActive<T>(Future<T> Function() action) async {
    if (_disposed) {
      return null;
    }
    final result = await action();
    if (_disposed) {
      return null;
    }
    return result;
  }

  /// Registra um [SynapxDisposable] para descarte automático e o devolve.
  T autoDispose<T extends SynapxDisposable>(T resource) {
    _disposables.add(resource);
    return resource;
  }

  /// Registra um [Observable] (ou `SynapxList`/`SynapxMap`) para descarte e o devolve.
  O trackObservable<O extends Observable<dynamic>>(O observable) {
    _disposables.addCallback(observable.dispose);
    return observable;
  }

  /// Registra um [ObservableToken] para cancelamento e o devolve.
  ObservableToken<T> trackToken<T>(ObservableToken<T> token) {
    _disposables.addToken(token);
    return token;
  }

  /// Registra um [Command] para descarte automático e o devolve.
  Command<TSuccess, TFailure, TParam> trackCommand<TSuccess, TFailure, TParam>(
    Command<TSuccess, TFailure, TParam> command,
  ) {
    _disposables.addCallback(command.dispose);
    return command;
  }

  /// Registra um [Timer] para cancelamento automático e o devolve.
  Timer trackTimer(Timer timer) {
    _disposables.addTimer(timer);
    return timer;
  }

  /// Registra um callback arbitrário de limpeza (ex.: `TextEditingController.dispose`).
  void onDispose(void Function() callback) =>
      _disposables.addCallback(callback);

  /// Gancho opcional executado uma única vez quando [dispose] é chamado,
  /// antes do descarte em cascata dos recursos rastreados.
  void onClose() {}

  @override
  void dispose() {
    if (_disposed) {
      return;
    }
    _disposed = true;
    try {
      onClose();
    } catch (error, stackTrace) {
      Zone.current.handleUncaughtError(error, stackTrace);
    } finally {
      _disposables.dispose();
    }
  }
}
