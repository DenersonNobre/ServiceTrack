// Contêiner de escopo hierárquico do Synapx (slice 0.1c, Green).
//
// Chave composta `(Type, String?)`, reuso de [LazyProxy] sem materializar no
// `dispose()`, e controle explícito de ownership (`owned: false` por padrão em
// [registerInstance]). O descarte do filho nunca afeta o escopo [parent].
//
// Dependências: [LazyProxy] (core), [SynapxDisposable] (synapx) e SDK (`dart:async`).

import 'dart:async';

import 'package:dnolib/core/core.dart';
import 'package:dnolib/synapx/src/lifecycle/synapx_disposable.dart';
import 'package:dnolib/synapx/src/lifecycle/synapx_module.dart';

typedef _SynapxScopeKey = (Type, String?);

/// Registro declarativo de dependências em um [SynapxModuleScope]: atalho usado por
/// `SynapxRouteScope.bind`, `SynapxApp.bind` e `SynapxTestScope.overrides`.
typedef SynapxBinder = void Function(SynapxModuleScope scope);

/// Escopo isolado e hierárquico de dependências vinculado ao ciclo de vida.
class SynapxModuleScope implements SynapxDisposable {
  SynapxModuleScope({this.parent});

  /// Escopo ancestral consultado quando um registro não existe localmente.
  final SynapxModuleScope? parent;

  final Map<_SynapxScopeKey, Object? Function(SynapxModuleScope scope)>
  _bindings = {};
  final List<void Function()> _ownedDisposers = [];
  bool _disposed = false;

  /// `true` após [dispose] ter sido executado.
  bool get isDisposed => _disposed;

  /// Aplica recursivamente os `imports` e `binds` de [module] neste escopo,
  /// ignorando módulos repetidos ou cíclicos já visitados nesta aplicação.
  void applyModule(SynapxModule module, {Set<Type>? visited}) {
    _ensureActive();
    final seen = visited ?? <Type>{};
    if (!seen.add(module.runtimeType)) {
      return;
    }
    for (final imported in module.imports) {
      applyModule(imported, visited: seen);
    }
    module.binds(this);
  }

  /// Registra uma factory que cria nova instância a cada [get].
  void registerFactory<T>(
    T Function(SynapxModuleScope scope) factory, {
    String? name,
  }) {
    _ensureActive();
    _bindings[(T, name)] = factory;
  }

  /// Registra um singleton preguiçoso materializado no primeiro [get].
  ///
  /// Se nunca for acessado antes de [dispose], não é instanciado.
  void registerLazySingleton<T>(
    T Function(SynapxModuleScope scope) factory, {
    String? name,
  }) {
    _ensureActive();
    var materialized = false;
    final proxy = LazyProxy<T>(() {
      materialized = true;
      return factory(this);
    });
    _bindings[(T, name)] = (_) => proxy.instancia;
    _ownedDisposers.add(() {
      if (!materialized) {
        return;
      }
      final instance = proxy.instancia;
      if (instance is SynapxDisposable) {
        instance.dispose();
      }
    });
  }

  /// Registra uma instância pronta.
  ///
  /// Por padrão [owned] é `false` (não é descartada pelo escopo).
  void registerInstance<T>(T instance, {String? name, bool owned = false}) {
    _ensureActive();
    _bindings[(T, name)] = (_) => instance;
    if (owned && instance is SynapxDisposable) {
      _ownedDisposers.add(instance.dispose);
    }
  }

  /// Resolve [T] (opcionalmente qualificado por [name]) neste escopo ou em
  /// seus ancestrais. Lança [StateError] se não houver registro.
  T get<T>({String? name}) {
    _ensureActive();
    final resolver = _bindings[(T, name)];
    if (resolver != null) {
      return resolver(this) as T;
    }
    if (parent != null) {
      return parent!.get<T>(name: name);
    }
    throw StateError('Nenhum registro encontrado para ($T, $name).');
  }

  /// Resolve [T] se registrado neste escopo ou em ancestrais; caso contrário
  /// devolve `null`.
  T? tryGet<T>({String? name}) {
    _ensureActive();
    final resolver = _bindings[(T, name)];
    if (resolver != null) {
      return resolver(this) as T;
    }
    return parent?.tryGet<T>(name: name);
  }

  @override
  void dispose() {
    if (_disposed) {
      return;
    }
    _disposed = true;
    final disposers = _ownedDisposers.reversed.toList();
    _ownedDisposers.clear();
    _bindings.clear();
    for (final disposer in disposers) {
      try {
        disposer();
      } catch (error, stackTrace) {
        Zone.current.handleUncaughtError(error, stackTrace);
      }
    }
  }

  void _ensureActive() {
    if (_disposed) {
      throw StateError('SynapxModuleScope já foi descartado.');
    }
  }
}
