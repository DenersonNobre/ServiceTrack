// Módulo declarativo do Synapx (inspirado no Flutter Modular, Dart puro).
//
// Dependências: [SynapxModuleScope] (synapx).

import 'package:dnolib/synapx/src/lifecycle/synapx_module_scope.dart';

/// Unidade declarativa de bindings e composição de submódulos do Synapx.
abstract class SynapxModule {
  const SynapxModule();

  /// Módulos importados e aplicados antes dos bindings locais deste módulo.
  List<SynapxModule> get imports => const [];

  /// Registra as dependências deste módulo em [scope].
  void binds(SynapxModuleScope scope);
}
