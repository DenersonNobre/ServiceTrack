// Harness isolado de testes do Synapx (Pilar IV, Dart puro).
//
// Permite instanciar um [SynapxModule] isoladamente e sobrescrever apenas as
// dependências necessárias para o teste, sem estado global e com descarte
// determinístico ao final.
//
// Dependências: [SynapxDisposable], [SynapxModuleScope], [SynapxModule] (synapx).

import 'package:dnolib/synapx/src/lifecycle/synapx_disposable.dart';
import 'package:dnolib/synapx/src/lifecycle/synapx_module.dart';
import 'package:dnolib/synapx/src/lifecycle/synapx_module_scope.dart';

/// Escopo isolado para testes unitários e de widget com overrides declarativos.
class SynapxTestScope implements SynapxDisposable {
  SynapxTestScope({
    SynapxModule? module,
    SynapxModuleScope? parent,
    SynapxBinder? overrides,
  }) : scope = SynapxModuleScope(parent: parent) {
    if (module != null) {
      scope.applyModule(module);
    }
    overrides?.call(scope);
  }

  /// [SynapxModuleScope] subjacente (pode ser entregue a `SynapxProvider.value`).
  final SynapxModuleScope scope;

  /// Resolve [T] no escopo de teste.
  T get<T>({String? name}) => scope.get<T>(name: name);

  /// Resolve [T] no escopo de teste ou devolve `null`.
  T? tryGet<T>({String? name}) => scope.tryGet<T>(name: name);

  @override
  void dispose() => scope.dispose();
}
