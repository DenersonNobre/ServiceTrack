// Widget observador do Synapx (slice 0.1b, Green): rastreia os [Observable]s
// lidos durante o `build` via [SynapxTracker] e reconstrói apenas o subtrecho
// delimitado quando algum deles muda.
//
// O `observable.watch(...)` explícito permanece como API canônica; [SynapxScope]
// é a conveniência opt-in auditável.
//
// Dependências: [Observable], [ObservableToken] (core), [SynapxTracker] (synapx) e
// `package:flutter/widgets.dart`.

import 'package:dnolib/core/core.dart';
import 'package:dnolib/synapx/src/reactive/synapx_reactive.dart';
import 'package:flutter/widgets.dart';

/// Reconstrói [builder] automaticamente quando qualquer [Observable] lido
/// durante a última execução síncrona sofre mutação.
class SynapxScope extends StatefulWidget {
  const SynapxScope({super.key, required this.builder});

  /// Construtor reativo executado sob rastreamento de [SynapxTracker].
  final WidgetBuilder builder;

  @override
  State<SynapxScope> createState() => _SynapxScopeState();
}

class _SynapxScopeState extends State<SynapxScope> {
  final SynapxTracker _tracker = SynapxTracker();
  final Map<Observable<dynamic>, ObservableToken<dynamic>> _subscriptions = {};

  @override
  Widget build(BuildContext context) {
    final read = <Observable<dynamic>>{};
    final child = _tracker.track(() => widget.builder(context), read.add);
    _reconcile(read);
    return child;
  }

  void _reconcile(Set<Observable<dynamic>> read) {
    final toRemove = _subscriptions.keys
        .where((observable) => !read.contains(observable))
        .toList();
    for (final observable in toRemove) {
      _subscriptions.remove(observable)?.cancel();
    }

    for (final observable in read) {
      _subscriptions.putIfAbsent(
        observable,
        () => observable.on(_onObservableChanged),
      );
    }
  }

  void _onObservableChanged(dynamic _) {
    if (!mounted) {
      return;
    }
    setState(() {});
  }

  @override
  void dispose() {
    for (final token in _subscriptions.values) {
      token.cancel();
    }
    _subscriptions.clear();
    super.dispose();
  }
}
