// Builder pontual explícito para um único [Observable] (sem Zone tracking).
//
// Complementa [SynapxScope]: ideal para trechos que dependem de um único
// observable (ex.: erro, flag booleana ou campo específico).
//
// Dependências: [Observable] (core), [ObservableAdapter]/[NotifierBuilder]
// (`widgets`) e `package:flutter/widgets.dart`.

import 'package:dnolib/core/core.dart';
import 'package:dnolib/widgets/widgets.dart';
import 'package:flutter/widgets.dart';

/// Assina explicitamente [observable] e reconstrói com seu valor atual.
class SynapxObserver<T> extends StatefulWidget {
  const SynapxObserver({
    super.key,
    required this.observable,
    required this.builder,
  });

  /// Observable observado diretamente sem rastreamento por `Zone`.
  final Observable<T> observable;

  /// Construtor chamado com o contexto e o valor atual de [observable].
  final Widget Function(BuildContext context, T value) builder;

  @override
  State<SynapxObserver<T>> createState() => _SynapxObserverState<T>();
}

class _SynapxObserverState<T> extends State<SynapxObserver<T>> {
  late ObservableAdapter<T> _listenable;

  @override
  void initState() {
    super.initState();
    _listenable = ObservableAdapter<T>(widget.observable);
  }

  @override
  void didUpdateWidget(covariant SynapxObserver<T> oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (!identical(oldWidget.observable, widget.observable)) {
      _listenable = ObservableAdapter<T>(widget.observable);
    }
  }

  @override
  Widget build(BuildContext context) {
    return NotifierBuilder<T>(
      listenable: _listenable,
      builder: widget.builder,
    );
  }
}
