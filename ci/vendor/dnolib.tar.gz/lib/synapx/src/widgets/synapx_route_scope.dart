// Adapter fino de rota modular (slice 0.2, Green): acopla [SynapxModuleScope] e
// [SynapxRouteGuardRunner] a rotas sobre o roteador da aplicação (RouterConfig /
// go_router / Navigator), sem reimplementar `RouterDelegate`.
//
// Dependências: [SynapxModuleScope], [SynapxProvider], [SynapxRouteGuard], [SynapxRouteGuardRunner]
// (synapx) e `package:flutter/widgets.dart`.

import 'dart:async';

import 'package:dnolib/synapx/src/lifecycle/synapx_lifecycle.dart';
import 'package:dnolib/synapx/src/routing/synapx_routing.dart';
import 'package:dnolib/synapx/src/widgets/synapx_provider.dart';
import 'package:flutter/widgets.dart';

/// Construtor de rota com [SynapxModuleScope] próprio e avaliação opcional de
/// [SynapxRouteGuard]s assíncronos.
class SynapxRouteScope extends StatefulWidget {
  const SynapxRouteScope({
    super.key,
    this.uri,
    this.module,
    this.createScope,
    this.bind,
    required this.builder,
    this.guards = const [],
    this.contextBuilder,
    this.loadingBuilder,
    this.rejectedBuilder,
    this.onRedirect,
    this.guardTimeout,
  });

  /// URI opcional usada ao construir o [SynapxRouteContext] padrão.
  final Uri? uri;

  /// Módulo declarativo aplicado ao [SynapxModuleScope] desta rota antes de [bind].
  final SynapxModule? module;

  /// Fábrica opcional do [SynapxModuleScope] vinculado ao ciclo de vida desta rota.
  ///
  /// Quando omitida, cria um [SynapxModuleScope] filho herdando automaticamente o
  /// [SynapxProvider.maybeOf] ancestral e executa [bind].
  final SynapxModuleScope Function(BuildContext context)? createScope;

  /// Atalho para registrar dependências no escopo filho criado automaticamente.
  final SynapxBinder? bind;

  /// Conteúdo da rota montado dentro do [SynapxProvider].
  final WidgetBuilder builder;

  /// Guards avaliados sequencialmente antes de exibir [builder].
  final List<SynapxRouteGuard> guards;

  /// Constrói o [SynapxRouteContext] entregue aos [guards].
  final SynapxRouteContext Function(BuildContext context)? contextBuilder;

  /// Exibido enquanto [guards] assíncronos estão em avaliação.
  final WidgetBuilder? loadingBuilder;

  /// Exibido quando um guard retorna [SynapxGuardReject].
  final Widget Function(BuildContext context, SynapxGuardReject reject)?
  rejectedBuilder;

  /// Chamado quando um guard retorna [SynapxGuardRedirect].
  final void Function(BuildContext context, Uri target)? onRedirect;

  /// Timeout opcional por guard individual.
  final Duration? guardTimeout;

  @override
  State<SynapxRouteScope> createState() => _SynapxRouteScopeState();
}

class _SynapxRouteScopeState extends State<SynapxRouteScope> {
  late final SynapxModuleScope _scope;
  late final SynapxRouteGuardRunner _runner;
  SynapxGuardResult? _result;

  @override
  void initState() {
    super.initState();
    _scope =
        widget.createScope?.call(context) ??
        (SynapxModuleScope(parent: SynapxProvider.readMaybeOf(context)));
    if (widget.module != null) {
      _scope.applyModule(widget.module!);
    }
    widget.bind?.call(_scope);
    _runner = SynapxRouteGuardRunner(timeout: widget.guardTimeout);
    if (widget.guards.isEmpty) {
      _result = const SynapxGuardAllow();
    } else {
      unawaited(_evaluateGuards());
    }
  }

  Future<void> _evaluateGuards() async {
    final routeContext =
        widget.contextBuilder?.call(context) ??
        SynapxRouteContext(uri: widget.uri ?? Uri.parse('/'), scope: _scope);
    final outcome = await _runner.evaluate(routeContext, widget.guards);
    if (!mounted) {
      return;
    }
    if (outcome is SynapxGuardRedirect) {
      widget.onRedirect?.call(context, outcome.target);
    }
    setState(() {
      _result = outcome;
    });
  }

  @override
  void dispose() {
    _runner.cancel();
    _scope.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final result = _result;
    if (result == null) {
      return widget.loadingBuilder?.call(context) ?? const SizedBox.shrink();
    }
    if (result is SynapxGuardReject) {
      return widget.rejectedBuilder?.call(context, result) ??
          const SizedBox.shrink();
    }
    if (result is SynapxGuardRedirect) {
      return const SizedBox.shrink();
    }
    return SynapxProvider.value(
      value: _scope,
      child: Builder(builder: widget.builder),
    );
  }
}
