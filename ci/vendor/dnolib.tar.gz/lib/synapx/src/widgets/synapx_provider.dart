// Integração do SynapxModuleScope com a árvore Flutter e observação de rotas
// (slice 0.1c, Green).
//
// Dependências: [SynapxModuleScope] (synapx) e `package:flutter/widgets.dart`.

import 'package:dnolib/synapx/src/lifecycle/synapx_module_scope.dart';
import 'package:flutter/widgets.dart';

/// Provê um [SynapxModuleScope] para a subárvore Flutter, descartando-o no
/// `State.dispose` quando [ownsScope] for `true`.
class SynapxProvider extends StatefulWidget {
  /// Cria e gerencia o ciclo de vida do [SynapxModuleScope] via [create].
  const SynapxProvider({
    super.key,
    required SynapxModuleScope Function(BuildContext context) create,
    required this.child,
  }) : _create = create,
       _value = null,
       ownsScope = true;

  /// Expõe um [SynapxModuleScope] externo sem assumir ownership do descarte.
  const SynapxProvider.value({
    super.key,
    required SynapxModuleScope value,
    required this.child,
  }) : _create = null,
       _value = value,
       ownsScope = false;

  final SynapxModuleScope Function(BuildContext context)? _create;
  final SynapxModuleScope? _value;

  /// `true` quando este widget é dono do escopo e deve descartá-lo ao desmontar.
  final bool ownsScope;

  /// Subárvore que terá acesso ao [SynapxModuleScope].
  final Widget child;

  /// Obtém o [SynapxModuleScope] ancestral mais próximo, registrando dependência.
  static SynapxModuleScope of(BuildContext context) {
    final scope = maybeOf(context);
    if (scope == null) {
      throw StateError('Nenhum SynapxProvider encontrado na árvore.');
    }
    return scope;
  }

  /// Obtém o [SynapxModuleScope] ancestral mais próximo ou `null` se ausente.
  static SynapxModuleScope? maybeOf(BuildContext context) {
    return context
        .dependOnInheritedWidgetOfExactType<_SynapxProviderInherited>()
        ?.scope;
  }

  /// Lê o [SynapxModuleScope] ancestral mais próximo sem registrar dependência de
  /// rebuild (seguro para uso em `initState`).
  static SynapxModuleScope? readMaybeOf(BuildContext context) {
    return context
        .getInheritedWidgetOfExactType<_SynapxProviderInherited>()
        ?.scope;
  }

  @override
  State<SynapxProvider> createState() => _SynapxProviderState();
}

/// Atalhos ergonômicos em [BuildContext] para acessar o [SynapxModuleScope] ativo.
extension SynapxContextExtension on BuildContext {
  /// [SynapxModuleScope] ancestral mais próximo.
  SynapxModuleScope get scope => SynapxProvider.of(this);

  /// Resolve [T] no [SynapxModuleScope] ancestral (ou pai).
  T get<T>({String? name}) => SynapxProvider.of(this).get<T>(name: name);

  /// Resolve [T] no [SynapxModuleScope] ancestral ou devolve `null`.
  T? tryGet<T>({String? name}) => SynapxProvider.of(this).tryGet<T>(name: name);
}

class _SynapxProviderState extends State<SynapxProvider> {
  late SynapxModuleScope _scope;

  @override
  void initState() {
    super.initState();
    _scope = widget._value ?? widget._create!(context);
  }

  @override
  void didUpdateWidget(covariant SynapxProvider oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (!widget.ownsScope &&
        widget._value != null &&
        widget._value != oldWidget._value) {
      _scope = widget._value!;
    }
  }

  @override
  void dispose() {
    if (widget.ownsScope) {
      _scope.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return _SynapxProviderInherited(scope: _scope, child: widget.child);
  }
}

class _SynapxProviderInherited extends InheritedWidget {
  const _SynapxProviderInherited({required this.scope, required super.child});

  final SynapxModuleScope scope;

  @override
  bool updateShouldNotify(covariant _SynapxProviderInherited oldWidget) =>
      scope != oldWidget.scope;
}

/// Observador de rotas compatível com `RouteAware` para rastreamento de
/// ciclo de vida de rotas ativas.
class SynapxRouteObserver extends RouteObserver<ModalRoute<dynamic>> {
  final Set<Route<dynamic>> _activeRoutes = {};

  /// Quantidade de rotas atualmente ativas na pilha observada.
  int get activeRoutesCount => _activeRoutes.length;

  @override
  void didPush(Route<dynamic> route, Route<dynamic>? previousRoute) {
    super.didPush(route, previousRoute);
    _activeRoutes.add(route);
  }

  @override
  void didPop(Route<dynamic> route, Route<dynamic>? previousRoute) {
    super.didPop(route, previousRoute);
    _activeRoutes.remove(route);
  }

  @override
  void didReplace({Route<dynamic>? newRoute, Route<dynamic>? oldRoute}) {
    super.didReplace(newRoute: newRoute, oldRoute: oldRoute);
    if (oldRoute != null) {
      _activeRoutes.remove(oldRoute);
    }
    if (newRoute != null) {
      _activeRoutes.add(newRoute);
    }
  }

  @override
  void didRemove(Route<dynamic> route, Route<dynamic>? previousRoute) {
    super.didRemove(route, previousRoute);
    _activeRoutes.remove(route);
  }
}
