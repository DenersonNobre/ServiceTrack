// Atalhos de UI do Synapx com contexto explícito (delta GetX sem armadilha):
// `confirm` e `notifySuccess`/`notifyError` como extensions em [BuildContext],
// sem chave global de navegação — reaproveitam [ConfirmDialog] e [Alert] do
// módulo `widgets`.
//
// Dependências: [ConfirmDialog], [Alert] (`widgets/`) e
// `package:flutter/material.dart`.

import 'package:dnolib/widgets/widgets.dart';
import 'package:flutter/material.dart';

/// Diálogos e avisos do Synapx sobre um [BuildContext] explícito.
extension SynapxDialogsExtension on BuildContext {
  /// Pergunta de confirmação modal; devolve `false` ao dispensar.
  Future<bool> confirm({
    required String title,
    required String message,
    String confirmLabel = 'Confirmar',
    String cancelLabel = 'Cancelar',
  }) async {
    final result = await showDialog<bool>(
      context: this,
      builder: (_) => ConfirmDialog(
        title: title,
        message: message,
        confirmLabel: confirmLabel,
        cancelLabel: cancelLabel,
      ),
    );
    return result ?? false;
  }

  /// Aviso de sucesso (SnackBar do tema via [Alert]).
  void notifySuccess(String message, {String title = 'Sucesso'}) {
    Alert.success(this, title: title, message: message);
  }

  /// Aviso de erro (SnackBar do tema via [Alert]).
  void notifyError(String message, {String title = 'Erro'}) {
    Alert.error(this, title: title, message: message);
  }
}
