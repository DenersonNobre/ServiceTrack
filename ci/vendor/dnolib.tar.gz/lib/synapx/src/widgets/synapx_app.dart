// Widget composicional de inicialização do Synapx (sem espelhar MaterialApp).
//
// Gerencia automaticamente o [SynapxModuleScope] raiz e o [SynapxRouteObserver]
// entregando-os ao [builder] da aplicação (MaterialApp, MaterialApp.router,
// go_router, CupertinoApp), com descarte determinístico ao desmontar.
//
// Dependências: [SynapxModuleScope], [SynapxRouteObserver], [SynapxProvider] (synapx) e
// `package:flutter/widgets.dart`.

import 'package:dnolib/synapx/src/lifecycle/synapx_lifecycle.dart';
import 'package:dnolib/synapx/src/widgets/synapx_provider.dart';
import 'package:flutter/widgets.dart';

/// Construtor da raiz da aplicação com acesso ao [SynapxModuleScope] raiz e ao
/// [SynapxRouteObserver].
typedef SynapxAppBuilder =
    Widget Function(
      BuildContext context,
      SynapxModuleScope scope,
      SynapxRouteObserver observer,
    );

/// Construtor enxuto da raiz da aplicação quando apenas [SynapxRouteObserver]
/// é necessário (evita placeholders de `scope`).
typedef SynapxObserverAppBuilder =
    Widget Function(
      BuildContext context,
      SynapxRouteObserver observer,
    );

/// Ponto de entrada composicional do Synapx para envolver o `MaterialApp`
/// (ou `MaterialApp.router`) da aplicação.
class SynapxApp extends StatelessWidget {
  const SynapxApp({
    super.key,
    this.module,
    this.bind,
    this.builder,
    this.appBuilder,
  }) : assert(
         (builder == null) != (appBuilder == null),
         'Informe exatamente um entre builder ou appBuilder.',
       );

  /// Módulo declarativo aplicado ao [SynapxModuleScope] raiz antes de [bind].
  final SynapxModule? module;

  /// Registra dependências iniciais no [SynapxModuleScope] raiz.
  final SynapxBinder? bind;

  /// Constrói a árvore raiz com acesso ao escopo raiz e ao observador.
  final SynapxAppBuilder? builder;

  /// Constrói a árvore raiz recebendo apenas `context` e [SynapxRouteObserver].
  final SynapxObserverAppBuilder? appBuilder;

  @override
  Widget build(BuildContext context) {
    return SynapxProvider(
      create: (_) {
        final scope = SynapxModuleScope();
        if (module != null) {
          scope.applyModule(module!);
        }
        bind?.call(scope);
        if (scope.tryGet<SynapxRouteObserver>() == null) {
          scope.registerLazySingleton<SynapxRouteObserver>(
            (_) => SynapxRouteObserver(),
          );
        }
        return scope;
      },
      child: Builder(
        builder: (innerContext) {
          final scope = SynapxProvider.of(innerContext);
          final observer = scope.get<SynapxRouteObserver>();
          final simpleBuilder = appBuilder;
          if (simpleBuilder != null) {
            return simpleBuilder(innerContext, observer);
          }
          return builder!(innerContext, scope, observer);
        },
      ),
    );
  }
}
