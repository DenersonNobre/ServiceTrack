// Ponte reativa estilo StateMixin sobre [Command], sem dependência de Material.
//
// Observa [Command.isExecuting] e [Command.result] via [SynapxScope] e mapeia
// os estados `idle`, `loading`, `empty`, `success` e `error` (com `retry`).
//
// Dependências: [Command], [IResult] (core), [SynapxScope] (synapx) e
// `package:flutter/widgets.dart`.

import 'package:dnolib/core/core.dart';
import 'package:dnolib/synapx/src/widgets/synapx_scope.dart';
import 'package:flutter/widgets.dart';

/// Construtor de UI em estado de erro com callback de nova tentativa.
typedef SynapxCommandErrorBuilder<TFailure> =
    Widget Function(BuildContext context, TFailure failure, VoidCallback retry);

/// Renderiza os estados assíncronos de um [Command] sem acoplamento a Material.
///
/// Ordem de resolução:
/// 1. `executing == true` → [onLoading] (ou `SizedBox.shrink()`).
/// 2. `result == null` → [onIdle] (ou [onLoading], ou `SizedBox.shrink()`).
/// 3. `Success` vazio (quando [onEmpty] é fornecido) → [onEmpty].
/// 4. `Success` com dados → [onSuccess].
/// 5. `Failure` → [onError] com `retry` (ou `SizedBox.shrink()`).
class SynapxCommandView<TSuccess, TFailure, TParam> extends StatelessWidget {
  const SynapxCommandView({
    super.key,
    required this.command,
    required this.onSuccess,
    this.onIdle,
    this.onLoading,
    this.onEmpty,
    this.onError,
    this.isEmpty,
    this.retryParam,
  });

  /// Comando observado pelo widget.
  final Command<TSuccess, TFailure, TParam> command;

  /// Construtor para estado inicial antes da primeira execução.
  final WidgetBuilder? onIdle;

  /// Construtor exibido enquanto [Command.isExecuting] é `true`.
  final WidgetBuilder? onLoading;

  /// Construtor para sucesso com dados não vazios.
  final Widget Function(BuildContext context, TSuccess data) onSuccess;

  /// Construtor opcional quando o dado de sucesso é considerado vazio.
  final WidgetBuilder? onEmpty;

  /// Construtor opcional para falhas tipadas, recebendo função `retry`.
  final SynapxCommandErrorBuilder<TFailure>? onError;

  /// Predicado customizado para determinar se `data` está vazio.
  final bool Function(TSuccess data)? isEmpty;

  /// Parâmetro repassado a `command.run(retryParam)` ao acionar `retry`.
  final TParam? retryParam;

  @override
  Widget build(BuildContext context) {
    return SynapxScope(
      builder: (context) {
        final executing = command.isExecuting.value;
        final result = command.result.value;

        if (executing) {
          return onLoading?.call(context) ?? const SizedBox.shrink();
        }
        if (result == null) {
          return onIdle?.call(context) ??
              onLoading?.call(context) ??
              const SizedBox.shrink();
        }
        return switch (result) {
          Success(:final value) when onEmpty != null && _isEmptyData(value) =>
            onEmpty!(context),
          Success(:final value) => onSuccess(context, value),
          Failure(:final value) =>
            onError?.call(context, value, () => command.run(retryParam)) ??
                const SizedBox.shrink(),
        };
      },
    );
  }

  bool _isEmptyData(TSuccess data) {
    final customCheck = isEmpty;
    if (customCheck != null) {
      return customCheck(data);
    }
    if (data is Iterable) {
      return data.isEmpty;
    }
    if (data is Map) {
      return data.isEmpty;
    }
    if (data is String) {
      return data.isEmpty;
    }
    return false;
  }
}
