// Widget base declarativo do Synapx (estilo GetView<T>, mas com escopo
// hierárquico via [SynapxProvider] e zero estado global).
//
// Dependências: [SynapxProvider] (synapx) e `package:flutter/widgets.dart`.

import 'package:dnolib/synapx/src/widgets/synapx_provider.dart';
import 'package:dnolib/synapx/src/widgets/synapx_scope.dart';
import 'package:flutter/widgets.dart';

/// Página ou widget base que resolve automaticamente o controlador [T] a
/// partir do [SynapxModuleScope] ancestral mais próximo.
///
/// Subclasses acessam [controller] diretamente em [build] e em métodos de
/// evento da classe. Use [tag] quando o registro no [SynapxModuleScope] tiver
/// qualificador por nome.
abstract class SynapxPage<T extends Object> extends StatelessWidget {
  const SynapxPage({super.key});

  static final Expando<BuildContext> _elementContexts = Expando<BuildContext>(
    'SynapxPageElements',
  );

  /// Qualificador opcional passado para `SynapxModuleScope.get<T>(name: tag)`.
  String? get tag => null;

  /// Instância de [T] resolvida no [SynapxModuleScope] ancestral.
  @protected
  T get controller {
    final context = _elementContexts[this];
    if (context == null) {
      throw StateError(
        'Não é possível acessar "controller" antes da montagem ou após o '
        'descarte de $runtimeType.',
      );
    }
    return SynapxProvider.of(context).get<T>(name: tag);
  }

  @override
  StatelessElement createElement() => _SynapxPageElement<T>(this);
}

/// Variante de [SynapxPage] cujo [buildReactive] executa dentro de [SynapxScope].
///
/// Ideal para páginas/widgets cujo corpo inteiro reage a observables de
/// [controller], eliminando um nível de wrapper manual.
abstract class SynapxReactivePage<T extends Object> extends SynapxPage<T> {
  const SynapxReactivePage({super.key});

  /// Constrói a árvore sob rastreamento automático de [SynapxScope].
  @protected
  Widget buildReactive(BuildContext context);

  @override
  Widget build(BuildContext context) => SynapxScope(builder: buildReactive);
}

class _SynapxPageElement<T extends Object> extends StatelessElement {
  _SynapxPageElement(SynapxPage<T> super.widget);

  @override
  Widget build() {
    SynapxPage._elementContexts[widget] = this;
    return super.build();
  }

  @override
  void update(StatelessWidget newWidget) {
    SynapxPage._elementContexts[newWidget] = this;
    super.update(newWidget);
  }

  @override
  void unmount() {
    SynapxPage._elementContexts[widget] = null;
    super.unmount();
  }
}
