// Rastreamento reativo por instância via Zone (slice 0.1b, Green).
//
// Substitui pilhas estáticas globais mutáveis: cada [SynapxTracker] roda sob uma
// [Zone] própria e suporta apenas computação síncrona (`_active` é desligado
// no `finally`), garantindo isolamento entre testes concorrentes e escopos
// aninhados.
//
// Dependências: [Observable] (core) e SDK (`dart:async`).

import 'dart:async';

import 'package:dnolib/core/core.dart';

/// Rastreador por instância de leituras de [Observable.value] via [Zone].
final class SynapxTracker {
  SynapxTracker();

  static final Object _zoneKey = Object();

  bool _active = false;
  void Function(Observable<dynamic>)? _onRead;

  /// Retorna o tracker ativo na [Zone] corrente, ou `null` fora de escopo.
  static SynapxTracker? get current {
    final tracker = Zone.current[_zoneKey] as SynapxTracker?;
    return (tracker != null && tracker._active) ? tracker : null;
  }

  /// Executa [computation] de forma síncrona registrando cada [Observable]
  /// lido através de [onRead].
  T track<T>(
    T Function() computation,
    void Function(Observable<dynamic> observable) onRead,
  ) {
    final previousActive = _active;
    final previousOnRead = _onRead;
    _active = true;
    _onRead = onRead;
    try {
      return runZoned(
        computation,
        zoneValues: <Object?, Object?>{
          _zoneKey: this,
          Observable.readTrackerZoneKey: recordRead,
        },
      );
    } finally {
      _active = previousActive;
      _onRead = previousOnRead;
    }
  }

  /// Registra a leitura de [observable] se este tracker estiver ativo.
  void recordRead(Observable<dynamic> observable) {
    if (!_active) {
      return;
    }
    _onRead?.call(observable);
  }
}
