// Coleções observáveis do Synapx (slice 0.1a, Green): `SynapxList` e `SynapxMap`
// compõem `Observable` (notificação, tokens, descarte) com `ListBase` e
// `MapBase` do `dart:collection`.
//
// Semântica de notificação:
// - cada mutação efetiva emite exatamente UMA notificação;
// - operações no-op (`remove` ausente, `clear` em vazio, `[]=` com mesmo
//   valor) NÃO notificam;
// - `batch` condensa N mutações (inclusive aninhadas) em uma notificação,
//   com `try/finally` para não travar o contador em caso de exceção.
//
// `value` é a coleção viva: leituras diretas não notificam — mutar sempre
// pela API de `SynapxList`/`SynapxMap`.
//
// Dependências: [Observable] (core) e SDK (`dart:collection`, `dart:math`).

import 'dart:collection';
import 'dart:math';

import 'package:dnolib/core/core.dart';

/// Lista observável: `Observable<List<E>>` com interface `List<E>` completa.
///
/// Mutadores sobrescritos emitem uma única notificação por chamada quando há
/// alteração efetiva; `batch` condensa blocos de mutação.
class SynapxList<E> extends Observable<List<E>> with ListMixin<E> {
  SynapxList([List<E>? initial]) : super(List<E>.of(initial ?? <E>[]));

  int _batchDepth = 0;
  bool _dirty = false;

  @override
  int get length => value.length;

  @override
  set length(int newLength) {
    if (newLength == value.length) {
      return;
    }
    value.length = newLength;
    _didMutate();
  }

  @override
  E operator [](int index) => value[index];

  @override
  void operator []=(int index, E element) {
    if (value[index] == element) {
      return;
    }
    value[index] = element;
    _didMutate();
  }

  @override
  void add(E element) {
    value.add(element);
    _didMutate();
  }

  @override
  void addAll(Iterable<E> iterable) {
    if (iterable.isEmpty) {
      return;
    }
    value.addAll(iterable);
    _didMutate();
  }

  @override
  void insert(int index, E element) {
    value.insert(index, element);
    _didMutate();
  }

  @override
  void insertAll(int index, Iterable<E> iterable) {
    if (iterable.isEmpty) {
      return;
    }
    value.insertAll(index, iterable);
    _didMutate();
  }

  @override
  bool remove(Object? element) {
    final removed = value.remove(element);
    if (removed) {
      _didMutate();
    }
    return removed;
  }

  @override
  E removeAt(int index) {
    final removed = value.removeAt(index);
    _didMutate();
    return removed;
  }

  @override
  E removeLast() {
    final removed = value.removeLast();
    _didMutate();
    return removed;
  }

  @override
  void removeRange(int start, int end) {
    if (start == end) {
      return;
    }
    value.removeRange(start, end);
    _didMutate();
  }

  @override
  void removeWhere(bool Function(E element) test) {
    final before = value.length;
    value.removeWhere(test);
    if (value.length != before) {
      _didMutate();
    }
  }

  @override
  void retainWhere(bool Function(E element) test) {
    final before = value.length;
    value.retainWhere(test);
    if (value.length != before) {
      _didMutate();
    }
  }

  @override
  void clear() {
    if (value.isEmpty) {
      return;
    }
    value.clear();
    _didMutate();
  }

  @override
  void sort([int Function(E a, E b)? compare]) {
    if (value.length <= 1) {
      return;
    }
    value.sort(compare);
    _didMutate();
  }

  @override
  void shuffle([Random? random]) {
    if (value.length <= 1) {
      return;
    }
    value.shuffle(random);
    _didMutate();
  }

  @override
  void setRange(int start, int end, Iterable<E> iterable, [int skipCount = 0]) {
    if (start == end) {
      return;
    }
    value.setRange(start, end, iterable, skipCount);
    _didMutate();
  }

  @override
  void fillRange(int start, int end, [E? fill]) {
    if (start == end) {
      return;
    }
    value.fillRange(start, end, fill);
    _didMutate();
  }

  @override
  void replaceRange(int start, int end, Iterable<E> newContents) {
    if (start == end && newContents.isEmpty) {
      return;
    }
    value.replaceRange(start, end, newContents);
    _didMutate();
  }

  @override
  void setAll(int index, Iterable<E> iterable) {
    if (iterable.isEmpty) {
      return;
    }
    value.setAll(index, iterable);
    _didMutate();
  }

  /// Substitui todo o conteúdo por [items] emitindo no máximo uma notificação.
  ///
  /// Permanece silencioso quando lista e [items] já são ambas vazias.
  void assign(Iterable<E> items) {
    final snapshot = List<E>.of(items);
    batch((list) {
      list
        ..clear()
        ..addAll(snapshot);
    });
  }

  /// Executa [action] condensando todas as mutações em uma única notificação
  /// ao final do bloco externo (aninhamento soma profundidade, sem notificar
  /// nos níveis internos). Se [action] lançar, o parcial acumulado é
  /// descarregado (uma notificação com o estado real) antes de a exceção
  /// propagar; a profundidade é resetada via `finally`.
  void batch(void Function(SynapxList<E> list) action) {
    _batchDepth++;
    try {
      action(this);
    } finally {
      _batchDepth--;
      if (_batchDepth == 0 && _dirty) {
        _dirty = false;
        notify();
      }
    }
  }

  void _didMutate() {
    if (_batchDepth > 0) {
      _dirty = true;
      return;
    }
    notify();
  }
}

/// Mapa observável: `Observable<Map<K, V>>` com interface `Map<K, V>` completa.
///
/// Mesma semântica de [SynapxList]: uma notificação por mutação efetiva, no-ops
/// silenciosos e [batch] condensador.
class SynapxMap<K, V> extends Observable<Map<K, V>> with MapMixin<K, V> {
  SynapxMap([Map<K, V>? initial]) : super(Map<K, V>.of(initial ?? <K, V>{}));

  int _batchDepth = 0;
  bool _dirty = false;

  @override
  Iterable<K> get keys => value.keys;

  @override
  V? operator [](Object? key) => value[key];

  @override
  void operator []=(K key, V val) {
    if (value.containsKey(key) && value[key] == val) {
      return;
    }
    value[key] = val;
    _didMutate();
  }

  @override
  V? remove(Object? key) {
    if (!value.containsKey(key)) {
      return null;
    }
    final removed = value.remove(key);
    _didMutate();
    return removed;
  }

  @override
  void clear() {
    if (value.isEmpty) {
      return;
    }
    value.clear();
    _didMutate();
  }

  @override
  void addAll(Map<K, V> other) {
    if (other.isEmpty) {
      return;
    }
    value.addAll(other);
    _didMutate();
  }

  @override
  void addEntries(Iterable<MapEntry<K, V>> newEntries) {
    if (newEntries.isEmpty) {
      return;
    }
    value.addEntries(newEntries);
    _didMutate();
  }

  @override
  void removeWhere(bool Function(K key, V value) test) {
    if (value.isEmpty) {
      return;
    }
    final before = value.length;
    value.removeWhere(test);
    if (value.length != before) {
      _didMutate();
    }
  }

  @override
  V update(K key, V Function(V value) update, {V Function()? ifAbsent}) {
    final hadKey = value.containsKey(key);
    final previous = hadKey ? value[key] : null;
    final result = value.update(key, update, ifAbsent: ifAbsent);
    if (!hadKey || previous != result) {
      _didMutate();
    }
    return result;
  }

  @override
  void updateAll(V Function(K key, V value) update) {
    if (value.isEmpty) {
      return;
    }
    value.updateAll(update);
    _didMutate();
  }

  @override
  V putIfAbsent(K key, V Function() ifAbsent) {
    if (value.containsKey(key)) {
      return value[key] as V;
    }
    final result = value.putIfAbsent(key, ifAbsent);
    _didMutate();
    return result;
  }

  /// Substitui todo o conteúdo por [entries] emitindo no máximo uma notificação.
  ///
  /// Permanece silencioso quando mapa e [entries] já são ambos vazios.
  void assign(Map<K, V> entries) {
    final snapshot = Map<K, V>.of(entries);
    batch((map) {
      map
        ..clear()
        ..addAll(snapshot);
    });
  }

  /// Condensa as mutações de [action] em uma única notificação (ver
  /// [SynapxList.batch], incluindo o descarregamento do parcial em caso de exceção).
  void batch(void Function(SynapxMap<K, V> map) action) {
    _batchDepth++;
    try {
      action(this);
    } finally {
      _batchDepth--;
      if (_batchDepth == 0 && _dirty) {
        _dirty = false;
        notify();
      }
    }
  }

  void _didMutate() {
    if (_batchDepth > 0) {
      _dirty = true;
      return;
    }
    notify();
  }
}

/// Atalho fluente: `[1, 2].rx` envolve uma **cópia** mutável em [SynapxList].
/// Mutações posteriores na lista de origem não afetam o [SynapxList].
extension SynapxListExtension<E> on List<E> {
  SynapxList<E> get rx => SynapxList<E>(this);
}

/// Atalho fluente: `{'a': 1}.rx` envolve uma **cópia** mutável em [SynapxMap].
/// Mutações posteriores no mapa de origem não afetam o [SynapxMap].
extension SynapxMapExtension<K, V> on Map<K, V> {
  SynapxMap<K, V> get rx => SynapxMap<K, V>(this);
}
