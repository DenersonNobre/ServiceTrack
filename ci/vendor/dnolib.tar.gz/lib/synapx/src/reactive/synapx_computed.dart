// Estado derivado reativo (Dart puro): [SynapxComputed<T>] e helper [synapxComputed].
//
// Rastreia automaticamente os [Observable]s lidos durante `compute()` via
// [SynapxTracker], reconcilia assinaturas condicionais e só notifica assinantes
// quando o valor derivado realmente muda (`==`).
//
// Dependências: [Observable], [ObservableToken] (core) e [SynapxTracker] (synapx).

import 'package:dnolib/core/core.dart';
import 'package:dnolib/synapx/src/reactive/synapx_tracker.dart';

/// Observável somente-leitura cujo valor é derivado de outros [Observable]s.
class SynapxComputed<T> extends Observable<T> {
  factory SynapxComputed(T Function() compute) {
    final tracker = SynapxTracker();
    final reads = <Observable<dynamic>>{};
    final initial = tracker.track(compute, reads.add);
    final instance = SynapxComputed<T>._(initial, compute, tracker);
    instance._reconcile(reads);
    return instance;
  }

  SynapxComputed._(super.initial, this._compute, this._tracker);

  final T Function() _compute;
  final SynapxTracker _tracker;
  final Map<Observable<dynamic>, ObservableToken<dynamic>> _subscriptions = {};
  bool _disposed = false;

  @override
  set value(T next) {
    throw UnsupportedError(
      'SynapxComputed é somente leitura; altere os Observables de origem.',
    );
  }

  void _recompute(dynamic _) {
    if (_disposed) {
      return;
    }
    final reads = <Observable<dynamic>>{};
    final next = _tracker.track(_compute, reads.add);
    _reconcile(reads);
    super.value = next;
  }

  void _reconcile(Set<Observable<dynamic>> reads) {
    final toRemove = _subscriptions.keys
        .where((observable) => !reads.contains(observable))
        .toList();
    for (final observable in toRemove) {
      _subscriptions.remove(observable)?.cancel();
    }

    for (final observable in reads) {
      if (identical(observable, this)) {
        continue;
      }
      _subscriptions.putIfAbsent(observable, () => observable.on(_recompute));
    }
  }

  @override
  void dispose() {
    if (_disposed) {
      return;
    }
    _disposed = true;
    for (final token in _subscriptions.values) {
      token.cancel();
    }
    _subscriptions.clear();
    super.dispose();
  }
}

/// Cria um [SynapxComputed<T>] somente-leitura derivado de [compute].
SynapxComputed<T> synapxComputed<T>(T Function() compute) =>
    SynapxComputed<T>(compute);
