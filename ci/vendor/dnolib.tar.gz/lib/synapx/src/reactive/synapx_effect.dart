// Workers reativos do Synapx (identidade canônica): fachada estática
// [SynapxEffect] sobre qualquer [Observable], com descarte via
// [ObservableToken].
//
// - `ever`: reação contínua (sem replay, como `Observable.on`);
// - `once`: disparo único, com auto-cancelamento antes do callback (seguro
//   contra mutação reentrante dentro do próprio callback);
// - `debounce`: emite só a última após [duration] sem novos eventos
//   (reaproveita [Debouncer]);
// - `interval`: throttle em janela fixa — dispara no primeiro evento e
//   ignora novos eventos até transcorrer [duration].
//
// `token.cancel()` cancela `Timer`s/`Debouncer` pendentes via `onCancel` e
// impede chamadas tardias.
//
// Dependências: [Observable], [ObservableToken] e [Debouncer] (core) e SDK
// (`dart:async` para `Timer`).

import 'dart:async';

import 'package:dnolib/core/core.dart';

/// Reação reativa a um valor: callback padrão dos workers de [SynapxEffect].
typedef SynapxCallback<T> = void Function(T value);

/// Fachada canônica dos workers reativos do Synapx.
abstract final class SynapxEffect {
  /// Reage a cada mudança de [rx], sem replay do valor corrente.
  static ObservableToken<T> ever<T>(
    Observable<T> rx,
    SynapxCallback<T> callback,
  ) {
    return rx.on(callback);
  }

  /// Reage só ao primeiro evento; cancela o próprio token antes de executar
  /// [callback], então mutações reentrantes dentro do callback não re-disparam.
  static ObservableToken<T> once<T>(
    Observable<T> rx,
    SynapxCallback<T> callback,
  ) {
    late final ObservableToken<T> token;
    token = rx.on((T value) {
      token.cancel();
      callback(value);
    });
    return token;
  }

  /// Emite só o último valor após [duration] sem novos eventos.
  static ObservableToken<T> debounce<T>(
    Observable<T> rx,
    SynapxCallback<T> callback, {
    required Duration duration,
  }) {
    final debouncer = Debouncer<T>(duration: duration, callback: callback);
    return rx.on(debouncer.call, onCancel: debouncer.cancel);
  }

  /// Throttle em janela fixa: dispara no primeiro evento e ignora novos eventos
  /// até transcorrer [duration].
  static ObservableToken<T> interval<T>(
    Observable<T> rx,
    SynapxCallback<T> callback, {
    required Duration duration,
  }) {
    Timer? timer;
    var ready = true;
    late final ObservableToken<T> token;
    token = rx.on(
      (T value) {
        if (!ready) {
          return;
        }
        ready = false;
        try {
          callback(value);
        } finally {
          if (token.isActive) {
            timer = Timer(duration, () {
              ready = true;
            });
          }
        }
      },
      onCancel: () {
        timer?.cancel();
        timer = null;
      },
    );
    return token;
  }
}
