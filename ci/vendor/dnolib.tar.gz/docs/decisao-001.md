# Decisão 001 — Consumo versionado da dnolib (git+tag e versionamento com melos)

- **Status**: aceita em 2026-10-06
- **Escopo**: `#dnolib` (lib) + `compras` (app) + `vendas` (app, pós-refatoração)
- **Contexto**: desfecho da sessão de 2026-10-06 no compras; substitui a dependência `path` por consumo pinado por tag.

---

## 1. Contexto e motivação

### O dilema original

A `dnolib` é a base compartilhada dos apps Flutter do ecossistema. Historicamente ela
consumia-se por **caminho local vivo**:

- `compras`: `dnolib: path: ../../#dnolib` — o app compilava contra o **working tree
  atual** da lib;
- `vendas`: consumia o fork `.dnolib` (workspace multi-pacote) também por `path`.

Consequência: **qualquer alteração na cópia principal da lib propagava
silenciosamente a todos os apps que apontassem para ela** — sem tag, sem release,
sem gate. Uma mudança em desenvolvimento na lib quebrava apps que nada tinham a ver
com aquele trabalho, e o `pubspec.lock` não ancorava nada (dependência `path` não é
pinada pelo lock).

### Evidências coletadas (2026-10-06)

| Evidência                                                        | Leitura                                                                                                                                               |
| ---------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Fork** `#dnolib` × `.dnolib`                                     | Duas linhagens divergentes: `#dnolib` = pacote único (87 arquivos `.dart`, `v0.1.0`, HEAD `17a92da`); `.dnolib` = workspace (`dnolib+kernel+rest+sqlite+widgets`, `v0.0.1`, HEAD `4bb81a4`). Nenhuma tinha remote ou tags. |
| Anti-padrão `vendas.monorepo` (backup em `A:\Projetos\#Backups\`) | Workspace nativo do pub **sem** melos: root `orquestrator` com `workspace: [dnolib, modules\..., vendas]`, membros com `resolution: workspace`, dnolib **dentro** da árvore live, um único lock, zero tags/ferramenta de versionamento. |
| `http://gitea.lan/DartFlutter/DNOLib.git`                          | Repo criado no Gitea e **vazio** — destino natural para a lib canônica.                                                                                |

**Decisão de canonicidade (anterior a esta)**: `#dnolib` é a lib canônica; o fork
`.dnolib` será **removido** quando o `vendas` refatorar para consumir a `#dnolib`.

## 2. Decisão

1. **Apps permanecem em repositórios separados.** A opção "repo único" foi avaliada
   e descartada pelo mantenedor nesta sessão.
2. **A `#dnolib` ganha repositório próprio no Gitea** (`DartFlutter/DNOLib`) e passa
   a ser versionada com **melos em modo single-package**:
   - root `pubspec.yaml` vira workspace vazio com `useRootAsPackage: true`
     (tags plain `vX.Y.Z`, compatíveis com `tag_pattern: v{{version}}`);
   - `versionPrivatePackages: true` (o pacote tem `publish_to: none`, senão o
     `melos version` o pula);
   - `command.version.branch: main` (release só a partir de `main`);
   - bumps por **Conventional Commits** (histórico da lib já obedece; pre-1.0:
     breaking → minor, ex.: `0.1.x → 0.2.0`).
3. **Cada app consome a lib pinada por tag**:

   ```yaml
   dnolib:
     git:
        url: http://gitea.lan/DartFlutter/DNOLib.git
       tag_pattern: v{{version}}
     version: ^0.1.0
   ```

   com o **`pubspec.lock` commitado** (SHA travado por repo). Requer Dart `^3.9.0`
   (a constraint de versão é obrigatória junto do `tag_pattern`).
4. **Jornada A é o único fluxo oficial de promoção de código** (código nasce no app,
   promove-se para a lib quando estabilizar). A *Jornada B* (co-desenvolvimento com
   override de path gerenciado pelo `dependencyOverridePaths` do melos) foi
   **considerada e adiada** — só entra se surgir demanda grande e prolongada de
   desenvolvimento na lib.

## 3. Alternativas consideradas e rejeitadas

| Alternativa                                        | Por que foi rejeitada                                                                                                                                                                                             |
| --------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **melos orquestrando todos os repos**               | melos opera sobre **um único workspace** por execução — não alcança repositórios soltos. Orquestração cross-repo não existe sem unificar o repo (descartado).                                                      |
| **dnolib como membro do workspace dos apps**        | `melos bootstrap`/pub workspace interliga membros ao **working tree local, independentemente da fonte declarada** — qualquer `source:` declarado perde para o diretório local. Recriaria o dilema original.        |
| **Monorepo único (lib + apps)**                     | Descartado explicitamente pelo mantenedor: perda de autonomia de release/CI por app, blast radius maior, custo de adoção desproporcional ao tamanho da frota (2 apps).                                             |
| **Pub server privado**                              | Infraestrutura nova (servidor + auth + publicação por release) desproporcional para 1 lib e 2 apps. O Gitea já entrega o mesmo contrato via git tags.                                                               |
| **Path + testes de contrato**                       | Sem CI, o contrato não é verificado em lugar nenhum; e `path` continua sem pin — exatamente o comportamento que causou o dilema.                                                                                   |
| **Jornada B (override de co-dev)**                  | Adiada, não rejeitada em definitivo: gera um switch de working tree live que precisa de disciplina (reverter o override após o ciclo). Ativa apenas sob demanda futura explícita.                                   |

## 4. Desenho alvo

```
#dnolib (repo próprio → gitea.lan/DartFlutter/DNOLib)
│   melos single-package: melos version → bump + CHANGELOG + tag anotada vX.Y.Z
│   develop (trabalho) ──merge──► main (releases) ──tag──► vX.Y.Z  (imutável)
│
│   dnolib: { git: { url: ..., tag_pattern: v{{version}} }, version: ^0.1.0 }
│   pubspec.lock commitado → SHA travado POR REPO
▼
compras (repo próprio)                     vendas (repo próprio, pós-refatoração)
```

- **O que é commitado no app**: só a declaração (`pubspec.yaml`) e o SHA
  (`pubspec.lock`). Nenhuma cópia do fonte da lib entra no repo — nem pasta
  `dnolib/`, nem submodule, nem subtree.
- **Onde o fonte vive no disco**: no cache global do pub do SDK ativo (aqui, via Puro:
  `A:\Desenvolvimento\Puro\shared\pub_cache\git\...`; fora do Puro seria
  `%LOCALAPPDATA%\Pub\Cache\git\...`), fora dos repositórios, compartilhado entre
  projetos, materializado na tag travada.
- **Custo de máquina**: build é por app e incremental; não existe build conjunto
  (não há orquestração — ver §7).

## 5. Regras duras

1. **Nunca** adicionar a `dnolib` (ou qualquer lib) como membro do workspace de um
   app — nem por `melos`, nem por `workspace:` no pubspec.
2. **Tag anotada só em release explícita** e sempre a partir de `main`; **nunca**
   mover/force-tag (`--force` em tag é proibido — a tag é a âncora inteira).
3. **`pubspec.lock` dos apps é commitado**; na lib, `melos bootstrap` roda com
   `enforceLockfile` para travar o SHA em todas as máquinas.
4. **Segundo consumidor = promover antes de copiar.** Enquanto só um app usa uma
   peça, ela pode viver no app. No instante em que um **segundo** app precisar da
   mesma peça, ela **obrigatoriamente** vai para a `#dnolib` (§6) — copiar código de
   um app para outro recria o fork que causou o dilema.
5. **Upgrade da lib é decisão e gate por app**: `dart pub upgrade dnolib` →
   `flutter analyze` + testes **naquele app** → commit **naquele app**. Quebra, se
   existir, aparece isolada no commit que escolheu subir.
6. **Documentação de todos os repos deste ecossistema em pt-BR** (identificadores
   em inglês; conteúdo dos `.md` em pt-BR). Desvio conhecido corrigido em 2026-10-06:
   `compras/AGENTS.md` estava em EN.

## 6. Ciclo de vida operacional (Jornada A)

### 6.1 Release da lib

```bash
# em #dnolib, develop → main (merge/FF) e depois, em main:
dart pub global activate melos
melos version        # bump por Conventional Commits + CHANGELOG + tag anotada vX.Y.Z
git push origin main --follow-tags
```

### 6.2 Upgrade no app

```bash
# em compras (ou vendas):
dart pub upgrade dnolib        # resolve a tag nova dentro da constraint ^0.x
flutter analyze                # gate
flutter test                   # gate
# commit no app: pubspec.lock (+ docs)
```

### 6.3 Promoção de código do app para a lib (Jornada A)

```text
1. código nasce e prova no app (lib/app/core/ ou módulo)  → analyze/testes verdes
2. mover para #dnolib (mantendo INV-AGNOSTICIDADE e a facade)
3. melos version na lib → tag vX.Y.Z → push
4. no app: dart pub upgrade dnolib → gates → apagar a cópia local → import da lib
```

O passo 4 só é disparado pela regra do segundo consumidor (§5.4) ou por decisão
explícita de alinhar o app à lib.

## 7. Plano de adoção (F0–F4) e limitações aceitas

| Fase | Escopo                                                                                     | Evidência de conclusão                                          |
| ---- | ------------------------------------------------------------------------------------------ | ---------------------------------------------------------------- |
| **F0** | Instalar melos (`dart pub global activate melos`), conferir PATH do bin, `melos --version` | `melos --version` ≥ 8.9.0                                        |
| **F1** | Push do histórico de `#dnolib` (preservando commits convencionais) → root pubspec vira workspace single-package → `melos bootstrap` → **baseline tag manual** em `main` → push com tags | `ls-remote` no Gitea com `develop`/`main` + tag `v0.1.0`          |
| **F2** | `compras` migra `path:` → `git + tag_pattern + ^0.1.0`; docs do app na mesma leva           | `flutter analyze` 0 issues; 226 testes; SHA no lock; árvore limpa |
| **F3** | Ponteiros: cada repo aponta este doc no **próprio** commit de mudança                       | grep do caminho do doc nos `AGENTS.md` da frota                  |
| **F4** | `vendas`: refatoração futura para `git+tag`; remoção do fork `.dnolib`; auditoria de idioma dos md's | consumidor único `git:`, `.dnolib` fora do disco                 |

**Limitações aceitas (por descartar o repo único e o melos cross-repo):**

- Sem orquestração entre repositórios: "subir a frota" = N commits (um por app);
  automatização futura seria um script próprio, não melos.
- `updateGitTagRefs` do melos atualiza `ref:` apenas de dependentes do **mesmo**
  workspace — bump de constraint no app é manual por app.
- Sem CI ativo: um workflow herdado no app era garantidamente quebrado (pin de SDK incompatível
  com a constraint) e foi removido em 2026-10-06. O gate é o suite local do app somado aos gates
  de toolchain do app (pin/lock/override/identidade de tag, com prova negativa versionada).
- `dependencyOverridePaths` (Jornada B) permanece disponível mas **não adotado**.

## 8. Ponteiros e documentação relacionada

- `#dnolib/AGENTS.md` — seção **Docs** aponta este documento.
- `compras/AGENTS.md` — seção de toolchain/versionamento referencia a migração
  `path` → `git+tag` (atualizado no commit da F2).
- `compras/LEARNINGS.md` / `HANDOFF.md` — entrada e estado da migração (F2).
- `vendas` — referencia a este doc quando refatorar para a `#dnolib` (F4).

**Fontes consultadas**: pub.dev/workspaces (Dart ≥3.9), pub.dev/guides
(dependências git com `tag_pattern`), melos.dev (install, bootstrap, version,
configuration, automated-releases) — versão alvo melos 8.9.0.
