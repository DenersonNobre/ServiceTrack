# Plano de Implementação: Synapx integrado à dnolib

> **Status:** Plano Arquitetural Executável (Revisado — v2.1.0)  
> **Versão:** 2.1.0  
> **Data:** 2026-11-18  
> **Target:** `dnolib` (Dart 3.x+ / Flutter 3.x+)  
> **Referências:** `docs/synapx/synapx-conceito-arquitetura.md`, `docs/synapx/synapx-consideracoes-dnolib.md`, `docs/synapx/synapx-analise-plano.md`, `docs/decisao-001.md`, `AGENTS.md`

---

## 1. Diretrizes Inegociáveis de Design

Para que o **Synapx** faça parte da `dnolib` sem gerar débito técnico ou quebrar o ecossistema, seis barreiras arquiteturais mecânicas são impostas:

1. **Respeito Absoluto à INV-AGNOSTICIDADE (`test/core/core_is_agnostic_test.dart`)**:
   - `lib/core/**` contém apenas Dart puro (zero dependência de `package:flutter`).
   - Evoluções em arquivos existentes do `core` (ex.: `ObservableToken` em `lib/core/patterns/observable.dart`) permanecem no lugar.
   - Todo código novo do Synapx vive em `lib/synapx/` (decisão §6).
2. **Evolução sobre `Observable` (Zero Duplicação de Vocabulário)**:
   - Não criar tipo concorrente isolado. Primitivas `Rx` evoluem ou atuam como alias/extensão de `Observable<T>`.
   - Reaproveitar `Debouncer<T>`, `Command`, `LazyProxy<T>` e `ObservableToken<T>`.
3. **Zero Singletons ou Pilhas Estáticas Globais**:
   - Rastreamento reativo (`RxTracker`) opera por **instância explícita** associada a `Zone` local (`Zone.current[_trackerZoneKey]`), nunca por pilha estática mutável global.
   - DI e ciclo de vida vinculados a instâncias de `ModuleScope` atreladas à árvore de widgets/rotas, sem variáveis estáticas mutáveis globais.
4. **Jornada A e Regra do Segundo Consumidor (`decisao-001` §§5.4 e 6.3)**:
   - Workers, `Disposable` e `ModuleScope` nascem e são provados primeiro no app consumidor (`.modelo` ou `compras`) antes de serem promovidos para a `dnolib`. O protótipo `vendas/lib/core/modular/module.dart` (em uso por 7 módulos) é o candidato S0, promovido com split agnóstico + qualificadores + `Disposable` (ver §5.1).
5. **Governança por Gates Mecânicos e Commits por Slice**:
   - Cada slice (`0.1a`, `0.1b`, `0.1c`, `0.2`) gera **commit próprio**, com ciclo **Red-Before-Green**, `puro flutter analyze --fatal-infos lib test`, `puro flutter test`, `puro dart format --output=none --set-exit-if-changed lib test`, atualização de `test/facade_test.dart` e entrada em `LEARNINGS.md` no **mesmo commit**.
6. **Synapx como submódulo-irmão (decisão do mantenedor)**:
   - Implementação em `lib/synapx/`, com barrel `lib/synapx/synapx.dart` exportado pela facade `lib/dnolib.dart` (precedente: `brlib`/`rest`/`sqlite`/`widgets`; consumidor corta com `show`/`hide`).
   - Topologia interna por papel: `src/reactive/`, `src/lifecycle/`, `src/routing/` (+ widgets da família no `src/`).
   - Direção única de dependência: `synapx → core` (e `synapx → widgets` somente se precisar de adapter; nunca o inverso, sem ciclo).
   - **Um único arquivo com `package:flutter/material`**: `lib/synapx/src/widgets/synapx_app.dart` (wrapper estilo app). Todo o resto do módulo em Dart puro. `SynapxScope`, `ScopeWidget` e o adapter de rotas moram em `synapx/` (coesão da família).

---

## 2. Mapa de Fatiamento e Entregas

```mermaid
flowchart TD
    subgraph S0["Pré-requisito: Protótipo Jornada A (App Consumidor)"]
        F0A["Provar workers + Disposable/ModuleScope no app"]
    end

    subgraph S1["Fase 0.1a: Token (core), Coleções & Workers (synapx)"]
        F1A1["Evolução ObservableToken (onCancel, isolamento de erro)"]
        F1A2["RxList / RxMap via ListBase/MapBase + batch sem vazamento"]
        F1A3["Workers puros: ever, once, debounceRx, intervalRx"]
    end

    subgraph S2["Fase 0.1b: Rastreamento por Zone & UI Reativa (synapx)"]
        F1B1["RxTracker por instância via Zone (síncrono)"]
        F1B2["SynapxScope (StatefulWidget) em synapx/"]
        F1B3["Testes de isolamento concorrente e FakeAsync"]
    end

    subgraph S3["Fase 0.1c: Lifecycle & Escopo Mínimo (synapx)"]
        F1C1["Contrato Disposable & CompositeDisposable"]
        F1C2["ModuleScope com chave (Type, name?) e ownership explícito"]
        F1C3["ScopeWidget (Stateful + Inherited) & ScopeRouteObserver"]
    end

    subgraph S4["Fase 0.2: Adapter Modular de Rotas & Guards (synapx)"]
        F2A1["Adapter fino sobre RouterConfig/go_router com ModuleScope"]
        F2A2["RouteGuard assíncrono (sealed GuardResult) + matriz de bordos"]
    end

    S0 --> S1
    S1 --> S2
    S2 --> S3
    S3 --> S4
```

---

## 3. Detalhamento das Fases

---

### FASE 0.1a — Motor Reativo v2: `ObservableToken`, Coleções e Workers

#### 3.1. Evolução de Contrato em `Observable<T>` e `ObservableToken<T>`
**Localização:** `lib/core/patterns/observable.dart` (arquivo existente do `core`)  
**Motivação (`B2`):** Hoje `ObservableToken.cancel()` apenas remove o token de `_tokens` e `_notify()` não isola exceções de listeners.  
**Contrato de Implementação:**
- Adicionar callback opcional `void Function()? _onCancel` em `ObservableToken<T>`, invocado **no máximo uma vez** tanto em `cancel()` quanto em `_invalidate()` (via `Observable.dispose()`).
- Em `Observable.on(listener, {void Function()? onCancel})` (ou construtor interno usado pelos workers), registrar o gancho de limpeza para que `token.cancel()` desligue `Timer`s ou subscrições encadeadas.
- **Isolamento de erro em `_notify()`**: cada invocação `token._notify(_value)` deve ser protegida (`try/catch` encaminhando para `Zone.current.handleUncaughtError(e, st)` ou handler configurável) para que uma exceção em um worker/listener não interrompa os demais assinantes do mesmo `Observable`.
- **Semântica de `once()`**: o worker cancela o próprio token **antes** de executar `callback(value)` (protegido pela iteração sobre `List.of(_tokens)`), garantindo disparo único mesmo em mutações reentrantes dentro do callback.
- Usar Conventional Commits (`feat!:` ou `feat:`) para que o `melos version` gere automaticamente a entrada correspondente no `CHANGELOG.md` na release (`decisao-001` §6.1).

#### 3.2. Semântica de `RxList<E>` e `RxMap<K, V>`
**Localização:** `lib/synapx/src/reactive/synapx_collections.dart`  
**Motivação (`B3`):** Implementar `List<E>` diretamente exige ~40 delegações manuais; `batch` recebendo `_internalList` vaza referência mutável para fora do controle de notificação; e `Observable.value=` usa `==` por identidade.  
**Contrato de Implementação:**
- **Composição via `dart:collection`**:
  - `RxList<E>` utiliza `ListBase<E>` (implementando `length`, `length=`, `operator []`, `operator []=`) envolvendo a lista interna encapsulada, e sobrescreve explicitamente os mutadores em lote (`add`, `addAll`, `insert`, `insertAll`, `remove`, `removeAt`, `removeLast`, `removeWhere`, `retainWhere`, `clear`, `sort`, `shuffle`, `setRange`, `fillRange`, `replaceRange`, `setAll`) para emitir **uma única notificação** por chamada quando houver alteração efetiva.
  - `RxMap<K, V>` utiliza `MapBase<K, V>` com o mesmo princípio (`[]=`, `addAll`, `addEntries`, `remove`, `removeWhere`, `clear`, `update`, `updateAll`).
- **Semântica de `distinct` / no-op em coleções**:
  - Mutações bem-sucedidas sempre notificam (não dependem de `==` de referência da lista).
  - Operações no-op (ex.: `remove(ausente)`, `clear()` em coleção já vazia, `[]=` com mesmo valor `==`) **não** disparam notificação.
- **`batch` sem vazamento de referência interna**:
  - `void batch(void Function(RxList<E> list) action)` (e análogo para `RxMap`) usa contador `_batchDepth` e flag `_dirty` em bloco `try/finally`:
    ```dart
    void batch(void Function(RxList<E> list) action) {
      _batchDepth++;
      try {
        action(this);
      } finally {
        _batchDepth--;
        if (_batchDepth == 0 && _dirty) {
          _dirty = false;
          _notify();
        }
      }
    }
    ```
  - A lista interna **nunca** é exposta ao chamador; chamadas externas via `RxList` após o `batch` continuam notificando normalmente.
- **Teste de contrato obrigatório**: exercitar **cada** método mutador da lista/mapa (incluindo `length=`, `sort`, `shuffle`, `setRange`, `fillRange`, `replaceRange`) e casos no-op, provando quando notifica e quando não notifica.

#### 3.3. Workers Funcionais Puros
**Localização:** `lib/synapx/src/reactive/synapx_effect.dart`  
**Contrato de Implementação:**
- Funções puras sobre qualquer `Observable<T>` devolvendo `ObservableToken<T>` descartável (reaproveitando `Debouncer<T>` de `lib/core/patterns/debouncer.dart`):
  ```dart
  ObservableToken<T> ever<T>(Observable<T> rx, void Function(T value) callback);
  ObservableToken<T> once<T>(Observable<T> rx, void Function(T value) callback);
  ObservableToken<T> debounceRx<T>(
    Observable<T> rx,
    void Function(T value) callback, {
    required Duration duration,
  });
  ObservableToken<T> intervalRx<T>(
    Observable<T> rx,
    void Function(T value) callback, {
    required Duration duration,
  });
  ```
- `ever` e `once` **não** disparam com o valor corrente na assinatura (sem replay, mantendo o contrato de `Observable.on`).
- `intervalRx` adota semântica explícita de **throttle em janela fixa**: dispara no primeiro evento e ignora novos eventos até transcorrer `duration`.
- O `onCancel` do token retornado cancela o `Debouncer` / `Timer` interno imediatamente.
- **Testes de barreira obrigatórios**:
  - `token.cancel()` impede chamadas tardias e zera timers pendentes.
  - Testes sob `FakeAsync` com `elapse`/`flushTimers` explícitos para `debounceRx` e `intervalRx`.

---

### FASE 0.1b — Rastreamento por Instância (`Zone`) & UI Reativa

#### 3.1. `RxTracker` Puro por Instância (Zero Estado Global)
**Localização:** `lib/synapx/src/reactive/synapx_tracker.dart`  
**Motivação (`B1`):** Pilha estática mutável global contamina testes concorrentes e viola a diretriz anti-global.  
**Contrato de Implementação:**
- Cada rastreamento instancia um `RxTracker` local, vinculado exclusivamente à execução síncrona via `Zone`:
  ```dart
  final class RxTracker {
    RxTracker();

    static final Object _zoneKey = Object();

    /// Retorna o tracker ativo na Zone corrente, ou null fora de escopo.
    static RxTracker? get current => Zone.current[_zoneKey] as RxTracker?;

    /// Executa [computation] de forma síncrona registrando cada [Observable] lido.
    T track<T>(T Function() computation, void Function(Observable<dynamic>) onRead) {
      ...
    }

    void recordRead(Observable<dynamic> observable) { ... }
  }
  ```
- **Invariante síncrona explícita**: `track` suporta apenas computações síncronas (como `Widget.build`). Se `computation` disparar trabalho assíncrono (`Future`/`Timer`), callbacks posteriores fora do frame síncrono não capturam leituras acidentalmente, pois a referência `RxTracker` pertence apenas à `Zone` da computação síncrona (e é desativada ao fim do `track` via flag `_active = false` em `finally`).
- No getter `Observable.value`, apenas consulta `RxTracker.current?.recordRead(this)` — custo O(1) nulo fora de `SynapxScope`.
- **Teste de barreira obrigatório**: dois `RxTracker`s aninhados/sobrepostos e execução concorrente com observáveis distintos não misturam dependências.

#### 3.2. Widget Observador em `synapx/`
**Localização:** `lib/synapx/src/widgets/synapx_scope.dart`  
**Contrato de Implementação:**
- `SynapxScope` (`StatefulWidget`) mantém uma instância própria de `RxTracker`:
  1. No `build()`, executa `builder(context)` dentro de `_tracker.track(...)`.
  2. Calcula o delta entre o conjunto anterior e o novo de `Observable`s lidos: cancela tokens de observáveis não mais lidos e assina apenas os novos.
  3. Dispara `setState()` quando qualquer observável assinado notificar (guardando `mounted`).
  4. No `dispose()`, cancela todos os `ObservableToken`s ativos.
- O `observable.watch(...)` explícito permanece como API canônica; `SynapxScope` atua como conveniência opt-in auditável.
- **Teste de barreira obrigatório (`testWidgets`)**: alterar um `Observable` **não** lido dentro do `builder` não provoca rebuild; deixar de ler um `Observable` condicional cancela sua assinatura no frame seguinte.

---

### FASE 0.1c — Contratos de Ciclo de Vida & Escopo Mínimo

#### 3.1. `Disposable` e `CompositeDisposable`
**Localização:** `lib/synapx/src/lifecycle/synapx_disposable.dart`  
**Contrato de Implementação:**
- Interface pura:
  ```dart
  abstract interface class Disposable {
    void dispose();
  }
  ```
- `CompositeDisposable implements Disposable`: agrupa `Disposable`s, `ObservableToken`s e `Timer`s (via wrapper interno ou `addCallback(void Function())`) para descarte atômico e idempotente em ordem reversa de registro.

#### 3.2. `ModuleScope` Hierárquico com Qualificador e Ownership
**Localização:** `lib/synapx/src/lifecycle/synapx_module_scope.dart`  
**Motivação (`M1`):** `get<T>()` só por tipo gera colisão; `registerInstance` pode descartar objeto alheio; filho não pode descartar registro do pai.  
**Contrato de Implementação:**
- Chave de registro composta por `(Type, String? name)` (record Dart 3).
- Reuso de `LazyProxy<T>` (`lib/core/patterns/lazy_proxy.dart`) para `registerLazySingleton`, rastreando se a instância já foi materializada antes de tentar chamar `dispose()` — um lazy singleton nunca acessado **não** é instanciado durante o `dispose()`.
- Factories recebem o escopo (`T Function(ModuleScope scope)`), permitindo composição — como no protótipo `vendas` (`T Function(Injector i)`).
- Controle explícito de *ownership*:
  ```dart
  class ModuleScope implements Disposable {
    ModuleScope({this.parent});

    final ModuleScope? parent;

    T get<T>({String? name});
    T? tryGet<T>({String? name});
    void registerFactory<T>(T Function(ModuleScope scope) factory, {String? name});
    void registerLazySingleton<T>(T Function(ModuleScope scope) factory, {String? name});
    void registerInstance<T>(T instance, {String? name, bool owned = false});

    @override
    void dispose();
  }
  ```
- **Regra pai-filho**: `get<T>` busca localmente em `(T, name)` e, se ausente, delega a `parent?.get<T>(name: name)`. Ao chamar `dispose()` no filho, descarta **exclusivamente** os registros criados com `owned: true` (factories/lazy singletons locais e instâncias marcadas como `owned: true`), em ordem reversa, **preservando integralmente** o escopo `parent`.

#### 3.3. Integração com Árvore Flutter e Ciclo de Rota
**Localização:** `lib/synapx/src/widgets/synapx_provider.dart`  
**Motivação (`M2`):** `InheritedWidget` puro não possui gancho de desmontagem nem de rota.  
**Contrato de Implementação:**
- `ScopeWidget` é um `StatefulWidget` que gerencia o ciclo do `ModuleScope` e provê o acesso via um `_ScopeInherited` (`InheritedWidget`) interno:
  - Aceita `create: (BuildContext) => ModuleScope` (com `ownsScope: true`) ou `value: ModuleScope` (com `ownsScope: false`).
  - Descarta `scope.dispose()` em `State.dispose()` apenas quando `ownsScope == true`.
  - Preserva a instância do `ModuleScope` durante `reassemble()` (hot reload).
- `ScopeRouteObserver` (`NavigatorObserver` / `RouteAware`): especifica explicitamente assinatura em `didChangeDependencies` e cancelamento em `dispose`, cobrindo `pop`, `pushReplacement`, remoção de pilha por deep-link e cancelamento durante guard.
- **Teste de fuga obrigatório (`test/synapx/scope_leak_test.dart`)**: executa `N` ciclos de `push`/`pop` e `pushReplacement` (incluindo caminho de erro) e comprova contagem de listeners e `Timer`s pendentes igual a `0`.

---

### FASE 0.2 — Adapter Modular de Rotas & Guards

#### 3.1. Adapter sobre Roteador Existente (`M3`)
**Localização:** `lib/synapx/src/widgets/synapx_route_scope.dart`  
**Decisão arquitetural (`M3`):** Como a casa estabelece que o app define sua navegação (ex.: `RouterConfig` / `go_router`), a Fase 0.2 **não** reimplementa um `RouterDelegate` completo concorrente. Fornece um **adapter fino** (`ScopeRouteBuilder` / `RouteGuardRunner`) que acopla `ModuleScope` e `RouteGuard` a rotas declaradas sobre o `RouterConfig` do app.

#### 3.2. Contratos de `RouteContext`, `GuardResult` e `RouteGuard`
**Localização:** `lib/synapx/src/routing/synapx_route_guard.dart`
```dart
class RouteContext {
  const RouteContext({
    required this.uri,
    this.pathParameters = const {},
    this.queryParameters = const {},
    this.extra,
    this.scope,
  });

  final Uri uri;
  final Map<String, String> pathParameters;
  final Map<String, String> queryParameters;
  final Object? extra;
  final ModuleScope? scope;
}

sealed class GuardResult {
  const GuardResult();
}

final class GuardAllow extends GuardResult {
  const GuardAllow();
}

final class GuardReject extends GuardResult {
  const GuardReject([this.reason]);
  final String? reason;
}

final class GuardRedirect extends GuardResult {
  const GuardRedirect(this.target);
  final Uri target;
}

abstract interface class RouteGuard {
  Future<GuardResult> canActivate(RouteContext context);
}
```
- **Executor (`RouteGuardRunner`, em `lib/synapx/src/routing/route_guard_runner.dart`)**: suporta execução sequencial de guards, `timeout` configurável por guard, detecção de **loop de redirect** (`A → B → A` com limite de saltos / histórico de URIs visitadas) e cancelamento seguro em caso de navegação concorrente (duplo tap ou `pop` durante `await`).
- **Matriz de testes obrigatória**:
  1. Autorizado (`GuardAllow`) $\rightarrow$ prossegue.
  2. Negado (`GuardReject`) $\rightarrow$ interrompe e mantém escopo intacto.
  3. Redirecionamento (`GuardRedirect`) $\rightarrow$ navega ao destino.
  4. Concorrência / duplo tap / `pop` durante guard $\rightarrow$ descarta execução obsoleta sem vazar escopo.
  5. Guard que lança exceção $\rightarrow$ tratado sem travar a navegação (falha segura configurável).
  6. Guard com timeout $\rightarrow$ interrompe dentro do SLA configurado.
  7. Redirect loop (`A → B → A`) $\rightarrow$ detectado e interrompido com erro explícito.

---

## 4. Matriz de Verificação e Evidências

| Item | Critério de Aceite | Gate / Teste |
| :--- | :--- | :--- |
| **Red-Before-Green por Fase** | Todo teste novo comprova falha (Red) antes da implementação (Green). | Registro por fase no commit/PR |
| **Agnosticidade de Core** | Zero menções a `package:flutter` em `lib/core/**` (com prova negativa). | `test/core/core_is_agnostic_test.dart` |
| **Isolamento do Tracker** | Dois escopos sobrepostos/concorrentes não vazam dependências. | `test/synapx/rx_tracker_test.dart` |
| **Contrato de Coleções** | Todos os mutadores de `RxList`/`RxMap` + no-ops + `batch` testados. | `test/synapx/rx_collections_test.dart` |
| **Timers sob `FakeAsync`** | `debounceRx`/`intervalRx` testados com `fakeAsync` + `cancel()`. | `test/synapx/rx_workers_test.dart` |
| **Sem Fuga de Memória** | `N` ciclos `push`/`pop`/`replace` e erro zeram listeners e `Timer`s. | `test/synapx/scope_leak_test.dart` |
| **Integridade da Facade** | Barrel `lib/synapx/synapx.dart` exportado em `lib/dnolib.dart`; símbolos instanciados. | `test/facade_test.dart` |
| **Qualidade e Estilo** | Zero advertências/infos com flags estritas. | `puro flutter analyze --fatal-infos lib test` |
| **Formatação Canônica** | Zero drift de formatação. | `puro dart format --output=none --set-exit-if-changed lib test` |

---

## 5. Ordem Executiva de Aplicação (Jornada A + Slices Atômicos)

1. **Protótipo Jornada A (App Consumidor)**: validar workers sobre `Observable` e `Disposable`/`ModuleScope` no app consumidor (`.modelo` ou `compras`) antes de abrir branch na `dnolib`. Base existente: protótipo `vendas/lib/core/modular/module.dart` (7 módulos em uso); promoção exige split agnóstico (`Injector`/`Bind`/`ScopeInjector` puros → `lib/synapx/`; `ModuleRoute.toRoute` via `RouteFactory` injetada no lugar do `AppPageRoute` concreto), qualificador `(Type, name?)`, `tryGet`, fail-fast em bind duplicado e testes Red (contrato + fuga) inexistentes no protótipo.
2. **Slice `0.1a` (Commit 1)**: criar barrel `lib/synapx/synapx.dart` + `src/` por papel; evoluir `ObservableToken`/`Observable._notify` no `core` (`onCancel`, `once`, isolamento de erro); implementar `RxList`, `RxMap` (`ListBase`/`MapBase` + `batch`) e workers puros (`ever`, `once`, `debounceRx`, `intervalRx`) em `lib/synapx/src/reactive/`. Rodar todos os gates + atualizar `test/facade_test.dart` + `LEARNINGS.md` (deixando o `CHANGELOG.md` a cargo do `melos version`).
3. **Slice `0.1b` (Commit 2)**: implementar `RxTracker` por instância via `Zone` e `SynapxScope` em `lib/synapx/src/` com testes de isolamento e `testWidgets`. Rodar todos os gates + `test/facade_test.dart` + `LEARNINGS.md`.
4. **Slice `0.1c` (Commit 3)**: implementar `Disposable`, `CompositeDisposable`, `ModuleScope` (chave `(Type, name?)`, factories com escopo, ownership) e `ScopeWidget`/`ScopeRouteObserver` em `lib/synapx/src/` com teste de fuga `push`/`pop`. Rodar todos os gates + `test/facade_test.dart` + `LEARNINGS.md`.
5. **Slice `0.2` (Commit 4)**: implementar adapter fino de rotas (`RouteContext`, `GuardResult`, `RouteGuardRunner`) em `lib/synapx/src/routing/` com a matriz completa de 7 cenários de teste. Rodar todos os gates + `test/facade_test.dart` + `LEARNINGS.md`.
