# Análise do Plano de Implementação Synapx

> **Status:** Análise técnica / revisão de plano
> **Data:** 2026-11-18
> **Alvo:** `docs/synapx/synapx-plano-implementacao.md` v1.0.0
> **Referências:** `docs/synapx/synapx-conceito-arquitetura.md`, `docs/synapx/synapx-consideracoes-dnolib.md`, `AGENTS.md`, `docs/decisao-001.md`
> **Base de código verificada:** `lib/core/patterns/observable.dart`, `lib/core/patterns/debouncer.dart`, `lib/core/patterns/lazy_proxy.dart`, `lib/core/patterns/event_bus.dart`, `lib/core/patterns/result.dart`

## 1. Veredito

Direção correta — o fatiamento `0.1a → 0.1b → 0.1c → 0.2` segue a recomendação das
considerações (§7.6), a separação `core` puro / `widgets` Flutter respeita a
INV-AGNOSTICIDADE e os workers como funções puras reaproveitam o vocabulário
existente (`ObservableToken`, `Debouncer`, `Command`). Porém o plano **subestima
4 pontos e se contradiz em 1**: precisa de revisão nos itens B1–B3 antes de virar
código. M1–M4 podem entrar como emendas na mesma revisão.

## 2. O que está bom (manter)

- Fatiamento em 4 fases com dependência linear (`S1 --> S2 --> S3 --> S4`).
- Localização correta: reativo puro, coleções, `Disposable` e workers em
  `lib/core/patterns/`; `SynapxScope`, `ScopeWidget`, rotas e guards em
  `lib/widgets/src/`.
- Reaproveitamento explícito: `Debouncer<T>`, `Command`, `ObservableToken`,
  `LazyProxy` — sem reinventar o que existe.
- Matriz de verificação (§4) com os gates certos: agnosticidade, facade,
  leak test, `analyze`, `format`.

## 3. Achados bloqueadores

### B1 — `RxTracker` estático viola a diretriz anti-global do próprio plano

O §1.3 do plano proíbe "variáveis estáticas mutáveis globais", mas o §3.1 da
Fase 0.1b especifica:

```dart
static void recordRead(Observable observable);
static T track<T>(T Function() computation, void Function(Observable) onRead);
```

Pilha estática mutável **é** o singleton proibido. Consequências medidas pelo
histórico da casa:

- Dois `track()` sobrepostos (teste concorrente, `testWidgets` + `test()` no
  mesmo isolate) se contaminam — o mesmo defeito documentado para locks e cursores
  compartilhados.
- Todo `rx.value` paga uma checagem de pilha, mesmo fora de qualquer escopo.
- Se o `build` fizer `await` no meio, a pilha síncrona desenrola e o registro
  perde dependências — o contrato precisa declarar "computação síncrona apenas".

**Fix exigido:** `track` como instância explícita (objeto de escopo ou `Zone`),
nunca estático global. Teste de barreira: dois escopos sobrepostos com
dependências distintas não se misturam. Sem isso, o "teste puro sem pump" do
Pilar IV é falso.

### B2 — Workers exigem mudança quebrada em `ObservableToken`, não especificada

O plano promete que `token.cancel()` "cancela qualquer `Timer` ou subscrição
subjacente". Verificação contra a implementação (`lib/core/patterns/observable.dart:36-43`):

- `cancel()` hoje só remove o token da lista — **não existe hook de cancelamento**.
- `debounceRx`/`intervalRx` precisam de um `onCancel` no token: mudança no
  contrato do núcleo.
- `once()` precisa de auto-cancelamento durante a iteração de `_notify` (hoje
  protegida por cópia com `List.of`, o que ajuda — mas precisa de teste que prove
  o auto-cancelamento no meio da notificação).
- `_notify` não tem `try/catch`: um callback de worker que lança quebra os
  demais listeners do mesmo observável.

**Fix exigido:** especificar a evolução de `ObservableToken` (hook `onCancel`,
semântica de `once` durante notify, comportamento quando o callback lança).
Tratar como mudança de API do núcleo: entrada no CHANGELOG como minor/breaking
conforme `decisao-001`, não como detalhe de implementação.

### B3 — `RxList implements List<E>` é ~40 métodos delegados; `batch` vaza referência interna

`class RxList<E> extends Observable<List<E>> implements List<E>` obriga delegar
toda a interface `List` — o plano lista 5 métodos e escreve "etc.", escondendo
~90% do trabalho (`insert`, `removeWhere`, `retainWhere`, `sort`, `shuffle`,
`clear`, `length=`, `setRange`, `fillRange`, `replaceRange`, `sort` etc.).

Pior: o `batch` proposto entrega a lista interna viva ao chamador:

```dart
void batch(void Function(List<E> list) action) {
  action(_internalList); // o chamador pode guardar a referência e mutar depois sem notificar
  notifyListeners();
}
```

**Fix exigido:** decidir e escrever no contrato antes de codar — composição vs
herança total; `batch` sobre cópia controlada ou API fechada; semântica de
`distinct` para coleções (identidade? profundo O(n)? nunca?); teste de contrato
que exercita **cada** método mutador e prova notifica/não-notifica. É o item 1
dos "próximos passos" das considerações, ainda pendente.

## 4. Achados médios

### M1 — `ModuleScope.get<T>()` só por tipo é ambíguo; ownership indefinido

- Dois registros do mesmo tipo em módulos diferentes: `get<T>` não distingue —
  falta qualificador ou chave nomeada.
- `registerInstance` (criada fora, dono fora) sob `dispose()` em cascata pode
  descartar objeto alheio.
- Falta a regra pai-filho no dispose: descartar o filho não pode descartar o que
  veio do `parent`.

**Fix:** `get<T>({String? name})` ou chave explícita; `registerInstance` com flag
de ownership (`owned: false` por padrão); teste pai-filho (filho descarta o
próprio, preserva o do pai).

### M2 — `ScopeWidget`/`ScopeRouteObserver` sem mecânica de ciclo de vida

`InheritedWidget` não tem gancho de rota. O plano nomeia `ScopeRouteObserver`
mas não especifica assinatura/cancelamento de `RouteObserver` nem os bordos:
`pop` durante guard assíncrono, `replace`, deep-link, hot reload — exatamente
onde o vazamento mora.

**Fix:** especificar contra `Navigator 2.0` real + teste de fuga (N push/pop,
contagem de listeners/`Timer` pendentes = 0), incluindo o descarte no caminho
de erro.

### M3 — Fase 0.2 redesenha roteador sem justificativa contra o existente

"Definição de Rotas com Scope integrado ao `RouterConfig`" é uma frase para o
tamanho de um `RouterDelegate` próprio. A casa estabelece que app define
navegação; reinventar delegate compete com `go_router`/`auto_route` sem análise
build-vs-buy. `RouteContext` e `GuardResult` são usados mas nunca definidos.

**Fix:** ou amarrar `ModuleScope` a roteador existente (adapter), ou escrever a
justificativa + sketch de API antes da fase. Matriz de guards precisa de 3 casos
a mais: guard que **lança**, guard com **timeout**, **redirect loop** (A→B→A).

### M4 — Ordem executiva pula a Jornada A e condensa commits

O §5 manda implementar direto na lib e fecha com "commit atômico" singular. Isso
contraria `decisao-001` §§5.4/6.3 (código nasce no app, promove com 2º
consumidor) e a regra de commit por slice (0.1a, 0.1b, 0.1c são 3 commits + 3
entradas de LEARNINGS, não 1).

**Fix:** protótipo de workers + `Disposable`/escopo no app consumidor primeiro;
cada fase = commit próprio + gate verde + LEARNINGS na mesma unidade.

## 5. Adições à matriz de verificação

| Falta | Por quê |
|---|---|
| Red-Before-Green documentado por fase | Teste que nasce verde sem fase Red é tautológico (regra da casa) |
| Teste de `FakeAsync` para `debounce`/`interval` | `Timer` real sob `FakeAsync` exige `flush` explícito (gotcha registrado em LEARNINGS) |
| Teste de isolamento do tracker (escopos sobrepostos) | Sem ele, B1 volta como regressão silenciosa |

## 6. Ordem de revisão recomendada

1. Página de semântica de coleções (B3) — pré-requisito da 0.1a.
2. Especificação do `ObservableToken.onCancel` + `once` + erro em callback (B2).
3. Tracker por instância + teste de isolamento (B1).
4. Protótipo Jornada A no app: workers + `Disposable`/escopo mínimo (M4).
5. Emendas M1–M3 na mesma revisão do plano.
6. Só então abrir branch da 0.1a na lib.

## 7. Veredito sobre a revisão v2.0.0 (2026-11-18)

Plano revisado para **v2.0.0** e reconferido item a item contra os achados acima:
**aprovado** — B1, B2, B3 e M1–M4 endereçados (§1.3 anti-global com `RxTracker`
por instância via `Zone`; `ObservableToken._onCancel` + isolamento de erro em
`_notify`; `RxList`/`RxMap` via `ListBase`/`MapBase` com `batch` sem vazamento;
chave `(Type, name?)` com ownership; `ScopeWidget` com `ownsScope` +
`ScopeRouteObserver`; adapter fino sem `RouterDelegate` próprio com `GuardResult`
sealed e matriz de 7 cenários; pré-requisito S0 Jornada A e 1 commit por slice).

Nits residuais (não bloqueiam a 0.1a): (1) semântica de `intervalRx` ainda
indefinida (amostragem periódica vs throttle) — 1 linha no contrato da 0.1a
resolve; (2) declarar que `ever` não dispara com o valor corrente (sem replay,
como `Observable.on`); (3) prefira deixar o `melos version` gerar o
`CHANGELOG.md` em vez de editá-lo à mão.

**Atualização:** nits (1)–(3) resolvidos no plano (`bd535a1` — semântica de
`intervalRx` como throttle, `ever`/`once` sem replay declarado, CHANGELOG a
cargo do `melos version`). Plano **aprovado sem ressalvas**; próximo passo é o
protótipo Jornada A (S0) no app consumidor.

---
*Revisão solicitada sobre `docs/synapx/synapx-plano-implementacao.md` v1.0.0; não altera
código nem decisões — trilha de revisão para o mantenedor.*
