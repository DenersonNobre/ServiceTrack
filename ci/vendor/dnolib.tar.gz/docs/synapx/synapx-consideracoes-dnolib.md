# Considerações Synapx × dnolib

> **Status:** Análise técnica / RFC-resposta
> **Data:** 2026-11-18
> **Alvo:** `docs/synapx/synapx-conceito-arquitetura.md` v0.1.0-draft
> **Ponto de vista:** mantenedor da `dnolib` — agnosticidade, facade única, Jornada A

## 1. Veredito em 1 parágrafo

O Synapx acerta no diagnóstico (GetX = produtivo mas vaza escopo; Bloc/Modular = seguro
mas cerimonioso) e erra no tamanho do salto: propõe 4 pilares de uma vez, quando a
`dnolib` já cobre ~70% do Pilar I com outro vocabulário (`Observable` + `distinct`
por `==` + `Debouncer` + `Command` + `ObservableAdapter`) e rejeita por regra
escrita os dois atalhos mais caros dos Pilares II/III — **service-locator global** e
**navegação global sem `BuildContext`** (`Synapx.to(...)`). A recomendação é
**evoluir, não fundar**: (a) completar o reativo que falta (`RxList`/`RxMap`,
workers puros) sobre o `Observable` existente; (b) trocar "container DI hierárquico
+ router próprio" por um **escopo mínimo + `Disposable`** amarrado à rota, provado
primeiro no app consumidor via Jornada A; (c) adiar DevTools/CLI para depois de
2 consumidores reais (regra `decisao-001` §5.4).

## 2. O que a dnolib já tem (não duplicar)

| Synapx propõe | dnolib já entrega | Delta real |
|---|---|---|
| `Rx<T>` com `distinct` | `Observable<T>` com `==` em `core/patterns/observable.dart` (sem replay, token como `StreamSubscription`) | Falta só coleção observável + workers |
| `debounce` worker | `Debouncer<T>` em `core/patterns/debouncer.dart` | Falta amarrar `Debouncer` a `Observable.on` como função pura |
| Estado de ação assíncrona | `Command` em `core/patterns/command.dart` (`isExecuting`/`canExecute`/`result`, ignora concorrente, `mapException`) | `whenSuccess`/`whenFailure` já são o `ever` tipado para resultado |
| `ValueListenable` / rebuild cirúrgico | `ObservableAdapter` + `watch()` + `NotifierBuilder`/`AsyncButton` em `widgets/` | Falta só o tracking transparente (ler `.value` no `build` e assinar sozinho) |
| `LazySingleton` | `LazyProxy<T>` em `core/patterns/lazy_proxy.dart` | Falta escopo + descarte, não o lazy em si |
| Eventos sem valor corrente | `EventBus` broadcast em `core/patterns/event_bus.dart` | Nada a fazer; manter separado de `Observable` |

Consequência: o Pilar I não é "motor novo" — é **Observable v2**. Criar `Rx<T>`
paralelo a `Observable<T>` gera dois vocabulários para o mesmo pattern (o mesmo
erro que o LEARNINGS de 2026-10-02 documenta para `subscribe` vs `on`). Se o nome
`Rx` for desejado por DX, que seja **alias/evolução**, nunca classe irmã.

## 3. Pilar I (Reativo) — aproveitar com 4 condições

1. **Manter INV-AGNOSTICIDADE: núcleo puro + binding Flutter.** O gate
   `test/core/core_is_agnostic_test.dart` reprova qualquer `import package:flutter`
   sob `lib/core`. Logo o tracking (`SynapxScope`/`SynapxObserver`) precisa de
   duas camadas: (a) `core`: registro de dependências lidas + `notify` (Dart puro,
   testável com `test()` sem pump); (b) `widgets`: o `State` que empilha o contexto
   e faz rebuild. Pilha reativa **global mutável** é o ponto de maior risco:
   teste concorrente e `FakeAsync` (cf. LEARNINGS 2026-10-02 — isolate do SQLite
   + `testWidgets` trava) exigem escopo explícito (objeto ou `Zone`), nunca
   singleton global implícito. Sem isso, o teste "puro sem pump" prometido no
   Pilar IV é falso.
2. **`RxList`/`RxMap`: definir semântica de mutação antes de codar.** Hoje
   `Observable.value=` compara com `==` — para `List` isso é identidade, então
   `lista.add(x)` sem `value=` novo nunca notifica. O Synapx precisa decidir e
   documentar: (a) API mutadora que notifica (`add`/`[]=` sobrescritos chamam
   `_notify`), (b) `distinct` profundo opcional (custo O(n)), (c) ou imutabilidade
   (`value = [...value, x]`). Cada escolha tem teste de contrato distinto; a
   proposta atual não escolhe.
3. **Workers como funções puras sobre `Observable.on`, não métodos de `Rx`.**
   `ever/once/debounce/interval` devolvem o token (`ObservableToken`) e o
   chamador descarta — isso reaproveita `Debouncer`/`Timer`, mantém `core` sem
   `Timer` escondido dentro do valor e evita mimetizar a API do GetX (que o repo
   deliberadamente abandonou). `interval` e `debounce` criam `Timer`: o retorno
   **precisa** ser descartável e o descarte precisa de teste (token inativo não
   dispara).
4. **Tracking transparente é açúcar, não fundamento.** O `watch()` explícito atual
   (`observable.watch((ctx, v) => ...)`) é verboso mas previsível e auditável pelo
   gate da facade. O tracking automático ("reage ao `.value` lido no frame") reduz
   boilerplate mas esconde dependência — debug de "por que rebuildou?" fica mais
   difícil. Sugestão: oferecer os dois, com o explícito como canônico e o
   transparente como conveniência opt-in, nunca o único caminho.

## 4. Pilar II (DI hierárquica) — o ponto de maior atrito

- **A dnolib não tem container por decisão, não por falta.** `AGENTS.md` e
  `decisao-001`: app define estado/navegação; lib é agnóstica; `Singleton` global
  é o antipattern GetX que motivou a lib. Um `SynapxModule` com catálogo
  `Singleton/LazySingleton/Factory` + resolução ancestral reintroduz o
  service-locator, agora com herança — o teste de widget volta a depender de
  estado global oculto em vez de injeção explícita por construtor (o padrão que
  fez o `example/` rodar em 4s com `FakeCustomerRepository`).
- **Se fizer, fazer mínimo e amarrado à rota.** O que falta de verdade não é um
  framework DI, é um contrato de descarte: `Disposable` (`dispose()`) +
  `Scope` que guarda instâncias do módulo e descarta em cascata no `pop`/`remove`
  da rota. `LazyProxy` já resolve o lazy; `Factory` é só "chame a closure". Não
  criar catálogo com 3 lifetimes antes de provar que o descarte em cascata
  funciona contra `Navigator 2.0` real (pop, replace, deep-link) sem vazar
  `Timer`/`StreamController`.
- **Auto-dispose precisa de prova de fuga, não de promessa.** O doc afirma
  "elimina vazamento" — isso se prova com teste que abre/fecha a rota N vezes e
  conta listeners/`Timer` pendentes, inclusive no caminho de erro (guard que
  cancela no meio). Sem esse teste, é declaração (cf. global_learnings: gate que
  valida declaração passa com capacidade morta).

## 5. Pilar III (Router) — adiar a fundação, fatiar o valor

- **Lugar errado se for para `core`.** `RouterConfig`/Navigator 2.0 é Flutter —
  mora em `widgets/`, nunca em `core`. Isso já divide o pilar em dois pacotes e
  dois gates.
- **`Synapx.to('/vendas/novo')` global é dívida disfarçada de DX.** Navegação sem
  `BuildContext` exige `GlobalKey<NavigatorState>` ou `RouterDelegate` singleton:
  quebra injeção explícita, dificulta teste (é preciso bootar o delegate real) e
  conflita com deep-link/Web onde a URL é fonte de verdade, não um comando
  imperativo. Preferir API que recebe o delegate/estado por parâmetro ou
  `BuildContext`; o açúcar global, se existir, deve ser fina camada opcional.
- **Guards assíncronos são o único valor novo — e o mais difícil.** Ordem
  sequencial, redirect, cancelamento e suspensão até auth: cada um é um caso de
  borda (duplo tap, pop durante guard, deep-link com guard pendente). Fatiar:
  primeiro rotas modulares + `Disposable` amarrado à rota **sem** guard; guards
  só depois, com matriz de teste (autorizado/negado/redirect/erro/timeout).
- **`code-splitting/lazy loading` não prometer.** Em Flutter isso é
  `deferred-components`, com suporte parcial por plataforma e custo de tooling
  alto. Manter fora do RFC até haver app que precise.

## 6. Pilar IV (Testes) — o mais alinhado, com 1 correção

`createScope()` + overrides declarativos + drivers de `Rx` sem pump é exatamente
a filosofia atual (DIP + fakes em memória + `test()` puro fora de `testWidgets`).
Correção única: **overrides por construção, não por global.** `createScope(fakes:
{...})` que recebe os fakes no construtor do escopo é testável e paralelo;
`Synapx.override(...)` global antes do teste é o mesmo singleton do Pilar II e
vaza entre testes. E registrar o gotcha `FakeAsync` no doc do Pilar IV: driver
reativo com `debounce`/`interval` usa `Timer` real — sob `FakeAsync` precisa de
`fakeAsync.flush` explícito, documentado com exemplo.

## 7. Transversais (regras da casa que o RFC precisa respeitar)

1. **Facade única + `show`/`hide`.** Nada de pacote `synapx` separado nem módulo
   fora da facade. Reativo vai para `core/patterns`, binding para `widgets/`,
   exatamente como `Observable` → `ObservableAdapter`.
2. **Regra do arquivo único.** `Money` foi fundido em `core/models` porque um
   arquivo não justifica diretório; `Document` seguiu igual. Não criar
   `lib/synapx/` com 1–2 arquivos.
3. **Identificadores em inglês, docs em pt-BR.** `SynapxScope`, `RouteGuard`,
   `Disposable` OK; mensagens de commit em inglês (padrão da casa).
4. **Jornada A + regra do segundo consumidor.** Código reativo/escopo nasce no app
   (`.modelo` ou `compras`), prova com 2 consumidores, só então promove para a
   lib (`decisao-001` §5.4/§6.3). Não fundar Pilar II/III na lib sem app pedindo.
5. **Gates antes de feature.** `puro flutter analyze --fatal-infos lib test` +
   `puro flutter test` + `dart format` verdes; novo símbolo exportado exige
   asserção em `test/facade_test.dart`; novo `core` puro exige o gate de
   agnosticidade verde (com prova negativa: inserir `import flutter` e ver
   reprovar).
6. **Roadmap realista.** v0.1 do RFC mistura reativo + DI + lifecycle — 3 slices
   em 1 rótulo. Proposta: `0.1a` Observable v2 (coleções + workers puros);
   `0.1b` `Disposable` + escopo mínimo amarrado à rota; `0.2` router modular sem
   guards; `0.3` guards; DevTools e CLI **pós-1.0** (custo alto, zero consumidor
   hoje).

## 8. Próximos passos sugeridos (ordenados)

1. Especificar semântica de `RxList`/`RxMap` (§3.2) em 1 página antes de qualquer
   código.
2. Prototipar workers como funções puras sobre `Observable` **no app** (Jornada A),
   com teste de descarte de `Timer`.
3. Definir `Disposable` + escopo mínimo e provar descarte em cascata contra
   `Navigator 2.0` real com teste de fuga (N push/pop, conta pendentes).
4. Só então decidir: evoluir `Observable` vs alias `Rx`, e se guards entram no
   `0.2` ou ficam para depois.
5. Registrar cada passo no `LEARNINGS.md` no commit da mudança (regra da casa),
   nunca "depois".

## 9. O melhor do GetX e do flutter_modular sem as armadilhas (2026-11-19)

Diretriz do mantenedor: implementar o melhor dos dois, recusando os atalhos que
os condenam. Mapeamento vigente (verificado contra o código):

| Melhor de cada um | Status Synapx | Armadilha recusada + trava |
|---|---|---|
| GetX: `Obx`, Rx + workers, `put/lazyPut/find`, `Bindings` | ✅ `SynapxScope`/`watch`, `RxList`/`RxMap` + 4 workers, `ModuleScope` + `SynapxModule` | Service-locator global e singletons zumbis → sem `find` global; ownership + descarte em cascata + teste de fuga |
| GetX: `toNamed` sem context, snackbar/dialog globais | ❌ recusado / parcial (`SynapxDialogsX` exige `BuildContext`) | Navegador global intestável → sem açúcar global; helpers só com contexto explícito |
| Modular: módulo = binds + rotas, hierarquia, guards, `AutoDispose` | ✅ `SynapxModule` + `ModuleScope(parent)`, `RouteGuard` sealed + `Runner` (timeout, geração, anti-loop) | Cerimônia por página e lock-in no `RouterDelegate` → regra do 2º consumidor; adapter fino, sem reimplementar roteador |

**Não-objetivos deliberados** (completar por iniciativa própria reintroduz a
armadilha): `GetMaterialApp` próprio, navegação global sem contexto (`to`),
matching de URL/wildcards no Synapx (parsing é do router do app). Pós-1.0
adiado por decisão: DevTools e CLI.

---
*Análise solicitada sobre `docs/synapx/synapx-conceito-arquitetura.md`; não altera código
nem decisões — RFC-resposta para discussão do mantenedor.*
