# Plano de Execução: Ergonomia, Identidade e Redução de Verbosidade do Synapx

> **Status:** Concluído (E0–E3 entregues em `develop`)  
> **Versão:** 0.2.0  
> **Data:** 2026-11-19  
> **Target:** `dnolib` (Dart 3.x+ / Flutter 3.x+) — módulo `lib/synapx/` e POC `example/`  
> **Referências:** `docs/synapx/synapx-plano-implementacao.md` (v2.1, slices 0.1a–0.2 entregues), `docs/synapx/synapx-consideracoes-dnolib.md` (§9 não-objetivos), `docs/synapx/synapx-conceito-arquitetura.md`, `AGENTS.md`, `LEARNINGS.md`

---

## 1. Objetivo

Tornar o Synapx **mais prático, menos verboso e com identidade própria consistente**, sem violar os invariantes já estabelecidos:

- **Renomeação limpa (sem aliases):** o E0 troca os nomes públicos para o padrão `Synapx*`/`*Extension` e migra **todos** os usos internos no mesmo ciclo; não há typedef/wrapper/depreciação de compatibilidade. Consumidores externos devem migrar junto (mudança breaking, registrada no CHANGELOG/release). As APIs de ergonomia (E1–E3) são aditivas; o E0 é a única etapa de rename.
- **Identidade canônica:** todo componente público do módulo `lib/synapx/` usa o prefixo **`Synapx`**; extensions usam o sufixo **`Extension`**.
- **Diretrizes preservadas (plano v2.1):** `core` puro (sem `package:flutter`), direção `synapx → core` (sem ciclo), sem singletons/pilhas globais, rastreamento por instância/`Zone`, ownership explícito de escopo/`Disposable`, facade única (`lib/dnolib.dart`, consumidor recorta com `show`/`hide`).
- **Não-objetivos deliberados mantidos (§9 considerações):** sem chave global de navegação/contexto implícito (diálogos continuam exigindo `BuildContext`), sem ocultar ciclo de vida/ownership, sem "mágica" de estado global.

**Critério de sucesso prático:** o `example/` (POC canônica) demonstra redução mensurável de cerimônia (linhas/boilerplate recorrente) nos padrões: refresh de lista, declaração de estado no controller, reação de UI e bootstrap do app — mantendo gates verdes e comportamento equivalente — e passa a usar exclusivamente os nomes canônicos Synapx.

---

## 2. Diagnóstico de verbosidade (baseline observado no `example/`)

| Ponto | Evidência (hoje) | Custo recorrente |
|---|---|---|
| Declaração + tracking no controller | `late final customers = trackObservable(RxList<Customer>())`, `trackObservable(computed(...))`, `trackToken(debounceRx(...))` | repetição `track*` em todo estado/worker |
| Guarda pós-`await` | `if (isDisposed) return;` repetido após operações assíncronas | ruído e risco de esquecimento |
| Substituição total de coleção | `customers.batch((l){ l..clear()..addAll(nova); })` em refresh | 3–4 linhas para operação comum |
| UI reativa | `SynapxScope(builder: (_) { final x = controller.x.value; ... })` por trecho, mesmo para 1 valor/página inteira | wrappers e leituras `.value` espalhadas |
| Bootstrap | `SynapxApp(builder: (_, __, observer) => MaterialApp(...))` | parâmetros ignorados obrigatórios |
| Comandos assíncronos na UI | estados idle/loading/error/empty tratados manualmente onde caberia `SynapxCommandView` | duplicação de mapeamento de estado |
| Identidade inconsistente | `ModuleScope`, `ScopeWidget`, `RxList`, `Disposable`, `Computed`, `ever/debounceRx` sem prefixo; `SynapxScope` (reativo) × `ScopeWidget` (DI) ambiguamente parecidos | leitura/descoberta e “cara” do módulo |

**Métrica de baseline (registrar no Slice E1, antes de refatorar):** contagem de ocorrências/linhas dos padrões acima em `example/lib/modules/customers` e `example/lib/app` (script simples `rg`/contagem manual registrada no commit do slice).

---

## 3. Fatiamento (slices aditivos, commits independentes)

Cada slice segue o ciclo do repositório: **Red-Before-Green** (teste/compilação falha provando a ausência) → implementação mínima → `puro flutter analyze --fatal-infos lib test` → `puro flutter test` → `puro dart format` (modo escrita) → atualizar `test/facade_test.dart` quando expor símbolo novo → `LEARNINGS.md`/`CHANGELOG.md` no **mesmo commit** (mudança observável) → commit atômico.

```mermaid
flowchart TD
    S0["Slice E0 — Identidade Synapx (nomes canônicos + aliases)"]
    S1["Slice E1 — Coleções & Controller DX"]
    S2["Slice E2 — UI reativa enxuta"]
    S3["Slice E3 — Wiring e adoção no example"]
    S0 --> S1 --> S2 --> S3
```

> Ordem por **impacto × risco**: E0 fecha a identidade antes que as APIs novas nasçam (evita retrabalho de rename); E1 entrega maior redução com APIs puras/aditivas; E2 melhora UI mantendo rastreamento; E3 consolida adoção e corta ruído de bootstrap. Preferir 1 commit por slice.

---

## 4. Slice E0 — Identidade Synapx (prioridade alta)

### 4.1 Regra
Todo símbolo **público** de `lib/synapx/` passa a ter nome canônico com prefixo **`Synapx`**; toda `extension` pública usa o sufixo **`Extension`**. Tipos do `core` (`Observable`, `Command`, `Result`…) ficam fora — não são componentes Synapx.

### 4.2 Mapeamento canônico (decisões fechadas; **sem aliases**)

| Categoria | Atual | Canônico | Ação |
|---|---|---|---|
| App/bootstrap | `SynapxApp`, `SynapxAppBuilder` | mantém | — |
| Página/controller | `SynapxPage`, `SynapxController` | mantém | — |
| Comando (UI) | `SynapxCommandView`, `SynapxCommandErrorBuilder` | mantém | — |
| Reativo (UI) | `SynapxScope` | mantém (**papel reativo explícito pelo nome da família; `SynapxProvider` cobre a DI**) | — |
| Provedor DI (UI) | `ScopeWidget` | **`SynapxProvider`** | renomear e migrar usos |
| Observador de rota | `ScopeRouteObserver` | **`SynapxRouteObserver`** | renomear e migrar usos |
| Rota modular (UI) | `ScopeRouteBuilder` | **`SynapxRouteScope`** | renomear e migrar usos |
| Container DI (Dart) | `ModuleScope` | **`SynapxModuleScope`** | renomear e migrar usos |
| Binding (typedef) | `ScopeBinder` | **`SynapxBinder`** | renomear e migrar usos |
| Módulo | `SynapxModule` | mantém | — |
| Teste | `SynapxTestScope` | mantém | — |
| Lifecycle | `Disposable` | **`SynapxDisposable`** | renomear e migrar usos |
| Lifecycle composto | `CompositeDisposable` | **`SynapxCompositeDisposable`** | renomear e migrar usos |
| Coleções reativas | `RxList`, `RxMap` | **`SynapxList`, `SynapxMap`** | renomear e migrar usos (a UX `.rx` permanece) |
| Extensions `.rx` | `RxListBind`, `RxMapBind` | **`SynapxListExtension`, `SynapxMapExtension`** | renomear (a UX `lista.rx`/`mapa.rx` não muda) |
| Derivado | `Computed`, `computed()` | **`SynapxComputed`, `synapxComputed()`** | renomear e migrar usos |
| Tracker | `RxTracker` | **`SynapxTracker`** | renomear e migrar usos |
| Callback | `RxCallback<T>` | **`SynapxCallback<T>`** | renomear e migrar usos |
| Workers | `ever`, `once`, `debounceRx`, `intervalRx` | **`SynapxEffect.ever/once/debounce/interval`** (fachada estática) | mover para a fachada; remover top-levels antigos e migrar usos |
| Contexto | `SynapxContextX` | **`SynapxContextExtension`** | renomear (extensions não têm alias; usos via `context.*` não mudam) |
| Diálogos | `SynapxDialogsX` | **`SynapxDialogsExtension`** | renomear (usos via `context.*` não mudam) |
| Rota | `RouteContext` | **`SynapxRouteContext`** | renomear e migrar usos |
| Guard | `RouteGuard` | **`SynapxRouteGuard`** | renomear e migrar usos |
| Resultado de guard | `GuardResult`, `GuardAllow`, `GuardReject`, `GuardRedirect` | **`SynapxGuardResult`, `SynapxGuardAllow`, `SynapxGuardReject`, `SynapxGuardRedirect`** | renomear e migrar usos |
| Executor de guard | `RouteGuardRunner` | **`SynapxRouteGuardRunner`** | renomear e migrar usos |

### 4.3 Pontos de implementação (sem aliases)
- **Rename direto:** renomear o tipo/função/extension no próprio arquivo e atualizar **todos** os usos do repo (`lib/synapx`, `lib/dnolib.dart` se reexportado por nome, `test/`, `example/`, docs) no mesmo slice. Nada de `typedef`/`@Deprecated`/wrapper de compatibilidade.
- **Top-levels (`ever`/`once`/`debounceRx`/`intervalRx`/`computed`):** migrar para a fachada `SynapxEffect.*` e `synapxComputed`; remover os nomes antigos (não manter funções de encaminhamento).
- **Extensions:** renomear para `Synapx*Extension`. A UX (`context.confirm`, `context.get<T>`, `lista.rx`) não muda; só o símbolo da extension. Sem extension duplicada.
- **Barrel/facade:** `lib/synapx/synapx.dart` exporta apenas os canônicos; `lib/dnolib.dart` (se reexporta símbolo por nome) atualizado; `test/facade_test.dart` asserta os canônicos.
- **Gate de identidade (novo, mecânico):** teste que varre `lib/synapx/src/**` e falha se uma declaração pública (`class`/`mixin`/`enum`/`extension`/`typedef`) não começar com `Synapx` (permitindo apenas privados `_*` e o que for explicitamente justificado). Prova negativa: renomear temporariamente um símbolo público para fora do padrão e o teste reprovar.
- **Ordem interna segura:** renomear símbolo → atualizar usos no mesmo commit → rodar gates → commit atômico. Não deixar o repo num estado intermediário com nomes mistos.

### 4.4 Testes (Red-Before-Green)
- Compilação/uso dos símbolos canônicos em teste dedicado (ex.: `test/synapx/identity_test.dart`) **falha antes** e passa depois.
- `test/facade_test.dart` instancia/usa 1 símbolo canônico de cada família (módulo, controller, list/map, guard, extension) para provar export correto.
- **Gate de identidade** (4.3) verde, com prova negativa registrada (o teste reprova o símbolo fora do padrão).
- **Gate de ausência de legado:** busca mecânica (`test/synapx/legacy_names_test.dart`) garantindo zero ocorrências dos nomes antigos (`ModuleScope`, `ScopeWidget`, `ScopeRouteObserver`, `ScopeRouteBuilder`, `RxList`, `RxMap`, `Disposable`, `CompositeDisposable`, `Computed`, `computed(`, `RxTracker`, `RxCallback`, `ever(`, `once(`, `debounceRx`, `intervalRx`, `RouteContext`, `RouteGuard`, `GuardAllow/Reject/Redirect`, `SynapxContextX`, `SynapxDialogsX`) em **código** (`lib/`, `test/`, `example/lib`, `example/test`). Docs históricos (`LEARNINGS`, `CHANGELOG`, planos anteriores em `docs/synapx/`) ficam fora do scan e preservam o registro da época.

**Critério de aceite E0:** todos os componentes públicos com prefixo `Synapx` (extensions com `Extension`); **nenhum alias/nome antigo vivo**; `example/`, testes internos e docs migrados; gates de identidade e de ausência de legado verdes; `CHANGELOG`/`LEARNINGS` no mesmo commit.

---

## 5. Slice E1 — Coleções & Controller DX (prioridade alta)

### 5.1 `SynapxList.assign` / `SynapxMap.assign` (substituição atômica)

**Arquivos:** `lib/synapx/src/reactive/synapx_collections.dart` (renomeado conceitualmente para `SynapxList`/`SynapxMap` no E0) + testes.

**Contrato:**
- `void assign(Iterable<E> items)` em `SynapxList<E>`: substitui todo o conteúdo por `items` emitindo **uma única notificação** (mesmo com N elementos). Implementação interna via `batch`/controle de `_batchDepth` (`clear` + `addAll` condensados), sem expor estado intermediário.
- `void assign(Map<K, V> entries)` (nome a fixar no Red e manter único) em `SynapxMap<K,V>` com semântica análoga.
- Não altera `value` ser a coleção viva; não quebra `batch`.

**Testes (Red):** lista/mapa observada recebe exatamente 1 notificação em `assign` com múltiplos itens; conteúdo final correto; `assign` em lista vazia→vazia define comportamento explícito (no-op ou notifica — fixar e testar); funciona dentro/fora de `batch` externo.

**Uso alvo (example):** `customers.assign(result.getOrNull() ?? const <Customer>[]);`

### 5.2 Helpers de criação+tracking em `SynapxController`

**Arquivo:** `lib/synapx/src/lifecycle/synapx_controller.dart` + testes.

**Contrato (aditivo; nomes de membro não precisam do prefixo, pois a classe já é Synapx):**
- `Observable<T> obs<T>(T initial)` — cria, `trackObservable`, devolve.
- `SynapxList<E> list<E>([Iterable<E>? initial])` e `SynapxMap<K,V> map<K,V>([Map<K,V>? initial])` — criam, rastreiam, devolvem.
- `SynapxComputed<T> derived<T>(T Function() compute)` (ou `computed`) — cria, rastreia, devolve.
- Atalhos de workers que **registram o token** e o devolvem: `debounce<T>(Observable<T>, RxCallback<T>, {required Duration})` (mínimo obrigatório) e equivalentes `ever`/`once`/`interval` se o ganho for claro; delegação a `SynapxEffect`.
- Todos retornam as instâncias/tokens tipados para uso fluente; continuam descartáveis pelo ciclo do controller.

**Testes (Red):** controller descartado cancela/descarta recursos criados pelos helpers (observable não notifica após dispose do controller; token de debounce cancelado; derived para de recomputar).

### 5.3 Guarda de execução assíncrona (`runIfActive`/`guard`)

**Arquivo:** `lib/synapx/src/lifecycle/synapx_controller.dart` + testes.

**Contrato (proposta, validar no Red):**
- `Future<void> runIfActive(Future<void> Function() action)` executa `action`; se o controller estiver `isDisposed` **após** a conclusão, a chamada retorna sem propagar efeitos colaterais adicionais do helper (o chamador ainda deve estruturar efeitos pós-await conscientemente). Alternativa mais forte: `bool get isActive => !isDisposed` + helper `T? ifActive<T>(T value)` — **decidir na implementação a forma que realmente remove linhas sem fingir segurança mágica**.
- Objetivo realista: eliminar o `if (isDisposed) return;` boilerplate padrão **onde for seguro**; documentar limites (não interrompe o corpo no meio de um `await` interno).

**Critério de aceite E1:** helpers e `assign` cobertos por testes; `example` (`CustomerController.refresh` + declarações + debounce) refatorado para usar as novas APIs com comportamento idêntico; gates verdes; símbolos novos exportados/assertados na facade.

---

## 6. Slice E2 — UI reativa enxuta (prioridade média)

### 6.1 Builder pontual de observable (`SynapxObserver`)

**Arquivo:** `lib/synapx/src/widgets/` (novo arquivo coeso, ex. `synapx_observer.dart`) + export no barrel synapx e na facade se necessário.

**Contrato (forma primária única):**
- `SynapxObserver<T>({required Observable<T> observable, required Widget Function(BuildContext, T) builder})` assina um observable específico e reconstrói com seu valor. Explícito, sem `Zone` tracking (complementa `SynapxScope`).
- Opcional: `observable.watch((context, value) => ...)` como açúcar sobre `SynapxObserver` **somente se** não inflar a API; preferir a primitiva primeiro.

**Testes (Red):** atualiza ao mudar valor; não atualiza após dispose; não vaza assinatura.

### 6.2 `SynapxReactivePage<T>` (página inteira reativa)

**Arquivo:** `lib/synapx/src/widgets/synapx_page.dart` (ou novo arquivo) + testes de widget.

**Contrato:** subclasse/variante de `SynapxPage<T>` cujo `build` é executado dentro de `SynapxScope`, para páginas cujo corpo inteiro depende de observáveis do controller (remove um nível de indentação/wrapper). **Aditivo:** `SynapxPage` original permanece para controle fino.

**Uso alvo:** `CustomerPage`/tiles que hoje embrulham tudo em `SynapxScope` avaliam migração quando ficar mais limpo.

### 6.3 Adoção de `SynapxCommandView` onde houver fluxo de comando

**Escopo:** refatoração guiada no `example/` (não mudança de lib, salvo lacuna real encontrada). Mapear pontos com loading/error/idle manual ligados a `Command` e substituir por `SynapxCommandView` quando reduzir código sem perder clareza. Se não houver candidato natural no example atual, registrar "sem candidato" no commit/LEARNINGS (não forçar).

**Critério de aceite E2:** pelo menos um widget/página do example simplificado com as novas primitivas de UI, sem regressão visual/comportamental nos testes existentes; testes novos para os widgets/helpers introduzidos.

---

## 7. Slice E3 — Wiring, aliases e consolidação (prioridade média/baixa)

### 7.1 `SynapxApp`: reduzir parâmetros ignorados

**Arquivo:** `lib/synapx/src/widgets/synapx_app.dart` + testes.

**Contrato (aditivo, sem quebrar `builder` atual):**
- Adicionar parâmetro nomeado alternativo, ex. `appBuilder: Widget Function(BuildContext context, SynapxRouteObserver observer)` **ou** `observerBuilder`, usado quando `builder` não for informado (assert de exclusividade/precedência clara). Permite `appBuilder: (context, observer) => MaterialApp(navigatorObservers: [observer], ...)` sem os dois placeholders.
- Manter `builder` atual funcional e documentado.

### 7.2 Aliases de binding no `SynapxModuleScope` (opcional, baixo risco)

**Arquivo:** `lib/synapx/src/lifecycle/synapx_module_scope.dart`.

**Contrato:** aliases curtos `instance<T>` / `lazy<T>` / `factory<T>` delegando para os `register*` existentes (ou manter apenas documentação de cascade). Incluir **somente se** o example ficar objetivamente mais legível; caso contrário, descartar neste slice e registrar decisão.

### 7.3 Refatoração completa do `example/` + medição

- Aplicar E0–E3 no `example/` de forma consistente (controllers, páginas, app, nomes canônicos).
- Registrar no commit: **delta** da métrica de baseline (§2) e nota de legibilidade (o que sumiu: `trackObservable` repetido, `batch/clear/addAll`, `if (isDisposed)` padrão, placeholders do builder, nomes ambíguos etc.).
- Garantir que o example continue sendo POC canônica (consumo só pela facade, VSA, gates).

**Critério de aceite E3:** example compila/testa com as novas APIs; documentação inline/README do example mínima atualizada se a forma recomendada mudar.

---

## 8. Cross-cutting: qualidade, gates e documentação

- **Testes:** Red-Before-Green por slice; cobrir contratos novos (notificação única de `assign`, descarte via helpers, guarda assíncrona, widgets `SynapxObserver/ReactivePage`, `SynapxApp` novo builder, identidade/aliases). Não enfraquecer testes existentes do synapx/core.
- **Gates por slice (obrigatórios):** `puro flutter analyze --fatal-infos lib test`, `puro flutter test` (raiz; e `example/` quando alterado, em sequência no Windows para evitar lock de `build/unit_test_assets`), `puro dart format` em modo escrita antes do commit.
- **Facade/exports:** todo símbolo público novo do Synapx exportado pelo barrel `lib/synapx/synapx.dart` e, se aplicável, coberto pela asserção de `test/facade_test.dart` (regra do repo: export esquecido não pode ficar silencioso).
- **Docs/changelog:** atualizar `CHANGELOG.md` (seção adequada ao fluxo do repo) e `LEARNINGS.md` no mesmo commit quando houver mudança observável/aprendizado; este plano em `docs/synapx/` é atualizado de **Proposto → Em execução/Concluído** por slice se desejado (sem espelhar status em duplicidade).
- **Dart/Flutter:** `formatter.trailing_commas: preserve` + `require_trailing_commas`; ~250 linhas por arquivo de UI → extrair widgets de classe.

---

## 9. Riscos e mitigação

| Risco | Mitigação |
|---|---|
| Rename E0 quebrar consumidores externos (`.modelo`/apps) | Sem aliases por decisão do mantenedor: tratar como **breaking change** explícita (CHANGELOG/release), migrar `example/` + testes + docs no mesmo ciclo e publicar nota de migração (mapa nomes antigos→novos). |
| `runIfActive/guard` dar falsa sensação de segurança (não cancela `await` em curso) | Documentar semântica exata; testes mostrando o limite; preferir açúcar mínimo honesto (`isActive`/checagem centralizada) se o helper "mágico" não reduzir bugs reais. |
| `assign` conflitar com expectativa de "no-op não notifica" em alguns casos | Fixar contrato no teste Red (notifica sempre na substituição vs compara conteúdo) e documentar; default seguro: notifica 1x. |
| Proliferação de APIs paralelas (`SynapxObserver` vs `SynapxScope` vs `watch`) | Escolher primitiva canônica (E2) e tornar as demais açúcar fino; documentar "quando usar qual". |
| `comp/list/map/obs` no controller puxarem dependências erradas | Manter tudo dentro de `lib/synapx/` (já depende de core); nenhum import de Flutter nos helpers puros. |
| `SynapxScope` (reativo) × `SynapxProvider`/`SynapxModuleScope` (DI) ainda confundirem | Nomes de papel distintos (reativo × provedor × container) + documentação curta no barrel/README. |

---

## 10. Fora de escopo (neste plano)

- Sintaxe de acesso reativo por call/getter mágico (`obs()`/`obs(v)`) no lugar de `.value` como padrão (avaliar separadamente; conflita com explicitude).
- Reescrever roteamento, guards ou lifecycle além do necessário para ergonomia.
- Mudanças em `lib/core/**` que não sejam estritamente necessárias e comprovadamente agnósticas (preferir resolver em `lib/synapx`).
- Novos domínios/features no `example` além do necessário para demonstrar a ergonomia.
- Design system visual próprio (`SynapxCommandView` e diálogos continuam reaproveitando widgets/tema do host).

---

## 11. Checklist de conclusão (por slice)

- [ ] Red escrito e falha observada (ausência do comportamento/API/símbolo canônico).
- [ ] Green mínimo implementado.
- [ ] `analyze --fatal-infos lib test` limpo.
- [ ] `flutter test` (raiz, e `example/` se tocado) verde.
- [ ] `dart format` aplicado.
- [ ] Facade/barrel e `test/facade_test.dart` coerentes com novos símbolos públicos.
- [ ] Nenhum nome antigo remanescente (gate de identidade + gate de ausência de legado verdes).
- [ ] `CHANGELOG.md`/`LEARNINGS.md` atualizados no mesmo commit (quando aplicável).
- [ ] `example/` refatorado quando o slice prometer adoção, com métrica/delta registrada (E1/E3).
- [ ] Commit atômico do slice, mensagem convencional.
