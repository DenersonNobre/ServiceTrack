# Desenho Conceitual e Arquitetural — Ecossistema Synapx

> **Status:** Proposta Estruturada / RFC  
> **Versão:** 0.1.0-draft  
> **Data:** 2026-11-17  
> **Target:** Flutter 3.x+ (Dart 3.x+)

---

## 1. Visão Geral e Proposta de Valor

O **Synapx** nasce para solucionar a falsa dicotomia clássica do ecossistema Flutter: **produtividade extrema com baixa barreira vs. arquitetura limpa e determinismo de ciclo de vida**.

Historicamente, soluções com reatividade transparente e DX (Developer Experience) ágil pecam por estado global descontrolado, falta de escopo ou acoplamento a padrões proprietários fora dos contratos oficiais do Flutter. Por outro lado, soluções arquiteturais rígidas impõem alto custo de boilerplate, fluxos complexos de Streams/Events e sobrecarga mental no dia a dia.

```mermaid
flowchart LR
    subgraph Synapx
        A[Zero Boilerplate na UI] --> D[Produtividade Fluida]
        B[Escopo Blindado e Hierárquico] --> E[Arquitetura Limpa]
        C[100% Nativo sobre Flutter] --> F[Previsibilidade e Desempenho]
    end
```

### Princípios Norteadores
1. **Zero Boilerplate na UI**: A camada de visualização reage pontualmente às variáveis observáveis acessadas em tempo de execução no escopo do widget observador, eliminando builders aninhados repetitivos.
2. **Escopo Blindado (Scoped Lifecycle)**: Dependências e controladores vivem estritamente vinculados ao ciclo de vida de seu módulo na árvore de navegação, sem risco de instâncias zumbis.
3. **Fundação 100% Nativa**: Construído sobre primitivas canônicas do framework Flutter (`Listenable`, `InheritedWidget`, `RouterConfig` / `Navigator 2.0`), sem dependências externas de terceiros e sem forçar monólitos.

---

## 2. Topologia dos 4 Pilares

```mermaid
flowchart TD
    subgraph Synapx Ecosystem
        P1["Pillar I: Synapx Reactive<br/>(Motor Reativo & Workers)"]
        P2["Pillar II: Synapx Core<br/>(DI Hierárquica & Lifecycle)"]
        P3["Pillar III: Synapx Router<br/>(Navigator 2.0, Módulos & Guards)"]
        P4["Pillar IV: Synapx Test<br/>(Isolamento & Overrides)"]
    end

    P3 -->|Ativa/Destrói Módulo| P2
    P2 -->|Gerencia Ciclo| P1
    P4 -.->|Injeta Fakes em| P2
    P4 -.->|Testa Rotas de| P3
```

---

### Pillar I: Synapx Reactive (Motor de Reatividade)

O motor reativo do Synapx opera com base no rastreamento transparente de leitura (*transparent reactive tracking*), desacoplando lógica de apresentação sem recorrer a pipelines pesados de `Stream`/`BroadcastStream`.

- **Primitivas Inteligentes (`Rx<T>`, `RxList<T>`, `RxMap<T>`)**:
  - Especializações leves de `ValueNotifier<T>` com despacho atômico de mutação.
  - Comparações estritas (`distinct`) para evitar notificações idempotentes.
- **Rastreamento Automático (`SynapxScope` / `SynapxObserver`)**:
  - Executa uma função de renderização sob uma pilha de contexto reativo global/transiente.
  - Registra automaticamente dependências apenas das variáveis `.value` avaliadas naquele frame.
  - Assina o `Listenable` e re-renderiza cirurgicamente apenas o subtree delimitado.
- **Workers Reativos de Fluxo**:
  - `ever(rx, callback)`: Reação contínua a cada alteração.
  - `once(rx, callback)`: Disparo único no primeiro evento de alteração.
  - `debounce(rx, callback, {duration})`: Atraso temporizado para campos de busca e digitação contínua.
  - `interval(rx, callback, {duration})`: Amostragem em janelas de tempo fixas.

---

### Pillar II: Synapx Core (DI & Ciclo de Vida)

Resolve o problema crítico de escopo: dependências não devem ser globais por padrão.

```mermaid
flowchart TD
    AppModule["AppModule (Root Scope)"]
    AuthModule["AuthModule (Child Scope)"]
    SalesModule["SalesModule (Child Scope)"]
    OrderSubModule["OrderSubModule (Nested Scope)"]

    AppModule --> AuthModule
    AppModule --> SalesModule
    SalesModule --> OrderSubModule

    classDef scope fill:#f4f4f5,stroke:#3b82f6,stroke-width:1px;
    class AppModule,AuthModule,SalesModule,OrderSubModule scope;
```

- **Contêineres Hierárquicos**:
  - Cada módulo define seu catálogo de serviços: `Singleton` (uma instância por escopo do módulo), `LazySingleton` (instanciação sob demanda) e `Factory` (nova instância por injeção).
  - Resolução em árvore: Se um submódulo solicita um serviço não declarado em si, busca recursivamente nos módulos ancestrais até o módulo raiz.
- **Auto-Dispose e Descarte em Cascata**:
  - Controladores que implementam `Disposable` (ou que gerenciam `Rx`/`Timer`/`StreamController`) têm seus métodos de finalização disparados no encerramento da rota ou módulo correspondente.
  - Elimina vazamento de memória e listeners pendentes.

---

### Pillar III: Synapx Router (Roteamento Modular)

Totalmente compatível com **Flutter Navigator 2.0 (`RouterConfig`)**, permitindo suporte nativo a Deep Links, Web URLs e histórico de navegação sem depender de hacks ou contextos instáveis.

- **Módulos como Unidade de Rota**:
  - Um módulo encapsula suas rotas filhas, seus bindings de injeção e seus interceptadores.
  - Suporte nativo a carregamento diferido (*code-splitting / lazy loading*).
- **Guards Assíncronos (`RouteGuard`)**:
  - Interceptadores com execução sequencial pré-navegação.
  - Capacidade de redirecionamento, cancelamento ou suspensão até resolução de autenticação/permissões.
- **Navegação Desacoplada e Declarativa**:
  - Interface ergonômica (`Synapx.to('/vendas/novo')`, `Synapx.back()`) sem dependência obrigatória de passar `BuildContext` em camadas de orquestração.
  - Preservação estrita da integridade de pilhas e rotas aninhadas.

---

### Pillar IV: Synapx Test (Experiência de Testes)

Desenvolvido para garantir que testes unitários e testes de widget rodem com velocidade e isolamento estrito.

- **Modo Isolado**:
  - `SynapxTest.createScope()` permite instanciar e inicializar um módulo isoladamente sem boot completo da aplicação.
- **Overrides Declarativos**:
  - Substituição cirúrgica de dependências por Fakes ou Mocks diretamente na inicialização do teste.
- **Testes de Reatividade Pura**:
  - Drivers de teste para verificar ciclos de `Rx` e disparo de workers sem necessitar de pump de widgets.

---

## 3. Matriz Comparativa: Por que Synapx?

| Aspecto | Abordagem Tradicional (GetX) | Abordagem Rígida (Modular / Bloc / Riverpod) | Proposta do **Synapx** |
| :--- | :--- | :--- | :--- |
| **Acoplamento & Escopo** | Estado global com facilidade de vazar instâncias. | Modular isola bem, mas exige contratos e factories extensas. | **Escopo estrito por módulo**, herdado hierarquicamente e com sintaxe enxuta. |
| **Consumo de Memória** | Alto risco de controladores zumbis e listeners esquecidos. | Bom controle, exigindo descarte manual ou configuração explícita. | **Descarte automático em cascata** atrelado diretamente à pilha de rotas. |
| **Pegada de Dependências** | Monólito com centenas de extensões e utilitários não correlatos. | Várias bibliotecas externas encadeadas e dependências extras. | **Núcleo ultra-enxuto**: 100% sobre APIs oficiais do Flutter, zero pacotes terceiros. |
| **Curva de Aprendizado** | Baixa barreira, mas ausência de guardrails conduz a antipatterns. | Curva íngreme, cerimônia excessiva e alto volume de boilerplate. | **Intuitiva e pragmática**, com o próprio design direcionando para arquitetura limpa. |
| **Fidelidade à Plataforma** | Hacks sobre Navigator e re-implementações paralelas. | Boa aderência ao ecossistema nativo do Flutter. | **Alinhamento estrito ao Flutter canônico** (`RouterConfig`, `Listenable`). |

---

## 4. Fases de Evolução do Ecossistema

```mermaid
timeline
    title Roadmap Evolutivo Synapx
    section v0.1 Foundation
        Core & Reactive : Primitivas Rx, Tracking, Scope Container, Lifecycle básico
    section v0.2 Routing
        Router & Guards : Integração RouterConfig, Nested Routes, Interceptadores assíncronos
    section v0.3 Observability
        DevTools & Logs : Extensão DevTools para auditoria de bindings, rebuilds e memory leaks
    section v1.0 Tooling
        Synapx CLI : Scaffolding de módulos, páginas e testes sob convenções oficiais
```

1. **v0.1 — Core & Reactive**:
   - Mecanismo reativo (`Rx`, `RxList`, `RxMap`, `SynapxScope`).
   - Contêiner de injeção hierárquico com suporte a `Singleton`, `LazySingleton` e `Factory`.
   - Gerenciamento de ciclo de vida e descarte determinístico.

2. **v0.2 — Router & Guards**:
   - Integração com `RouterConfig` / Navigator 2.0 nativo.
   - Declaração de rotas modulares e carregamento sob demanda.
   - Pipeline de `RouteGuard` assíncrono para autorização e autenticação.

3. **v0.3 — DevTools & Observability**:
   - Extensão para o Flutter DevTools.
   - Inspeção visual de módulos ativos, contagem de rebuilds e detecção de dependências retidas.

4. **v1.0 — Synapx CLI & Release Estável**:
   - CLI de scaffolding (`synapx create module`, `synapx create page`).
   - Maturação de documentação, guias de migração e estabilização de APIs públicas.
