import 'package:dnolib/dnolib.dart'
    show
        Command,
        IFailure,
        IResult,
        Money,
        SynapxRouteObserver,
        SynapxProvider,
        Success,
        SynapxTestScope;
import 'package:dnolib_example/app/app_module.dart';
import 'package:dnolib_example/main.dart';
import 'package:dnolib_example/modules/customers/domain/customer.dart';
import 'package:dnolib_example/modules/customers/domain/customer_repository.dart';
import 'package:dnolib_example/modules/customers/ui/customer_controller.dart';
import 'package:dnolib_example/modules/orders/customer_orders_module.dart';
import 'package:dnolib_example/modules/orders/domain/customer_order.dart';
import 'package:dnolib_example/modules/orders/domain/customer_order_repository.dart';
import 'package:dnolib_example/modules/orders/ui/customer_orders_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'customer_form_test.dart';

void main() {
  testWidgets(
    'POC Synapx: SynapxModuleScope, SynapxScope e SynapxRouteScope com guard',
    (tester) async {
      final repo = FakeCustomerRepository();

      await tester.pumpWidget(CustomerApp(repository: repo));
      await tester.pumpAndSettle();

      final pageContext = tester.element(find.byType(CustomerPage));
      final rootScope = SynapxProvider.of(pageContext);
      final controller = rootScope.get<CustomerController>();

      expect(rootScope.get<SynapxRouteObserver>().activeRoutesCount, 1);
      expect(controller.isDisposed, isFalse);

      // Navega para rota protegida com guard autorizado (SynapxRouteScope).
      await tester.tap(find.byKey(const Key('summaryButton')));
      await tester.pumpAndSettle();

      expect(find.text('Resumo Synapx'), findsOneWidget);
      expect(find.text('Total de clientes: 0'), findsOneWidget);

      // Pop volta para a tela principal; controller raiz permanece ativo.
      await tester.pageBack();
      await tester.pumpAndSettle();
      expect(controller.isDisposed, isFalse);

      // Desmontar CustomerApp descarta o SynapxModuleScope e o CustomerController.
      await tester.pumpWidget(const SizedBox.shrink());
      expect(controller.isDisposed, isTrue);
    },
  );

  testWidgets('POC Synapx: guard negado exibe tela de rejeição', (
    tester,
  ) async {
    await tester.pumpWidget(
      CustomerApp(repository: FakeCustomerRepository(), allowSummary: false),
    );
    await tester.pumpAndSettle();

    await tester.tap(find.byKey(const Key('summaryButton')));
    await tester.pumpAndSettle();

    expect(find.text('Acesso negado'), findsOneWidget);
    expect(find.text('Acesso restrito ao resumo'), findsOneWidget);
  });

  testWidgets(
    'POC Synapx: tocar em cliente abre fatia de pedidos com SynapxModuleScope filho descartado no pop',
    (tester) async {
      await tester.pumpWidget(
        CustomerApp(repository: FakeCustomerRepository()),
      );
      await tester.pumpAndSettle();

      await tester.enterText(find.byKey(const Key('nameField')), 'Ana');
      await tester.enterText(
        find.byKey(const Key('cpfField')),
        '529.982.247-25',
      );
      await tester.enterText(
        find.byKey(const Key('emailField')),
        'ana@example.com',
      );
      await tester.enterText(find.byKey(const Key('cepField')), '01001-000');
      await tester.enterText(find.byKey(const Key('valueField')), '100,00');
      await tester.tap(find.byKey(const Key('saveButton')));
      await tester.pumpAndSettle();

      await tester.ensureVisible(find.text('Ana'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('Ana'));
      await tester.pumpAndSettle();

      expect(find.text('Pedidos de Ana'), findsOneWidget);

      final ordersContext = tester.element(find.text('Pedidos de Ana'));
      final ordersController = SynapxProvider.of(
        ordersContext,
      ).get<CustomerOrdersController>();
      expect(ordersController.isDisposed, isFalse);

      await tester.enterText(
        find.byKey(const Key('orderDescriptionField')),
        'Café Especial',
      );
      await tester.enterText(
        find.byKey(const Key('orderAmountField')),
        '15,00',
      );
      await tester.tap(find.byKey(const Key('saveOrderButton')));
      await tester.pumpAndSettle();

      expect(find.text('Café Especial'), findsOneWidget);

      await tester.pageBack();
      await tester.pumpAndSettle();

      expect(ordersController.isDisposed, isTrue);
    },
  );

  test(
    'SynapxTestScope isola AppModule com overrides e SynapxComputed totalBalance',
    () async {
      final fakeRepo = FakeCustomerRepository();
      final testScope = SynapxTestScope(
        module: AppModule(
          repository: fakeRepo,
          orderRepository: _TestOrderRepository(),
        ),
        overrides: (scope) => scope.registerLazySingleton<CustomerController>(
          (s) => CustomerController(s.get<CustomerRepository>()),
        ),
      );

      final controller = testScope.get<CustomerController>();
      expect(controller.totalBalance.value.minorUnits, BigInt.zero);

      controller.customers.add(
        Customer(
          id: 1,
          name: 'Maria',
          cpf: '52998224725',
          email: 'maria@example.com',
          cep: '01001000',
          balance: Money.fromMinorUnits(15050, currencyCode: 'BRL', scale: 2),
        ),
      );
      expect(controller.totalBalance.value.minorUnits, BigInt.from(15050));

      final childScope = SynapxTestScope(
        parent: testScope.scope,
        module: CustomerOrdersModule(controller.customers.first),
      );
      final ordersController = childScope.get<CustomerOrdersController>();
      expect(ordersController.customer.name, 'Maria');

      childScope.dispose();
      expect(ordersController.isDisposed, isTrue);
      testScope.dispose();
      expect(controller.isDisposed, isTrue);
    },
  );
}

class _TestOrderRepository implements CustomerOrderRepository {
  @override
  Future<IResult<List<CustomerOrder>, IFailure>> listByCustomer(
    int customerId,
  ) async => const Success(<CustomerOrder>[]);

  @override
  Command<int, String, CustomerOrder> saveCommand() =>
      Command<int, String, CustomerOrder>(
        (_) async => const Success(1),
        mapException: (e, _) => '$e',
      );
}
