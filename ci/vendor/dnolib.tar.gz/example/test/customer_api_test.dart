import 'dart:convert';

import 'package:dnolib/dnolib.dart' show KeyValue, RestClient, RestConfig;
import 'package:dnolib_example/modules/customers/data/customer_api.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';

void main() {
  test('lista clientes da API', () async {
    final client = MockClient(
      (request) async => http.Response(
        jsonEncode([
          {'id': 1, 'name': 'Ana'},
        ]),
        200,
      ),
    );
    final api = CustomerApi(
      const RestConfig(baseUrl: 'https://api.example.com'),
      RestClient(
        const RestConfig(baseUrl: 'https://api.example.com'),
        httpClient: client,
      ),
    );

    final result = await api.fetchCustomers();

    expect(result.getOrNull(), [
      {'id': 1, 'name': 'Ana'},
    ]);
  });

  test('404 devolve Success(null) e 500 devolve Failure', () async {
    final notFound = CustomerApi(
      const RestConfig(baseUrl: 'https://api.example.com'),
      RestClient(
        const RestConfig(baseUrl: 'https://api.example.com'),
        httpClient: MockClient((request) async => http.Response('[]', 404)),
      ),
    );
    final missingResult = await notFound.readById(
      const KeyValue(key: 'id', value: '99'),
    );
    expect(missingResult.isSuccess, isTrue);
    expect(missingResult.getOrNull(), isNull);

    final broken = CustomerApi(
      const RestConfig(baseUrl: 'https://api.example.com'),
      RestClient(
        const RestConfig(baseUrl: 'https://api.example.com'),
        httpClient: MockClient((request) async => http.Response('ops', 500)),
      ),
    );
    final failureResult = await broken.fetchCustomers();
    expect(failureResult.isFailure, isTrue);
    expect(failureResult.getOrNullFailure()?.code, 'INFRASTRUCTURE_ERROR');
  });
}
