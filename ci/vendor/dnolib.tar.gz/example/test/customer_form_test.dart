import 'package:dnolib/dnolib.dart' show Command, IFailure, IResult, Success;
import 'package:dnolib_example/main.dart';
import 'package:dnolib_example/modules/customers/domain/customer.dart';
import 'package:dnolib_example/modules/customers/domain/customer_repository.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

class FakeCustomerRepository implements CustomerRepository {
  final List<Customer> _customers = [];
  int _nextId = 1;

  @override
  Future<IResult<List<Customer>, IFailure>> listCustomers({
    String? name,
  }) async {
    if (name == null) {
      return Success(List.unmodifiable(_customers));
    }
    return Success(_customers.where((c) => c.name == name).toList());
  }

  @override
  Command<int, String, Customer> saveCommand() {
    return Command<int, String, Customer>((customer) async {
      final id = _nextId++;
      _customers.add(
        Customer(
          id: id,
          name: customer!.name,
          cpf: customer.cpf,
          email: customer.email,
          cep: customer.cep,
          balance: customer.balance,
        ),
      );
      return Success(id);
    }, mapException: (error, _) => error.toString());
  }

  @override
  Command<int, String, int> deleteCommand() {
    return Command<int, String, int>((id) async {
      _customers.removeWhere((customer) => customer.id == id);
      return Success(id!);
    }, mapException: (error, _) => error.toString());
  }
}

void main() {
  Future<void> pumpPage(WidgetTester tester, [CustomerRepository? repo]) async {
    final repository = repo ?? FakeCustomerRepository();
    await tester.pumpWidget(CustomerApp(repository: repository));
    await tester.pumpAndSettle();
  }

  Future<void> fillValidForm(WidgetTester tester) async {
    await tester.enterText(find.byKey(const Key('nameField')), 'Ana');
    await tester.enterText(find.byKey(const Key('cpfField')), '529.982.247-25');
    await tester.enterText(
      find.byKey(const Key('emailField')),
      'ana@example.com',
    );
    await tester.enterText(find.byKey(const Key('cepField')), '01001-000');
    await tester.enterText(find.byKey(const Key('valueField')), '1.234,56');
  }

  testWidgets('CPF inválido bloqueia o salvamento', (tester) async {
    await pumpPage(tester);

    await tester.enterText(find.byKey(const Key('nameField')), 'Ana');
    await tester.enterText(find.byKey(const Key('cpfField')), '111.111.111-11');
    await tester.tap(find.byKey(const Key('saveButton')));
    await tester.pumpAndSettle();

    expect(find.text('CPF inválido'), findsOneWidget);
    expect(find.text('0 clientes'), findsOneWidget);
  });

  testWidgets('cliente válido entra na lista e atualiza o total', (
    tester,
  ) async {
    await pumpPage(tester);
    await fillValidForm(tester);
    await tester.tap(find.byKey(const Key('saveButton')));
    await tester.pumpAndSettle();

    expect(find.text('Ana'), findsOneWidget);
    expect(find.text('529.982.247-25 • 01001-000'), findsOneWidget);
    expect(find.text('R\$ 1.234,56'), findsNWidgets(2));
  });

  testWidgets('excluir com confirmação remove da lista', (tester) async {
    await pumpPage(tester);
    await fillValidForm(tester);
    await tester.tap(find.byKey(const Key('saveButton')));
    await tester.pumpAndSettle();
    expect(find.text('Ana'), findsOneWidget);

    await tester.ensureVisible(find.byKey(const Key('delete_1')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('delete_1')));
    await tester.pumpAndSettle();
    expect(find.text('Excluir cliente?'), findsOneWidget);

    await tester.tap(find.text('Confirmar'));
    await tester.pumpAndSettle();

    expect(find.text('Ana'), findsNothing);
  });

  testWidgets('cancelar a confirmação mantém o cliente', (tester) async {
    await pumpPage(tester);
    await fillValidForm(tester);
    await tester.tap(find.byKey(const Key('saveButton')));
    await tester.pumpAndSettle();

    await tester.ensureVisible(find.byKey(const Key('delete_1')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('delete_1')));
    await tester.pumpAndSettle();

    await tester.tap(find.text('Cancelar'));
    await tester.pumpAndSettle();

    expect(find.text('Ana'), findsOneWidget);
  });
}
