// Caso de uso puro de salvamento de cliente (sem UI, sem Synapx).
// Fase Red: falha sem `modules/customers/commands/submit_customer_form.dart`.

import 'package:dnolib/dnolib.dart' show Command, IFailure, IResult, Success;
import 'package:dnolib_example/modules/customers/commands/submit_customer_form.dart';
import 'package:dnolib_example/modules/customers/domain/customer.dart';
import 'package:dnolib_example/modules/customers/domain/customer_draft.dart';
import 'package:dnolib_example/modules/customers/domain/customer_repository.dart';
import 'package:flutter_test/flutter_test.dart';

class _SpyRepository implements CustomerRepository {
  var saveCalls = 0;
  Customer? saved;

  @override
  Future<IResult<List<Customer>, IFailure>> listCustomers({
    String? name,
  }) async => const Success(<Customer>[]);

  @override
  Command<int, String, Customer> saveCommand() {
    return Command<int, String, Customer>((customer) async {
      saveCalls++;
      saved = customer;
      return const Success(7);
    }, mapException: (error, _) => '$error');
  }

  @override
  Command<int, String, int> deleteCommand() => throw UnimplementedError();
}

CustomerDraft _validDraft() => CustomerDraft()
  ..name = 'Ana'
  ..cpf = '529.982.247-25'
  ..email = 'ana@example.com'
  ..cep = '01001-000'
  ..balance = '100,00';

void main() {
  group('submitCustomerForm', () {
    test('saldo inválido falha sem chamar o repositório', () async {
      final repository = _SpyRepository();
      final draft = _validDraft()..balance = 'invalido';

      final result = await submitCustomerForm(
        repository: repository,
        draft: draft,
      );

      expect(result.isFailure, isTrue);
      expect(repository.saveCalls, 0);
    });

    test('rascunho válido salva e devolve o cliente com id', () async {
      final repository = _SpyRepository();

      final result = await submitCustomerForm(
        repository: repository,
        draft: _validDraft(),
      );

      final customer = result.getOrNull()!;
      expect(customer.id, 7);
      expect(customer.name, 'Ana');
      expect(customer.cpf, '52998224725');
      expect(customer.cep, '01001000');
      expect(repository.saved?.name, 'Ana');
    });
  });
}
