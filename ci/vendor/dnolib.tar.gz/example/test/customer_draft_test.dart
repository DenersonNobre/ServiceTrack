// Rascunho mutável do formulário de clientes (sem TextEditingController).
// Fase Red: falha sem `modules/customers/domain/customer_draft.dart`.

import 'package:dnolib_example/modules/customers/domain/customer_draft.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('CustomerDraft', () {
    test('começa vazio', () {
      final draft = CustomerDraft();

      expect(draft.name, isEmpty);
      expect(draft.cpf, isEmpty);
      expect(draft.email, isEmpty);
      expect(draft.cep, isEmpty);
      expect(draft.balance, isEmpty);
    });

    test('clear esvazia todos os campos', () {
      final draft = CustomerDraft()
        ..name = 'Ana'
        ..cpf = '52998224725'
        ..email = 'ana@example.com'
        ..cep = '01001000'
        ..balance = '1.234,56';

      draft.clear();

      expect(draft.name, isEmpty);
      expect(draft.cpf, isEmpty);
      expect(draft.email, isEmpty);
      expect(draft.cep, isEmpty);
      expect(draft.balance, isEmpty);
    });
  });
}
