import 'package:dnolib/dnolib.dart' show KeyValue, Money, SqliteProvider;
import 'package:dnolib_example/core/database.dart';
import 'package:dnolib_example/modules/customers/data/customer_store.dart';
import 'package:dnolib_example/modules/customers/domain/customer.dart';
import 'package:dnolib_example/modules/orders/data/customer_order_store.dart';
import 'package:dnolib_example/modules/orders/domain/customer_order.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  setUpAll(sqfliteFfiInit);

  late CustomerStore store;
  late SqliteProvider provider;

  setUp(() {
    provider = openCustomerDatabase(
      dbName: 'example_${DateTime.now().microsecondsSinceEpoch}.db',
      factory: databaseFactoryFfi,
    );
    store = CustomerStore(provider);
    addTearDown(provider.close);
  });

  Customer newCustomer(String name, String minor) {
    return Customer(
      name: name,
      cpf: '52998224725',
      email: 'ana@example.com',
      cep: '01001000',
      balance: Money.fromBigInt(
        BigInt.parse(minor),
        currencyCode: 'BRL',
        scale: 2,
      ),
    );
  }

  test('salva via Command e lista com filtro e paginação', () async {
    final save = store.saveCommand();
    await save.run(newCustomer('Ana', '123456'));
    await save.run(newCustomer('Beto', '10000'));
    save.dispose();

    expect(save.result.value?.isSuccess, isTrue);

    final all = (await store.listCustomers()).getOrNull()!;
    expect(all.map((customer) => customer.name), ['Ana', 'Beto']);
    expect(
      all.first.balance.format(decimalSeparator: ',', groupSeparator: '.'),
      '1.234,56',
    );

    final filtered = (await store.listCustomers(name: 'Beto')).getOrNull()!;
    expect(filtered.map((customer) => customer.name), ['Beto']);

    final byId = await store.readById(
      KeyValue(key: 'id', value: all.first.id.toString()),
    );
    expect(Customer.fromMap(byId.getOrNull()!).name, 'Ana');

    await store.delete(KeyValue(key: 'id', value: all.first.id.toString()));
    final remaining = await store.listCustomers();
    expect(remaining.getOrNull(), hasLength(1));
  });

  test(
    'segunda tabela customer_orders persiste pedidos por customer_id',
    () async {
      final orderStore = CustomerOrderStore(provider);
      final saveCustomer = store.saveCommand();
      await saveCustomer.run(newCustomer('Ana', '5000'));
      await saveCustomer.run(newCustomer('Beto', '7000'));
      saveCustomer.dispose();

      final customers = (await store.listCustomers()).getOrNull()!;
      final anaId = customers.firstWhere((c) => c.name == 'Ana').id!;
      final betoId = customers.firstWhere((c) => c.name == 'Beto').id!;

      final saveOrder = orderStore.saveCommand();
      await saveOrder.run(
        CustomerOrder(
          customerId: anaId,
          description: 'Expresso',
          amount: Money.fromMinorUnits(850, currencyCode: 'BRL', scale: 2),
        ),
      );
      await saveOrder.run(
        CustomerOrder(
          customerId: betoId,
          description: 'Bolo',
          amount: Money.fromMinorUnits(1200, currencyCode: 'BRL', scale: 2),
        ),
      );
      saveOrder.dispose();

      final anaOrders = (await orderStore.listByCustomer(anaId)).getOrNull()!;
      expect(anaOrders.map((o) => o.description), ['Expresso']);
      expect(
        anaOrders.first.amount.format(
          decimalSeparator: ',',
          groupSeparator: '.',
        ),
        '8,50',
      );
    },
  );

  test(
    'segunda tabela customer_orders persiste pedidos por customer_id',
    () async {
      final orderStore = CustomerOrderStore(provider);
      final saveCustomer = store.saveCommand();
      await saveCustomer.run(newCustomer('Ana', '5000'));
      await saveCustomer.run(newCustomer('Beto', '7000'));
      saveCustomer.dispose();

      final customers = (await store.listCustomers()).getOrNull()!;
      final anaId = customers.firstWhere((c) => c.name == 'Ana').id!;
      final betoId = customers.firstWhere((c) => c.name == 'Beto').id!;

      final saveOrder = orderStore.saveCommand();
      await saveOrder.run(
        CustomerOrder(
          customerId: anaId,
          description: 'Expresso',
          amount: Money.fromMinorUnits(850, currencyCode: 'BRL', scale: 2),
        ),
      );
      await saveOrder.run(
        CustomerOrder(
          customerId: betoId,
          description: 'Bolo',
          amount: Money.fromMinorUnits(1200, currencyCode: 'BRL', scale: 2),
        ),
      );
      saveOrder.dispose();

      final anaOrders = (await orderStore.listByCustomer(anaId)).getOrNull()!;
      expect(anaOrders.map((o) => o.description), ['Expresso']);
      expect(
        anaOrders.first.amount.format(
          decimalSeparator: ',',
          groupSeparator: '.',
        ),
        '8,50',
      );
    },
  );
}
