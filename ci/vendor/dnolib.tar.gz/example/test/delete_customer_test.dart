// Caso de uso de exclusão de cliente (sem UI, sem Synapx).
// Fase Red: falha sem `modules/customers/commands/delete_customer.dart`.

import 'package:dnolib/dnolib.dart' show Command, IFailure, IResult, Success;
import 'package:dnolib_example/modules/customers/commands/delete_customer.dart';
import 'package:dnolib_example/modules/customers/domain/customer.dart';
import 'package:dnolib_example/modules/customers/domain/customer_repository.dart';
import 'package:flutter_test/flutter_test.dart';

class _SpyRepository implements CustomerRepository {
  var deleteCalls = 0;

  @override
  Future<IResult<List<Customer>, IFailure>> listCustomers({
    String? name,
  }) async => const Success(<Customer>[]);

  @override
  Command<int, String, Customer> saveCommand() => throw UnimplementedError();

  @override
  Command<int, String, int> deleteCommand() {
    return Command<int, String, int>((id) async {
      deleteCalls++;
      return Success(id!);
    }, mapException: (error, _) => '$error');
  }
}

void main() {
  group('deleteCustomer', () {
    test('exclui e devolve o id', () async {
      final repository = _SpyRepository();

      final result = await deleteCustomer(repository: repository, id: 3);

      expect(result.getOrNull(), 3);
      expect(repository.deleteCalls, 1);
    });

    test('falha da porta vira Failure com a mensagem', () async {
      final repository = _FailingRepository();

      final result = await deleteCustomer(repository: repository, id: 3);

      expect(result.isFailure, isTrue);
      expect(result.getOrNullFailure(), contains('boom'));
    });
  });
}

class _FailingRepository implements CustomerRepository {
  @override
  Future<IResult<List<Customer>, IFailure>> listCustomers({
    String? name,
  }) async => const Success(<Customer>[]);

  @override
  Command<int, String, Customer> saveCommand() => throw UnimplementedError();

  @override
  Command<int, String, int> deleteCommand() {
    return Command<int, String, int>(
      (_) async => throw StateError('boom'),
      mapException: (error, _) => '$error',
    );
  }
}
