# dnolib_example

App demo e ambiente oficial de POC da `dnolib`: consome a biblioteca
**exclusivamente pela facade** (`package:dnolib/dnolib.dart`, com `show`) e
serve de prova viva de integração real — além dos testes unitários da lib.

## O que demonstra

- **CRUD de clientes** com formulário validado (`brlib`: CPF, CEP, moeda),
  lista, persistência SQLite (`CustomerStore`) e cliente REST (`customer_api`).
- **Pedidos por cliente** em módulo-filho com escopo próprio, descartado no
  `pop` da rota.
- **POC Synapx**: `SynapxModule`/`SynapxModuleScope` hierárquico, `SynapxScope`
  (rebuild cirúrgico), `SynapxComputed` (ex.: `totalBalance`), `SynapxRouteGuard`
  (rota de resumo com guard autorizado/negado), `SynapxCommandView` e
  `SynapxTestScope` com overrides para testes isolados.
- **Testes**: unidade (stores, commands), widget (fluxos de tela) e SQLite real
  via `sqflite_common_ffi` no desktop — sem `testWidgets` com banco (DIP com
  `FakeCustomerRepository` em memória, cf. `LEARNINGS.md` da raiz).

## Como rodar

```bash
puro flutter pub get
puro flutter analyze --fatal-infos lib test
puro flutter test
```

No desktop (`windows/`, `linux/`, `macOS`), o SQLite usa `databaseFactoryFfi`;
no mobile/web, o factory nativo. `flutter run` escolhe o target da plataforma.

## Regras do ambiente

- Importar a `dnolib` **só pela facade** — gate mecânico em
  `test/example_facade_consumption_test.dart` (raiz) reprova barrels internos
  ou `src/`.
- É POC versionada junto da lib (workspace `melos`), não app publicado
  (`publish_to: none`).
