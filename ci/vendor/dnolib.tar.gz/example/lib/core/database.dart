import 'package:dnolib/dnolib.dart' show Migration, SqliteProvider;
import 'package:sqflite/sqflite.dart' show DatabaseFactory;

SqliteProvider openCustomerDatabase({
  required String dbName,
  DatabaseFactory? factory,
}) {
  return SqliteProvider(
    dbName: dbName,
    dbVersion: 2,
    migrations: [
      Migration(
        version: 1,
        scripts: [
          'CREATE TABLE customers ('
              'id INTEGER PRIMARY KEY AUTOINCREMENT, '
              'name TEXT NOT NULL, '
              'cpf TEXT NOT NULL, '
              'email TEXT NOT NULL, '
              'cep TEXT NOT NULL, '
              'balance_minor TEXT NOT NULL, '
              'currency TEXT NOT NULL, '
              'scale INTEGER NOT NULL)',
        ],
      ),
      Migration(
        version: 2,
        scripts: [
          'CREATE TABLE customer_orders ('
              'id INTEGER PRIMARY KEY AUTOINCREMENT, '
              'customer_id INTEGER NOT NULL, '
              'description TEXT NOT NULL, '
              'amount_minor TEXT NOT NULL, '
              'currency TEXT NOT NULL, '
              'scale INTEGER NOT NULL)',
        ],
      ),
    ],
    factory: factory,
  );
}
