import 'package:dnolib/dnolib.dart'
    show
        SynapxDisposable,
        SynapxGuardAllow,
        SynapxGuardReject,
        SynapxGuardResult,
        SynapxRouteContext,
        SynapxRouteGuard,
        SynapxRouteScope,
        SynapxContextExtension;
import 'package:flutter/material.dart';

import '../../customers/ui/.index.dart';

/// Fatia de rota protegida de resumo usando [SynapxRouteScope] com herança
/// automática do escopo pai e [SynapxRouteGuard].
class SummaryRoutePage extends StatelessWidget {
  const SummaryRoutePage({super.key, required this.allowSummary});

  final bool allowSummary;

  @override
  Widget build(BuildContext context) {
    return SynapxRouteScope(
      uri: Uri.parse('/resumo'),
      bind: (scope) => scope.registerLazySingleton<_SummaryDependency>(
        (_) => _SummaryDependency(),
      ),
      guards: [_SummaryGuard(allow: allowSummary)],
      rejectedBuilder: (_, reject) => Scaffold(
        appBar: AppBar(title: const Text('Acesso negado')),
        body: Center(child: Text(reject.reason ?? 'Sem permissão')),
      ),
      builder: (ctx) {
        ctx.get<_SummaryDependency>();
        final controller = ctx.get<CustomerController>();
        return Scaffold(
          appBar: AppBar(title: const Text('Resumo Synapx')),
          body: Center(
            child: Text('Total de clientes: ${controller.customers.length}'),
          ),
        );
      },
    );
  }
}

class _SummaryGuard implements SynapxRouteGuard {
  const _SummaryGuard({required this.allow});

  final bool allow;

  @override
  Future<SynapxGuardResult> canActivate(SynapxRouteContext context) async {
    return allow
        ? const SynapxGuardAllow()
        : const SynapxGuardReject('Acesso restrito ao resumo');
  }
}

class _SummaryDependency implements SynapxDisposable {
  @override
  void dispose() {}
}
