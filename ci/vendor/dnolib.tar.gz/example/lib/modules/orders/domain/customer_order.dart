import 'package:dnolib/dnolib.dart' show IMappable, Money;

/// Pedido vinculado a um cliente na segunda tabela SQLite (`customer_orders`).
class CustomerOrder extends IMappable {
  CustomerOrder({
    this.id,
    required this.customerId,
    required this.description,
    required this.amount,
  });

  final int? id;
  final int customerId;
  final String description;
  final Money amount;

  @override
  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'customer_id': customerId,
      'description': description,
      'amount_minor': amount.minorUnits.toString(),
      'currency': amount.currencyCode,
      'scale': amount.scale,
    };
  }

  static CustomerOrder fromMap(Map<String, dynamic> map) {
    return CustomerOrder(
      id: map['id'] as int?,
      customerId: map['customer_id'] as int,
      description: map['description'] as String,
      amount: Money.fromBigInt(
        BigInt.parse(map['amount_minor'].toString()),
        currencyCode: map['currency'] as String,
        scale: map['scale'] as int,
      ),
    );
  }
}
