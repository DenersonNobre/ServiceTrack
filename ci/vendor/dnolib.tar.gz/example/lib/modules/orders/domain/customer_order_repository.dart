import 'package:dnolib/dnolib.dart' show Command, IFailure, IResult;
import './customer_order.dart';

/// Contrato do repositório de pedidos por cliente.
abstract class CustomerOrderRepository {
  Future<IResult<List<CustomerOrder>, IFailure>> listByCustomer(int customerId);
  Command<int, String, CustomerOrder> saveCommand();
}
