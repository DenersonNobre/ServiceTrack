import 'package:dnolib/dnolib.dart'
    show
        Command,
        Failure,
        Filter,
        IFailure,
        IResult,
        ISqliteCrudDataSource,
        Paginate,
        Query,
        Success;
import '../domain/.index.dart';

/// Persistência SQLite de pedidos via CRUD do módulo `sqlite` (tabela `customer_orders`).
class CustomerOrderStore extends ISqliteCrudDataSource
    implements CustomerOrderRepository {
  CustomerOrderStore(super.sql) : super(resource: 'customer_orders');

  @override
  Future<IResult<List<CustomerOrder>, IFailure>> listByCustomer(
    int customerId,
  ) async {
    final result = await readAll(
      Query(
        filter: Filter({'customer_id': customerId}),
        paginate: Paginate(take: 50),
      ),
    );
    final rows = result.getOrNull();
    if (rows == null) return Failure(result.getOrNullFailure()!);
    return Success(rows.map(CustomerOrder.fromMap).toList());
  }

  @override
  Command<int, String, CustomerOrder> saveCommand() {
    return Command<int, String, CustomerOrder>((order) async {
      final result = await create(order!.toMap());
      final id = result.getOrNull();
      if (id == null) {
        return Failure('Falha ao salvar pedido: ${result.getOrNullFailure()}');
      }
      return Success(id as int);
    }, mapException: (error, _) => 'Falha ao salvar pedido: $error');
  }
}
