import 'package:dnolib/dnolib.dart'
    show
        Command,
        Failure,
        Money,
        Observable,
        SynapxList,
        Success,
        SynapxController;
import 'package:flutter/widgets.dart'
    show FormState, GlobalKey, TextEditingController;

import '../../customers/domain/.index.dart';
import '../commands/.index.dart';
import '../domain/.index.dart';

/// Controller escopado por rota para os pedidos de um [Customer].
class CustomerOrdersController extends SynapxController {
  CustomerOrdersController({
    required this.customer,
    required CustomerOrderRepository repository,
  }) : _repository = repository {
    loadOrders = trackCommand(
      Command<List<CustomerOrder>, String, int>((customerId) async {
        if (customerId == null) {
          return const Failure('Cliente sem identificador');
        }
        final result = await _repository.listByCustomer(customerId);
        return switch (result) {
          Success(:final value) => () {
            if (isActive) {
              orders.assign(value);
            }
            return Success<List<CustomerOrder>, String>(value);
          }(),
          Failure(:final value) => Failure<List<CustomerOrder>, String>(
            value.message,
          ),
        };
      }, mapException: (e, _) => '$e'),
    );
    onDispose(descriptionController.dispose);
    onDispose(amountController.dispose);
  }

  final Customer customer;
  final CustomerOrderRepository _repository;

  late final SynapxList<CustomerOrder> orders = list();
  late final Observable<String> error = obs('');
  late final Command<List<CustomerOrder>, String, int> loadOrders;

  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  final TextEditingController descriptionController = TextEditingController();
  final TextEditingController amountController = TextEditingController();

  Future<void> refresh() async {
    final customerId = customer.id;
    if (customerId == null) {
      return;
    }
    await loadOrders.run(customerId);
  }

  String? validateMoney(String? value) {
    final parsed = Money.tryParse(
      value,
      currencyCode: 'BRL',
      scale: 2,
      decimalSeparator: ',',
      groupSeparator: '.',
    );
    return parsed.isSuccess ? null : 'Valor inválido';
  }

  Future<void> submitForm() async {
    final customerId = customer.id;
    if (customerId == null || !(formKey.currentState?.validate() ?? false)) {
      return;
    }
    final outcome = await runIfActive(
      () => submitCustomerOrder(
        repository: _repository,
        customerId: customerId,
        description: descriptionController.text,
        amountText: amountController.text,
      ),
    );
    if (outcome == null) {
      return;
    }
    outcome.fold(
      onSuccess: (_) => error.value = '',
      onFailure: (failure) => error.value = failure,
    );
    if (outcome.isFailure) {
      return;
    }
    descriptionController.clear();
    amountController.clear();
    await refresh();
  }
}
