import 'package:dnolib/dnolib.dart'
    show
        NumberInputFormatter,
        SynapxRouteScope,
        SynapxCommandView,
        SynapxObserver,
        SynapxPage;
import 'package:flutter/material.dart';

import '../../customers/domain/.index.dart';
import '../customer_orders_module.dart';
import '../domain/.index.dart';
import './customer_orders_controller.dart';

/// Rota modular de pedidos de um [Customer], com [SynapxModuleScope] filho criado
/// sob demanda via [CustomerOrdersModule] e descartado automaticamente no pop.
class CustomerOrdersRoutePage extends StatelessWidget {
  const CustomerOrdersRoutePage({super.key, required this.customer});

  final Customer customer;

  @override
  Widget build(BuildContext context) {
    return SynapxRouteScope(
      uri: Uri.parse('/customers/${customer.id ?? 0}/orders'),
      module: CustomerOrdersModule(customer),
      builder: (_) => const _CustomerOrdersView(),
    );
  }
}

class _CustomerOrdersView extends SynapxPage<CustomerOrdersController> {
  const _CustomerOrdersView();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Pedidos de ${controller.customer.name}')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Form(
              key: controller.formKey,
              child: Column(
                children: [
                  TextFormField(
                    key: const Key('orderDescriptionField'),
                    controller: controller.descriptionController,
                    decoration: const InputDecoration(labelText: 'Descrição'),
                    validator: (value) => value == null || value.trim().isEmpty
                        ? 'Informe a descrição'
                        : null,
                  ),
                  TextFormField(
                    key: const Key('orderAmountField'),
                    controller: controller.amountController,
                    decoration: const InputDecoration(labelText: 'Valor (R\$)'),
                    keyboardType: TextInputType.number,
                    inputFormatters: [NumberInputFormatter()],
                    validator: controller.validateMoney,
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    key: const Key('saveOrderButton'),
                    onPressed: controller.submitForm,
                    child: const Text('Adicionar pedido'),
                  ),
                ],
              ),
            ),
            SynapxObserver<String>(
              observable: controller.error,
              builder: (_, error) {
                if (error.isEmpty) {
                  return const SizedBox.shrink();
                }
                return Text(
                  error,
                  style: TextStyle(color: Theme.of(context).colorScheme.error),
                );
              },
            ),
            const SizedBox(height: 16),
            Expanded(
              child: SynapxCommandView<List<CustomerOrder>, String, int>(
                command: controller.loadOrders,
                retryParam: controller.customer.id,
                onLoading: (_) =>
                    const Center(child: CircularProgressIndicator()),
                onEmpty: (_) =>
                    const Center(child: Text('Nenhum pedido cadastrado')),
                onError: (_, failure, retry) => Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(failure),
                      const SizedBox(height: 8),
                      TextButton(
                        onPressed: retry,
                        child: const Text('Tentar novamente'),
                      ),
                    ],
                  ),
                ),
                onSuccess: (_, orders) => ListView(
                  children: [
                    for (final order in orders)
                      ListTile(
                        title: Text(order.description),
                        trailing: Text(
                          'R\$ ${order.amount.format(decimalSeparator: ',', groupSeparator: '.')}',
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
