import 'package:dnolib/dnolib.dart' show SynapxModuleScope, SynapxModule;
import '../customers/domain/.index.dart';
import './domain/.index.dart';
import './ui/.index.dart';

/// Módulo declarativo da fatia de pedidos de um [Customer].
class CustomerOrdersModule extends SynapxModule {
  const CustomerOrdersModule(this.customer);

  final Customer customer;

  @override
  void binds(SynapxModuleScope scope) {
    scope.registerLazySingleton<CustomerOrdersController>(
      (s) => CustomerOrdersController(
        customer: customer,
        repository: s.get<CustomerOrderRepository>(),
      )..refresh(),
    );
  }
}
