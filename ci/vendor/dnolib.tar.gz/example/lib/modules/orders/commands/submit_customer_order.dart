// Caso de uso: salvar um pedido do cliente (commands destrinchado).
//
// Função pura sobre a porta [CustomerOrderRepository], espelho de
// `submitCustomerForm`: monta o [CustomerOrder], executa o `saveCommand` e
// devolve o pedido com o id atribuído — ou a falha como texto.

import 'package:dnolib/dnolib.dart' show Failure, IResult, Money, Success;
import '../domain/.index.dart';

/// Salva um pedido de [customerId] com [description] e [amountText] (`1,50`).
Future<IResult<CustomerOrder, String>> submitCustomerOrder({
  required CustomerOrderRepository repository,
  required int customerId,
  required String description,
  required String amountText,
}) async {
  final parsed = Money.tryParse(
    amountText,
    currencyCode: 'BRL',
    scale: 2,
    decimalSeparator: ',',
    groupSeparator: '.',
  );
  if (parsed.isFailure) {
    return const Failure('Valor inválido');
  }
  final order = CustomerOrder(
    customerId: customerId,
    description: description.trim(),
    amount: parsed.value!,
  );
  final save = repository.saveCommand();
  await save.run(order);
  final outcome = save.result.value;
  if (outcome == null) {
    return const Failure('Falha ao salvar pedido');
  }
  return outcome.fold(
    onSuccess: (id) => Success(
      CustomerOrder(
        id: id,
        customerId: order.customerId,
        description: order.description,
        amount: order.amount,
      ),
    ),
    onFailure: Failure.new,
  );
}
