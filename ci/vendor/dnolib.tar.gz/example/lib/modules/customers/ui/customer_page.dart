import 'package:dnolib/dnolib.dart' show SectionTitle, SynapxPage;
import 'package:flutter/material.dart';

import '../../summary/ui/.index.dart';
import './customer_controller.dart';
import './widgets/.index.dart';

/// Página principal da fatia de clientes usando [SynapxPage].
class CustomerPage extends SynapxPage<CustomerController> {
  const CustomerPage({super.key, this.allowSummary = true});

  final bool allowSummary;

  void _openSummary(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => SummaryRoutePage(allowSummary: allowSummary),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Clientes'),
        actions: [
          IconButton(
            key: const Key('summaryButton'),
            icon: const Icon(Icons.analytics_outlined),
            onPressed: () => _openSummary(context),
          ),
        ],
      ),
      body: const SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            CustomerTotalTile(),
            SizedBox(height: 16),
            SectionTitle(title: 'Novo cliente'),
            CustomerForm(),
            SizedBox(height: 16),
            SectionTitle(title: 'Clientes'),
            CustomerList(),
          ],
        ),
      ),
    );
  }
}
