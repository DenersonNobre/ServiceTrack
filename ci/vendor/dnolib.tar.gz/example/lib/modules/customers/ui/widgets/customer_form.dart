import 'package:dnolib/dnolib.dart'
    show
        CepInputFormatter,
        CepValidator,
        CpfInputFormatter,
        CpfValidator,
        NumberInputFormatter,
        SynapxObserver,
        SynapxPage;
import 'package:flutter/material.dart';

import '../customer_controller.dart';

/// Formulário de cadastro de clientes sem `StatefulWidget`, usando [SynapxPage]
/// e [SynapxScope] para erro reativo.
class CustomerForm extends SynapxPage<CustomerController> {
  const CustomerForm({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Form(
          key: controller.formKey,
          child: Column(
            children: [
              TextFormField(
                key: const Key('nameField'),
                initialValue: '',
                onChanged: (value) => controller.draft.name = value,
                decoration: const InputDecoration(labelText: 'Nome'),
                validator: (value) => value == null || value.trim().isEmpty
                    ? 'Informe o nome'
                    : null,
              ),
              TextFormField(
                key: const Key('cpfField'),
                initialValue: '',
                onChanged: (value) => controller.draft.cpf = value,
                decoration: const InputDecoration(labelText: 'CPF'),
                keyboardType: TextInputType.number,
                inputFormatters: [CpfInputFormatter()],
                validator: (value) =>
                    CpfValidator.isValid(value) ? null : 'CPF inválido',
              ),
              TextFormField(
                key: const Key('emailField'),
                initialValue: '',
                onChanged: (value) => controller.draft.email = value,
                decoration: const InputDecoration(labelText: 'E-mail'),
                keyboardType: TextInputType.emailAddress,
                validator: controller.emailValidator.validate,
              ),
              TextFormField(
                key: const Key('cepField'),
                initialValue: '',
                onChanged: (value) => controller.draft.cep = value,
                decoration: const InputDecoration(labelText: 'CEP'),
                keyboardType: TextInputType.number,
                inputFormatters: [CepInputFormatter()],
                validator: (value) =>
                    CepValidator.hasValidShape(value) ? null : 'CEP inválido',
              ),
              TextFormField(
                key: const Key('valueField'),
                initialValue: '',
                onChanged: (value) => controller.draft.balance = value,
                decoration: const InputDecoration(labelText: 'Saldo (R\$)'),
                keyboardType: TextInputType.number,
                inputFormatters: [NumberInputFormatter()],
                validator: controller.validateMoney,
              ),
              const SizedBox(height: 12),
              ElevatedButton(
                key: const Key('saveButton'),
                onPressed: controller.submitForm,
                child: const Text('Salvar'),
              ),
            ],
          ),
        ),
        SynapxObserver<String>(
          observable: controller.error,
          builder: (_, error) {
            if (error.isEmpty) {
              return const SizedBox.shrink();
            }
            return Text(
              error,
              key: const Key('errorText'),
              style: TextStyle(color: Theme.of(context).colorScheme.error),
            );
          },
        ),
      ],
    );
  }
}
