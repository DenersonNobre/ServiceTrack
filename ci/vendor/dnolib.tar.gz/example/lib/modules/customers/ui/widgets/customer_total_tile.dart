import 'package:dnolib/dnolib.dart' show StatTile, SynapxReactivePage;
import 'package:flutter/material.dart';

import '../customer_controller.dart';

/// Card reativo que exibe o total acumulado ([SynapxComputed]) e a quantidade de clientes.
class CustomerTotalTile extends SynapxReactivePage<CustomerController> {
  const CustomerTotalTile({super.key});

  @override
  Widget buildReactive(BuildContext context) {
    final total = controller.totalBalance.value;
    return StatTile(
      key: const Key('totalTile'),
      value: 'R\$ ${total.format(decimalSeparator: ',', groupSeparator: '.')}',
      label: '${controller.customers.length} clientes',
    );
  }
}
