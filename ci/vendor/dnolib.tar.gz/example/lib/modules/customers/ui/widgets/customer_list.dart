import 'package:dnolib/dnolib.dart'
    show SynapxDialogsExtension, SynapxReactivePage, formatCep, formatCpf;
import 'package:flutter/material.dart';

import '../../../orders/ui/customer_orders_page.dart';
import '../customer_controller.dart';

/// Lista reativa de clientes observando [CustomerController.customers].
class CustomerList extends SynapxReactivePage<CustomerController> {
  const CustomerList({super.key});

  @override
  Widget buildReactive(BuildContext context) {
    return Column(
      children: [
        for (final customer in controller.customers)
          ListTile(
            title: Text(customer.name),
            subtitle: Text(
              '${formatCpf(customer.cpf)} • ${formatCep(customer.cep)}',
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'R\$ ${customer.balance.format(decimalSeparator: ',', groupSeparator: '.')}',
                ),
                IconButton(
                  key: Key('delete_${customer.id}'),
                  icon: const Icon(Icons.delete_outline),
                  tooltip: 'Excluir',
                  onPressed: customer.id == null
                      ? null
                      : () async {
                          final confirmed = await context.confirm(
                            title: 'Excluir cliente?',
                            message:
                                'Excluir ${customer.name} permanentemente?',
                          );
                          if (!confirmed || !context.mounted) {
                            return;
                          }
                          await controller.deleteCustomer(customer.id!);
                        },
                ),
              ],
            ),
            onTap: customer.id == null
                ? null
                : () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) =>
                          CustomerOrdersRoutePage(customer: customer),
                    ),
                  ),
          ),
      ],
    );
  }
}
