import 'package:dnolib/dnolib.dart'
    show
        Money,
        Observable,
        SynapxComputed,
        SynapxController,
        SynapxList,
        ValidEmail;
import 'package:flutter/widgets.dart' show FormState, GlobalKey;

import '../commands/.index.dart' as commands;
import '../domain/.index.dart';

/// Controller reativo da POC Synapx em `./example` usando [SynapxController].
class CustomerController extends SynapxController {
  /// Janela anti-tecla do filtro por nome (tempo fake em teste: custo zero).
  static const searchDebounce = Duration(milliseconds: 250);

  CustomerController(this._repository) {
    debounce<String>(
      searchQuery,
      (query) => refresh(name: query.trim().isEmpty ? null : query.trim()),
      duration: searchDebounce,
    );
  }

  final CustomerRepository _repository;

  late final SynapxList<Customer> customers = list();
  late final SynapxComputed<Money> totalBalance = derived(() {
    var minor = BigInt.zero;
    for (final customer in customers) {
      minor += customer.balance.minorUnits;
    }
    return Money.fromBigInt(minor, currencyCode: 'BRL', scale: 2);
  });
  late final Observable<String> error = obs('');
  late final Observable<String> searchQuery = obs('');

  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  /// Rascunho editado pelo formulário (sem `TextEditingController`).
  final CustomerDraft draft = CustomerDraft();

  final ValidEmail emailValidator = ValidEmail();

  /// Carrega a lista de clientes do repositório para [customers].
  Future<void> refresh({String? name}) async {
    final result = await runIfActive(
      () => _repository.listCustomers(name: name),
    );
    if (result == null) {
      return;
    }
    customers.assign(result.getOrNull() ?? const <Customer>[]);
  }

  String? validateMoney(String? value) {
    final parsed = Money.tryParse(
      value,
      currencyCode: 'BRL',
      scale: 2,
      decimalSeparator: ',',
      groupSeparator: '.',
    );
    return parsed.isSuccess ? null : 'Valor inválido';
  }

  /// Valida o formulário, delega o salvamento ao caso de uso
  /// [submitCustomerForm] e recarrega a lista em caso de sucesso.
  Future<void> submitForm() async {
    if (!(formKey.currentState?.validate() ?? false)) {
      return;
    }
    final outcome = await runIfActive(
      () => commands.submitCustomerForm(
        repository: _repository,
        draft: draft,
      ),
    );
    if (outcome == null) {
      return;
    }
    outcome.fold(
      onSuccess: (_) {
        error.value = '';
        draft.clear();
        formKey.currentState?.reset();
      },
      onFailure: (failure) => error.value = failure,
    );
    if (outcome.isSuccess) {
      await refresh();
    }
  }

  /// Exclui o cliente [id] (após confirmação na UI) e recarrega a lista.
  Future<void> deleteCustomer(int id) async {
    final outcome = await runIfActive(
      () => commands.deleteCustomer(
        repository: _repository,
        id: id,
      ),
    );
    if (outcome == null) {
      return;
    }
    outcome.fold(
      onSuccess: (_) => error.value = '',
      onFailure: (failure) => error.value = failure,
    );
    if (outcome.isSuccess) {
      await refresh();
    }
  }
}
