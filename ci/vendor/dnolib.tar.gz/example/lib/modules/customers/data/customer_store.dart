import 'package:dnolib/dnolib.dart'
    show
        Command,
        Failure,
        Filter,
        IFailure,
        IResult,
        ISqliteCrudDataSource,
        KeyValue,
        Paginate,
        Query,
        Success;
import '../domain/.index.dart';

/// Persistência SQLite de clientes via CRUD do módulo `sqlite`.
class CustomerStore extends ISqliteCrudDataSource
    implements CustomerRepository {
  CustomerStore(super.sql) : super(resource: 'customers');

  @override
  Future<IResult<List<Customer>, IFailure>> listCustomers({
    String? name,
  }) async {
    final result = await readAll(
      Query(
        filter: name == null ? null : Filter({'name': name}),
        paginate: Paginate(take: 50),
      ),
    );
    final rows = result.getOrNull();
    if (rows == null) return Failure(result.getOrNullFailure()!);
    return Success(rows.map(Customer.fromMap).toList());
  }

  /// Salvamento com estado observável via [Command] do módulo `core`.
  @override
  Command<int, String, Customer> saveCommand() {
    return Command<int, String, Customer>((customer) async {
      final result = await create(customer!.toMap());
      final id = result.getOrNull();
      if (id == null) {
        return Failure('Falha ao salvar cliente: ${result.getOrNullFailure()}');
      }
      return Success(id as int);
    }, mapException: (error, _) => 'Falha ao salvar cliente: $error');
  }

  /// Exclusão com estado observável; devolve o id excluído.
  @override
  Command<int, String, int> deleteCommand() {
    return Command<int, String, int>((id) async {
      if (id == null) {
        return const Failure('Cliente sem identificador');
      }
      final result = await delete(KeyValue(key: 'id', value: id.toString()));
      if (result.isFailure) {
        return Failure(
          'Falha ao excluir cliente: ${result.getOrNullFailure()}',
        );
      }
      return Success(id);
    }, mapException: (error, _) => 'Falha ao excluir cliente: $error');
  }
}
