import 'package:dnolib/dnolib.dart' show IFailure, IResult, IRestCrudDataSource;

/// Sincronização de clientes via HTTP com o CRUD do módulo `rest`.
class CustomerApi extends IRestCrudDataSource {
  CustomerApi(super.config, super.api) : super(resource: 'customers');

  Future<IResult<List<Map<String, dynamic>>, IFailure>> fetchCustomers() =>
      readAll(null);
}
