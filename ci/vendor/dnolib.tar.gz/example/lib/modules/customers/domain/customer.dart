import 'package:dnolib/dnolib.dart' show IMappable, Money;

/// Cliente do app demo: nome, documentos brasileiros e saldo em [Money].
class Customer extends IMappable {
  Customer({
    this.id,
    required this.name,
    required this.cpf,
    required this.email,
    required this.cep,
    required this.balance,
  });

  final int? id;
  final String name;
  final String cpf;
  final String email;
  final String cep;
  final Money balance;

  @override
  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'name': name,
      'cpf': cpf,
      'email': email,
      'cep': cep,
      'balance_minor': balance.minorUnits.toString(),
      'currency': balance.currencyCode,
      'scale': balance.scale,
    };
  }

  static Customer fromMap(Map<String, dynamic> map) {
    return Customer(
      id: map['id'] as int?,
      name: map['name'] as String,
      cpf: map['cpf'] as String,
      email: map['email'] as String,
      cep: map['cep'] as String,
      balance: Money.fromBigInt(
        BigInt.parse(map['balance_minor'].toString()),
        currencyCode: map['currency'] as String,
        scale: map['scale'] as int,
      ),
    );
  }
}
