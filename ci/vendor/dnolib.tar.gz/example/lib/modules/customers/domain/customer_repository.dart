import 'package:dnolib/dnolib.dart' show Command, IFailure, IResult;
import './customer.dart';

/// Contrato do repositório de clientes para desacoplar a UI da persistência.
abstract class CustomerRepository {
  Future<IResult<List<Customer>, IFailure>> listCustomers({String? name});
  Command<int, String, Customer> saveCommand();
  Command<int, String, int> deleteCommand();
}
