/// Rascunho mutável do formulário de clientes.
///
/// Fonte de verdade da edição sem `TextEditingController`: os campos do
/// `Form` escrevem aqui via `onChanged` (com `initialValue` vazio) e o submit
/// lê daqui. Limpar o formulário é [clear] + `FormState.reset()`, sem
/// descartar nada (não há lifecycle para gerenciar).
class CustomerDraft {
  String name = '';
  String cpf = '';
  String email = '';
  String cep = '';
  String balance = '';

  void clear() {
    name = '';
    cpf = '';
    email = '';
    cep = '';
    balance = '';
  }
}
