// Caso de uso: salvar o cliente do rascunho (commands destrinchado).
//
// Função pura sobre a porta [CustomerRepository]: monta o [Customer] a partir
// do [CustomerDraft], executa o `saveCommand` e devolve o cliente com o id
// atribuído — ou a falha como texto. Não conhece UI, `Synapx` nem `Form`:
// erro observável e recarregamento continuam no controller (presentation).

import 'package:dnolib/dnolib.dart' show Failure, IResult, Money, Success;

import '../domain/.index.dart';

/// Salva o [draft] via [repository] e devolve o cliente persistido.
Future<IResult<Customer, String>> submitCustomerForm({
  required CustomerRepository repository,
  required CustomerDraft draft,
}) async {
  final parsed = Money.tryParse(
    draft.balance,
    currencyCode: 'BRL',
    scale: 2,
    decimalSeparator: ',',
    groupSeparator: '.',
  );
  if (parsed.isFailure) {
    return const Failure('Valor inválido');
  }
  final customer = Customer(
    name: draft.name.trim(),
    cpf: draft.cpf.replaceAll(RegExp(r'[^0-9]'), ''),
    email: draft.email.trim(),
    cep: draft.cep.replaceAll(RegExp(r'[^0-9]'), ''),
    balance: parsed.value!,
  );
  final save = repository.saveCommand();
  await save.run(customer);
  final outcome = save.result.value;
  if (outcome == null) {
    return const Failure('Falha ao salvar cliente');
  }
  return outcome.fold(
    onSuccess: (id) => Success(
      Customer(
        id: id,
        name: customer.name,
        cpf: customer.cpf,
        email: customer.email,
        cep: customer.cep,
        balance: customer.balance,
      ),
    ),
    onFailure: Failure.new,
  );
}
