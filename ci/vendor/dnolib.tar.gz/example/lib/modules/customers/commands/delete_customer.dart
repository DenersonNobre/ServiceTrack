// Caso de uso: exclusão de cliente (commands destrinchado).
//
// Função pura sobre a porta [CustomerRepository]: executa o `deleteCommand` e
// devolve o id excluído — ou a falha como texto. A confirmação (`confirm`)
// é decisão de UI e vive na camada `ui/`, nunca aqui.

import 'package:dnolib/dnolib.dart' show Failure, IResult, Success;

import '../domain/.index.dart';

/// Exclui o cliente [id] via [repository].
Future<IResult<int, String>> deleteCustomer({
  required CustomerRepository repository,
  required int id,
}) async {
  final remove = repository.deleteCommand();
  await remove.run(id);
  final outcome = remove.result.value;
  if (outcome == null) {
    return const Failure('Falha ao excluir cliente');
  }
  return outcome.fold(onSuccess: (_) => Success(id), onFailure: Failure.new);
}
