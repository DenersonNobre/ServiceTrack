import 'package:dnolib/dnolib.dart' show SynapxModuleScope, SynapxModule;

import '../modules/customers/domain/.index.dart';
import '../modules/customers/ui/.index.dart';
import '../modules/orders/domain/.index.dart';

/// Módulo raiz da aplicação declarando repositórios e [CustomerController].
class AppModule extends SynapxModule {
  const AppModule({required this.repository, required this.orderRepository});

  final CustomerRepository repository;
  final CustomerOrderRepository orderRepository;

  @override
  void binds(SynapxModuleScope scope) {
    scope
      ..registerInstance<CustomerRepository>(repository)
      ..registerInstance<CustomerOrderRepository>(orderRepository)
      ..registerLazySingleton<CustomerController>(
        (s) => CustomerController(s.get<CustomerRepository>())..refresh(),
      );
  }
}
