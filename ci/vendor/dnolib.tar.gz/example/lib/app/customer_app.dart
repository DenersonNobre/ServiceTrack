import 'package:dnolib/dnolib.dart'
    show Command, IFailure, IResult, Success, SynapxApp;
import 'package:flutter/material.dart';

import '../modules/customers/domain/.index.dart';
import '../modules/customers/ui/.index.dart';
import '../modules/orders/domain/.index.dart';
import 'app_module.dart';

/// Composition root da aplicação: configura [SynapxModuleScope] raiz,
/// [SynapxRouteObserver] e o [MaterialApp] nativo via [SynapxApp].
class CustomerApp extends StatelessWidget {
  const CustomerApp({
    super.key,
    required this.repository,
    this.orderRepository,
    this.allowSummary = true,
  });

  final CustomerRepository repository;
  final CustomerOrderRepository? orderRepository;
  final bool allowSummary;

  @override
  Widget build(BuildContext context) {
    return SynapxApp(
      module: AppModule(
        repository: repository,
        orderRepository: orderRepository ?? _InMemoryOrderRepository(),
      ),
      appBuilder: (_, observer) => MaterialApp(
        title: 'Clientes dnolib (Synapx POC)',
        navigatorObservers: [observer],
        home: CustomerPage(allowSummary: allowSummary),
      ),
    );
  }
}

class _InMemoryOrderRepository implements CustomerOrderRepository {
  final List<CustomerOrder> _orders = [];
  int _nextId = 1;

  @override
  Future<IResult<List<CustomerOrder>, IFailure>> listByCustomer(
    int customerId,
  ) async {
    return Success(
      _orders.where((order) => order.customerId == customerId).toList(),
    );
  }

  @override
  Command<int, String, CustomerOrder> saveCommand() {
    return Command<int, String, CustomerOrder>((order) async {
      final id = _nextId++;
      _orders.add(
        CustomerOrder(
          id: id,
          customerId: order!.customerId,
          description: order.description,
          amount: order.amount,
        ),
      );
      return Success(id);
    }, mapException: (error, _) => error.toString());
  }
}
