import 'dart:io' show Platform;

import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart'
    show databaseFactoryFfi, sqfliteFfiInit;

import 'app/customer_app.dart';
import 'core/database.dart';
import 'modules/customers/data/.index.dart';
import 'modules/orders/data/.index.dart';

export 'app/customer_app.dart';
export 'modules/customers/ui/customer_page.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  final isDesktop =
      !kIsWeb &&
      (Platform.isWindows || //
          Platform.isLinux ||
          Platform.isMacOS);

  if (isDesktop) {
    sqfliteFfiInit();
  }

  final database = openCustomerDatabase(
    dbName: 'customers.db',
    factory: isDesktop ? databaseFactoryFfi : null,
  );
  runApp(
    CustomerApp(
      repository: CustomerStore(database),
      orderRepository: CustomerOrderStore(database),
    ),
  );
}
