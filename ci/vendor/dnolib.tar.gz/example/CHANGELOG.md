# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## 0.2.0 — 2026-10-14

- **REFACTOR**(core): remove fábricas de `IResult` e renomeia `map` para `mapSuccess`.
- **REFACTOR**(core): unifica `Result` em `IResult` selado com `IFailure`.
- **FEAT**(core): extensão fluente `ObservableBindExtension` (`.bind`) e helper `bindOf<T>()`.
- **FEAT**(widgets): `PresenterView` e `PresenterScope` com getter `presenter` direto.
- **FEAT**(brlib,example): formatação monetária da direita para esquerda e integração no app demo.
- **FEAT**(example): app demo consumindo dnolib exclusivamente via facade.
- **FIX**(example): `Customer` usa `IMappable` em vez de `Mappable`.
