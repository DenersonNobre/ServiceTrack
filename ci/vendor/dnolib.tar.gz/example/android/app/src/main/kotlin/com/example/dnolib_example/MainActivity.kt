package com.example.dnolib_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
