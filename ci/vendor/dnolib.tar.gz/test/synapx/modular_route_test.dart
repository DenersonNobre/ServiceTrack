// Testes do SynapxRouteScope (slice 0.2): integração de SynapxModuleScope + guards.

import 'dart:async';

import 'package:dnolib/dnolib.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

class _ScopedDep implements SynapxDisposable {
  var disposed = false;

  @override
  void dispose() => disposed = true;
}

class _AsyncGuard implements SynapxRouteGuard {
  _AsyncGuard(this._fn);

  final Future<SynapxGuardResult> Function(SynapxRouteContext context) _fn;

  @override
  Future<SynapxGuardResult> canActivate(SynapxRouteContext context) =>
      _fn(context);
}

void main() {
  group('SynapxRouteScope', () {
    testWidgets(
      'sem guards monta síncrono com SynapxModuleScope e descarta no pop',
      (
        tester,
      ) async {
        late _ScopedDep dep;

        await tester.pumpWidget(
          Directionality(
            textDirection: TextDirection.ltr,
            child: SynapxRouteScope(
              createScope: (_) {
                dep = _ScopedDep();
                return SynapxModuleScope()
                  ..registerInstance<_ScopedDep>(dep, owned: true);
              },
              builder: (context) {
                SynapxProvider.of(context).get<_ScopedDep>();
                return const Text('ok');
              },
            ),
          ),
        );

        expect(find.text('ok'), findsOneWidget);
        expect(dep.disposed, isFalse);

        await tester.pumpWidget(const SizedBox.shrink());
        expect(dep.disposed, isTrue);
      },
    );

    testWidgets('pop durante guard assíncrono cancela e descarta sem vazar', (
      tester,
    ) async {
      final completer = Completer<SynapxGuardResult>();
      late _ScopedDep dep;
      var redirected = false;

      await tester.pumpWidget(
        Directionality(
          textDirection: TextDirection.ltr,
          child: SynapxRouteScope(
            createScope: (_) {
              dep = _ScopedDep();
              return SynapxModuleScope()
                ..registerInstance<_ScopedDep>(dep, owned: true);
            },
            guards: [_AsyncGuard((_) => completer.future)],
            contextBuilder: (_) =>
                SynapxRouteContext(uri: Uri.parse('/protegida')),
            loadingBuilder: (_) => const Text('carregando'),
            onRedirect: (_, __) => redirected = true,
            builder: (_) => const Text('conteudo'),
          ),
        ),
      );

      expect(find.text('carregando'), findsOneWidget);

      // Desmonta antes de o guard resolver.
      await tester.pumpWidget(const SizedBox.shrink());
      expect(dep.disposed, isTrue);

      completer.complete(SynapxGuardRedirect(Uri.parse('/login')));
      await tester.pump();
      expect(redirected, isFalse);
    });

    testWidgets('guard negado exibe rejectedBuilder', (tester) async {
      await tester.pumpWidget(
        Directionality(
          textDirection: TextDirection.ltr,
          child: SynapxRouteScope(
            createScope: (_) => SynapxModuleScope(),
            guards: [
              _AsyncGuard((_) async => const SynapxGuardReject('bloqueado')),
            ],
            contextBuilder: (_) =>
                SynapxRouteContext(uri: Uri.parse('/privada')),
            rejectedBuilder: (_, reject) => Text(reject.reason ?? ''),
            builder: (_) => const Text('conteudo'),
          ),
        ),
      );

      await tester.pumpAndSettle();
      expect(find.text('bloqueado'), findsOneWidget);
    });
  });
}
