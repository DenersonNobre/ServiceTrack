import 'package:dnolib/dnolib.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('Slice E3 — SynapxApp.appBuilder', () {
    testWidgets(
      'appBuilder entrega BuildContext e SynapxRouteObserver sem placeholders',
      (tester) async {
        SynapxRouteObserver? receivedObserver;

        await tester.pumpWidget(
          Directionality(
            textDirection: TextDirection.ltr,
            child: SynapxApp(
              appBuilder: (context, observer) {
                receivedObserver = observer;
                return const Text('app-ok');
              },
            ),
          ),
        );

        expect(find.text('app-ok'), findsOneWidget);
        expect(receivedObserver, isNotNull);
      },
    );

    test('exige exatamente um entre builder ou appBuilder', () {
      expect(
        SynapxApp.new,
        throwsAssertionError,
      );
      expect(
        () => SynapxApp(
          builder: (_, __, ___) => const SizedBox.shrink(),
          appBuilder: (_, __) => const SizedBox.shrink(),
        ),
        throwsAssertionError,
      );
    });
  });
}
