// Testes da camada ergonômica do Synapx: SynapxApp, context.get<T>() e
// SynapxRouteScope(bind: ...).

import 'package:dnolib/dnolib.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

class _AppService implements SynapxDisposable {
  var disposed = false;

  @override
  void dispose() => disposed = true;
}

class _RouteService implements SynapxDisposable {
  var disposed = false;

  @override
  void dispose() => disposed = true;
}

void main() {
  group('Ergonomia Synapx', () {
    testWidgets(
      'SynapxApp provê SynapxModuleScope e SynapxRouteObserver e descarta ao desmontar',
      (tester) async {
        late _AppService service;

        await tester.pumpWidget(
          SynapxApp(
            bind: (scope) {
              service = _AppService();
              scope.registerInstance<_AppService>(service, owned: true);
            },
            builder: (context, scope, observer) => MaterialApp(
              navigatorObservers: [observer],
              home: Builder(
                builder: (ctx) {
                  final resolved = ctx.get<_AppService>();
                  expect(resolved, same(service));
                  expect(ctx.tryGet<String>(), isNull);
                  expect(ctx.scope, same(scope));
                  expect(observer.activeRoutesCount, 1);
                  return const Text('ok');
                },
              ),
            ),
          ),
        );

        expect(find.text('ok'), findsOneWidget);
        expect(service.disposed, isFalse);

        await tester.pumpWidget(const SizedBox.shrink());
        expect(service.disposed, isTrue);
      },
    );

    testWidgets(
      'SynapxRouteScope(bind: ...) herda escopo pai automaticamente e descarta filho no pop',
      (tester) async {
        late _AppService appService;
        late _RouteService routeService;

        await tester.pumpWidget(
          SynapxApp(
            bind: (scope) {
              appService = _AppService();
              scope.registerInstance<_AppService>(appService, owned: true);
            },
            builder: (_, __, observer) => MaterialApp(
              navigatorObservers: [observer],
              home: Builder(
                builder: (ctx) => ElevatedButton(
                  onPressed: () {
                    Navigator.of(ctx).push(
                      MaterialPageRoute<void>(
                        builder: (_) => SynapxRouteScope(
                          bind: (child) {
                            routeService = _RouteService();
                            child.registerInstance<_RouteService>(
                              routeService,
                              owned: true,
                            );
                          },
                          builder: (innerCtx) {
                            expect(
                              innerCtx.get<_AppService>(),
                              same(appService),
                            );
                            expect(
                              innerCtx.get<_RouteService>(),
                              same(routeService),
                            );
                            return Scaffold(
                              appBar: AppBar(),
                              body: const Text('rota_filha'),
                            );
                          },
                        ),
                      ),
                    );
                  },
                  child: const Text('abrir'),
                ),
              ),
            ),
          ),
        );

        await tester.tap(find.text('abrir'));
        await tester.pumpAndSettle();
        expect(find.text('rota_filha'), findsOneWidget);
        expect(routeService.disposed, isFalse);

        await tester.pageBack();
        await tester.pumpAndSettle();
        expect(routeService.disposed, isTrue);
        expect(appService.disposed, isFalse);
      },
    );
  });
}
