// Contrato do SynapxScope (slice 0.1b): rebuild cirúrgico e descarte de tokens.

import 'package:dnolib/dnolib.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('SynapxScope', () {
    testWidgets('reconstrói apenas quando um Observable lido no frame muda', (
      tester,
    ) async {
      final count = Observable<int>(0);
      final unread = Observable<int>(100);
      var builds = 0;

      await tester.pumpWidget(
        Directionality(
          textDirection: TextDirection.ltr,
          child: SynapxScope(
            builder: (_) {
              builds++;
              return Text('${count.value}');
            },
          ),
        ),
      );

      expect(find.text('0'), findsOneWidget);
      expect(builds, 1);

      unread.value = 200;
      await tester.pump();
      expect(builds, 1);

      count.value = 1;
      await tester.pump();
      expect(find.text('1'), findsOneWidget);
      expect(builds, 2);
    });

    testWidgets(
      'cancela assinatura de Observable que deixou de ser lido no frame',
      (tester) async {
        final showSecondary = Observable<bool>(true);
        final secondary = Observable<String>('B');
        var builds = 0;

        await tester.pumpWidget(
          Directionality(
            textDirection: TextDirection.ltr,
            child: SynapxScope(
              builder: (_) {
                builds++;
                final text = showSecondary.value ? secondary.value : 'hidden';
                return Text(text);
              },
            ),
          ),
        );

        expect(find.text('B'), findsOneWidget);
        expect(builds, 1);

        showSecondary.value = false;
        await tester.pump();
        expect(find.text('hidden'), findsOneWidget);
        expect(builds, 2);

        // Alterar secondary agora não deve mais causar rebuild.
        secondary.value = 'C';
        await tester.pump();
        expect(builds, 2);
      },
    );

    testWidgets('cancela todas as assinaturas ao desmontar o widget', (
      tester,
    ) async {
      final count = Observable<int>(0);
      var builds = 0;

      await tester.pumpWidget(
        Directionality(
          textDirection: TextDirection.ltr,
          child: SynapxScope(
            builder: (_) {
              builds++;
              return Text('${count.value}');
            },
          ),
        ),
      );

      expect(builds, 1);

      await tester.pumpWidget(const SizedBox.shrink());

      count.value = 1;
      await tester.pump();
      expect(builds, 1);
    });
  });
}
