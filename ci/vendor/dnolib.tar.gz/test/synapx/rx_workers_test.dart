// Contrato dos workers puros (slice 0.1a): `ever`, `once`, `SynapxEffect.debounce` e
// `SynapxEffect.interval` sobre qualquer `Observable`, com descarte via token.
// Fase Red: estes testes falham contra os stubs sem comportamento.

import 'dart:async';

import 'package:dnolib/core/core.dart';
import 'package:dnolib/synapx/synapx.dart';
import 'package:fake_async/fake_async.dart';
import 'package:test/test.dart';

void main() {
  group('ever', () {
    test('dispara a cada mudança, sem replay inicial', () {
      final rx = Observable<int>(0);
      final received = <int>[];
      SynapxEffect.ever<int>(rx, received.add);

      rx
        ..value = 1
        ..value = 2;

      expect(received, [1, 2]);
    });

    test('cancel interrompe as próximas reações', () {
      final rx = Observable<int>(0);
      final received = <int>[];
      final token = SynapxEffect.ever<int>(rx, received.add);

      rx.value = 1;
      token.cancel();
      rx.value = 2;

      expect(received, [1]);
    });
  });

  group('once', () {
    test('dispara só no primeiro evento', () {
      final rx = Observable<int>(0);
      final received = <int>[];
      SynapxEffect.once<int>(rx, received.add);

      rx
        ..value = 1
        ..value = 2;

      expect(received, [1]);
    });

    test('mutação reentrante fixa dentro do callback não re-dispara', () {
      final rx = Observable<int>(0);
      final received = <int>[];
      SynapxEffect.once<int>(rx, (v) {
        received.add(v);
        rx.value = 99;
      });

      rx.value = 1;

      expect(received, [1]);
      expect(rx.value, 99);
    });
  });

  group('SynapxEffect.debounce', () {
    test('emite só a última após a janela (FakeAsync)', () {
      fakeAsync((async) {
        final rx = Observable<int>(0);
        final received = <int>[];
        SynapxEffect.debounce<int>(
          rx,
          received.add,
          duration: const Duration(milliseconds: 100),
        );

        rx.value = 1;
        rx.value = 2;
        async.elapse(const Duration(milliseconds: 99));
        expect(received, isEmpty);

        async.elapse(const Duration(milliseconds: 1));
        expect(received, [2]);
      });
    });

    test('cancel antes da janela impede o disparo tardio', () {
      fakeAsync((async) {
        final rx = Observable<int>(0);
        final received = <int>[];
        final token = SynapxEffect.debounce<int>(
          rx,
          received.add,
          duration: const Duration(milliseconds: 100),
        );

        rx.value = 1;
        token.cancel();
        async.elapse(const Duration(milliseconds: 500));

        expect(received, isEmpty);
      });
    });
  });

  group('SynapxEffect.interval', () {
    test('throttle em janela fixa: primeiro passa, resto da janela ignora', () {
      fakeAsync((async) {
        final rx = Observable<int>(0);
        final received = <int>[];
        SynapxEffect.interval<int>(
          rx,
          received.add,
          duration: const Duration(milliseconds: 100),
        );

        rx.value = 1; // dispara
        rx.value = 2; // ignorado (janela)
        async.elapse(const Duration(milliseconds: 100));
        rx.value = 3; // dispara (janela nova)

        expect(received, [1, 3]);
      });
    });

    test('cancel zera o timer e silencia eventos futuros', () {
      fakeAsync((async) {
        final rx = Observable<int>(0);
        final received = <int>[];
        final token = SynapxEffect.interval<int>(
          rx,
          received.add,
          duration: const Duration(milliseconds: 100),
        );

        rx.value = 1;
        token.cancel();
        async.elapse(const Duration(milliseconds: 100));
        rx.value = 2;

        expect(received, [1]);
      });
    });

    test('exceção no callback não trava a janela de throttle', () {
      fakeAsync((async) {
        final rx = Observable<int>(0);
        final received = <int>[];
        final errors = <Object>[];

        runZonedGuarded(() {
          SynapxEffect.interval<int>(rx, (v) {
            if (v == 1) {
              throw StateError('falha no callback');
            }
            received.add(v);
          }, duration: const Duration(milliseconds: 100));
          rx.value = 1;
        }, (error, _) => errors.add(error));

        async.elapse(const Duration(milliseconds: 100));
        rx.value = 2;

        expect(errors, hasLength(1));
        expect(received, [2]);
      });
    });
  });
}
