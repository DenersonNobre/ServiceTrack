// Gate de identidade do Synapx (slice E0): toda declaração pública em
// `lib/synapx/src/**` deve usar o prefixo `Synapx` (extensions com sufixo
// `Extension`). Inclui prova negativa para garantir que o gate realmente
// reprova um símbolo fora do padrão.
//
// Dependências: SDK (`dart:io`) e `package:test`.

import 'dart:io';

import 'package:test/test.dart';

// Modificadores opcionais + tipo de declaração + nome.
final RegExp _declaration = RegExp(
  r'^(?:abstract\s+|final\s+|sealed\s+|base\s+|interface\s+)*'
  r'(?:class|mixin|enum|extension(?:\s+type)?|typedef)\s+([A-Za-z_]\w*)',
);

/// Nomes públicos violando a identidade (fora do prefixo `Synapx`).
List<String> identityViolations(Iterable<String> lines) {
  final offenders = <String>[];
  for (final line in lines) {
    final match = _declaration.firstMatch(line);
    if (match == null) {
      continue;
    }
    final name = match.group(1)!;
    if (name.startsWith('_') || name.startsWith('Synapx')) {
      continue;
    }
    offenders.add(name);
  }
  return offenders;
}

void main() {
  test('gate reprova declaração pública fora do padrão (prova negativa)', () {
    expect(identityViolations(['class LegacyThing {}']), ['LegacyThing']);
    expect(
      identityViolations(['extension LegacyExtension on Object {}']),
      ['LegacyExtension'],
    );
    expect(identityViolations(['class SynapxOk {}']), isEmpty);
    expect(identityViolations(['class _PrivateOk {}']), isEmpty);
  });

  test('todo componente público de lib/synapx/src usa o prefixo Synapx', () {
    final root = Directory('lib/synapx/src');
    expect(root.existsSync(), isTrue, reason: 'diretório do módulo ausente');

    final offenders = <String>[];
    final files =
        root
            .listSync(recursive: true)
            .whereType<File>()
            .where((file) => file.path.endsWith('.dart'))
            .toList()
          ..sort((a, b) => a.path.compareTo(b.path));

    for (final file in files) {
      final violations = identityViolations(file.readAsLinesSync());
      for (final name in violations) {
        offenders.add('${file.path}: $name');
      }
    }

    expect(offenders, isEmpty, reason: 'Sem prefixo Synapx: $offenders');
  });
}
