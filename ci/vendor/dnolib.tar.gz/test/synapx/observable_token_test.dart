// Contrato novo de [ObservableToken] e [Observable] (slice 0.1a):
// gancho `onCancel` (uma vez, em `cancel()` e em `dispose()`), notificação
// pública via `notify()` e isolamento de erro em `_notify()`.
// Fase Red: estes testes falham contra o `core` atual.

import 'dart:async';

import 'package:dnolib/core/core.dart';
import 'package:test/test.dart';

void main() {
  group('ObservableToken.onCancel', () {
    test('executa uma única vez mesmo com cancel repetido', () {
      var calls = 0;
      final token = Observable<int>(0).on((_) {}, onCancel: () => calls++);

      token
        ..cancel()
        ..cancel();

      expect(calls, 1);
    });

    test('executa quando o observable é descartado', () {
      var calls = 0;
      final observable = Observable<int>(0);
      observable.on((_) {}, onCancel: () => calls++);

      observable.dispose();

      expect(calls, 1);
    });

    test('sem onCancel, cancel e dispose seguem normais', () {
      final token = Observable<int>(0).on((_) {});

      expect(token.cancel, returnsNormally);
      expect(token.isActive, isFalse);
    });

    test('erro no onCancel vai para a Zone sem quebrar o cancel', () {
      Object? captured;
      late ObservableToken<int> token;
      runZonedGuarded(() {
        final observable = Observable<int>(0);
        token = observable.on(
          (_) {},
          onCancel: () => throw StateError('gancho falhou'),
        );
        token.cancel();
      }, (error, _) => captured = error);

      expect(token.isActive, isFalse);
      expect(captured, isStateError);
    });
  });

  group('Observable.notify', () {
    test('notifica assinantes com o valor corrente sem alterá-lo', () {
      final received = <int>[];
      final observable = Observable<int>(7)..on(received.add);

      observable.notify();

      expect(received, [7]);
      expect(observable.value, 7);
    });

    test('após dispose, notify é ignorado', () {
      final received = <int>[];
      final observable = Observable<int>(7)
        ..on(received.add)
        ..dispose();

      observable.notify();

      expect(received, isEmpty);
    });
  });

  group('Isolamento de erro em _notify', () {
    test('exceção em um listener não bloqueia os demais', () {
      final received = <int>[];
      Object? captured;
      runZonedGuarded(() {
        final observable = Observable<int>(0)
          ..on((_) => throw StateError('ouvinte falhou'))
          ..on(received.add);
        observable.value = 1;
      }, (error, _) => captured = error);

      expect(received, [1]);
      expect(captured, isStateError);
    });
  });
}
