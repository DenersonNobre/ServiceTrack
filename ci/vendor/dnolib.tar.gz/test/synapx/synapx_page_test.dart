// Contrato do SynapxPage<T> (injeção automática de controller via SynapxModuleScope).

import 'package:dnolib/dnolib.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

class _TestController implements SynapxDisposable {
  _TestController(this.label);

  final String label;
  final Observable<int> count = Observable<int>(0);
  var disposed = false;

  void increment() => count.value++;

  @override
  void dispose() {
    disposed = true;
    count.dispose();
  }
}

class _CounterPage extends SynapxPage<_TestController> {
  const _CounterPage();

  _TestController readController() => controller;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SynapxScope(builder: (_) => Text('${controller.count.value}')),
        ElevatedButton(
          onPressed: controller.increment,
          child: const Text('inc'),
        ),
      ],
    );
  }
}

class _NamedPage extends SynapxPage<_TestController> {
  const _NamedPage();

  @override
  String? get tag => 'vip';

  @override
  Widget build(BuildContext context) => Text(controller.label);
}

void main() {
  group('SynapxPage', () {
    testWidgets('resolve controller dentro do build e em callbacks de evento', (
      tester,
    ) async {
      await tester.pumpWidget(
        SynapxApp(
          bind: (scope) => scope.registerLazySingleton<_TestController>(
            (_) => _TestController('padrao'),
          ),
          builder: (_, __, observer) => MaterialApp(
            navigatorObservers: [observer],
            home: const Scaffold(body: _CounterPage()),
          ),
        ),
      );

      expect(find.text('0'), findsOneWidget);

      await tester.tap(find.text('inc'));
      await tester.pump();
      expect(find.text('1'), findsOneWidget);
    });

    testWidgets('respeita qualificador tag ao resolver do SynapxModuleScope', (
      tester,
    ) async {
      await tester.pumpWidget(
        SynapxProvider(
          create: (_) => SynapxModuleScope()
            ..registerInstance<_TestController>(_TestController('normal'))
            ..registerInstance<_TestController>(
              _TestController('vip-instance'),
              name: 'vip',
            ),
          child: const Directionality(
            textDirection: TextDirection.ltr,
            child: _NamedPage(),
          ),
        ),
      );

      expect(find.text('vip-instance'), findsOneWidget);
    });

    testWidgets('lança StateError antes da montagem e após unmount', (
      tester,
    ) async {
      const page = _CounterPage();
      expect(page.readController, throwsStateError);

      await tester.pumpWidget(
        SynapxProvider(
          create: (_) =>
              SynapxModuleScope()
                ..registerInstance<_TestController>(_TestController('a')),
          child: const Directionality(
            textDirection: TextDirection.ltr,
            child: page,
          ),
        ),
      );
      expect(page.readController().label, 'a');

      await tester.pumpWidget(const SizedBox.shrink());
      expect(page.readController, throwsStateError);
    });
  });
}
