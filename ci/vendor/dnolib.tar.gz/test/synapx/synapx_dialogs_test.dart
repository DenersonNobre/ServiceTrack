// Atalhos de UI com contexto explícito (delta GetX sem armadilha global):
// `confirm` e `notifySuccess`/`notifyError` sobre [BuildContext], sem chave
// global de navegação. Fase Red: falham (não compilam) sem `synapx_dialogs.dart`.

import 'package:dnolib/dnolib.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('SynapxDialogsExtension', () {
    testWidgets('confirm devolve true ao confirmar', (tester) async {
      var result = false;

      await tester.pumpWidget(
        MaterialApp(
          home: Builder(
            builder: (context) => ElevatedButton(
              onPressed: () async {
                result = await context.confirm(
                  title: 'Sair?',
                  message: 'Descartar alterações?',
                );
              },
              child: const Text('abrir'),
            ),
          ),
        ),
      );

      await tester.tap(find.text('abrir'));
      await tester.pumpAndSettle();
      expect(find.text('Sair?'), findsOneWidget);

      await tester.tap(find.text('Confirmar'));
      await tester.pumpAndSettle();

      expect(result, isTrue);
    });

    testWidgets('confirm devolve false ao cancelar', (tester) async {
      var result = true;

      await tester.pumpWidget(
        MaterialApp(
          home: Builder(
            builder: (context) => ElevatedButton(
              onPressed: () async {
                result = await context.confirm(
                  title: 'Sair?',
                  message: 'Descartar alterações?',
                );
              },
              child: const Text('abrir'),
            ),
          ),
        ),
      );

      await tester.tap(find.text('abrir'));
      await tester.pumpAndSettle();

      await tester.tap(find.text('Cancelar'));
      await tester.pumpAndSettle();

      expect(result, isFalse);
    });

    testWidgets('notifySuccess exibe a mensagem', (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Builder(
              builder: (context) => ElevatedButton(
                onPressed: () => context.notifySuccess('Tudo certo'),
                child: const Text('ok'),
              ),
            ),
          ),
        ),
      );

      await tester.tap(find.text('ok'));
      await tester.pump();

      expect(find.textContaining('Tudo certo'), findsOneWidget);
    });

    testWidgets('notifyError exibe a mensagem', (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Builder(
              builder: (context) => ElevatedButton(
                onPressed: () => context.notifyError('Algo falhou'),
                child: const Text('ok'),
              ),
            ),
          ),
        ),
      );

      await tester.tap(find.text('ok'));
      await tester.pump();

      expect(find.textContaining('Algo falhou'), findsOneWidget);
    });
  });
}
