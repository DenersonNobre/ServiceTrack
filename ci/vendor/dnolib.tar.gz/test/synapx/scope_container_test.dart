// Contrato do SynapxModuleScope hierárquico com qualificador e ownership (slice 0.1c).

import 'package:dnolib/synapx/synapx.dart';
import 'package:test/test.dart';

class _Service implements SynapxDisposable {
  _Service(this.label);

  final String label;
  var disposed = false;

  @override
  void dispose() => disposed = true;
}

class _CompositeService {
  _CompositeService(this.dep);
  final _Service dep;
}

void main() {
  group('SynapxModuleScope', () {
    test('registerFactory cria nova instância a cada get e recebe scope', () {
      final scope = SynapxModuleScope();
      scope.registerInstance<_Service>(_Service('dep'));
      scope.registerFactory<_CompositeService>(
        (s) => _CompositeService(s.get<_Service>()),
      );

      final a = scope.get<_CompositeService>();
      final b = scope.get<_CompositeService>();

      expect(identical(a, b), isFalse);
      expect(a.dep.label, 'dep');
    });

    test('registerLazySingleton só materializa no primeiro get', () {
      final scope = SynapxModuleScope();
      var builds = 0;
      scope.registerLazySingleton<_Service>((_) {
        builds++;
        return _Service('lazy');
      });

      expect(builds, 0);
      final first = scope.get<_Service>();
      final second = scope.get<_Service>();

      expect(builds, 1);
      expect(identical(first, second), isTrue);

      scope.dispose();
      expect(first.disposed, isTrue);
    });

    test('lazy singleton nunca acessado não é instanciado no dispose', () {
      final scope = SynapxModuleScope();
      var builds = 0;
      scope.registerLazySingleton<_Service>((_) {
        builds++;
        return _Service('never');
      });

      scope.dispose();

      expect(builds, 0);
    });

    test('registerInstance respeita ownership (owned: false por padrão)', () {
      final external = _Service('external');
      final owned = _Service('owned');
      final scope = SynapxModuleScope()
        ..registerInstance<_Service>(external, name: 'ext')
        ..registerInstance<_Service>(owned, name: 'own', owned: true);

      scope.dispose();

      expect(external.disposed, isFalse);
      expect(owned.disposed, isTrue);
    });

    test('qualificador por nome distingue registros do mesmo tipo', () {
      final scope = SynapxModuleScope()
        ..registerInstance<String>('primary', name: 'a')
        ..registerInstance<String>('secondary', name: 'b');

      expect(scope.get<String>(name: 'a'), 'primary');
      expect(scope.get<String>(name: 'b'), 'secondary');
      expect(scope.tryGet<String>(), isNull);
      expect(() => scope.get<String>(), throwsStateError);
    });

    test('hierarquia resolve do pai e dispose do filho preserva o pai', () {
      final parent = SynapxModuleScope()
        ..registerLazySingleton<_Service>((_) => _Service('parent'));
      final child = SynapxModuleScope(parent: parent)
        ..registerLazySingleton<_Service>(
          (_) => _Service('child'),
          name: 'local',
        );

      final fromParent = child.get<_Service>();
      final fromChild = child.get<_Service>(name: 'local');

      expect(fromParent.label, 'parent');
      expect(fromChild.label, 'child');

      child.dispose();

      expect(fromChild.disposed, isTrue);
      expect(fromParent.disposed, isFalse);
      expect(parent.get<_Service>(), same(fromParent));

      parent.dispose();
      expect(fromParent.disposed, isTrue);
    });

    test('get após dispose lança StateError', () {
      final scope = SynapxModuleScope()..registerInstance<int>(1);
      scope.dispose();

      expect(() => scope.get<int>(), throwsStateError);
    });
  });
}
