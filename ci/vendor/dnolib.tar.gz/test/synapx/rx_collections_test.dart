// Contrato de `SynapxList` e `SynapxMap` (slice 0.1a): mutadores notificam uma única
// vez por chamada; operações no-op não notificam; `batch` condensa N mutações
// em uma notificação (com aninhamento e exceção seguros).
// Fase Red: estes testes falham contra os stubs sem notificação.

import 'package:dnolib/synapx/synapx.dart';
import 'package:test/test.dart';

void main() {
  group('SynapxList', () {
    test('expõe a lista inicial e notifica um adicionador', () {
      final notified = <List<int>>[];
      final list = SynapxList<int>([1, 2])..on((v) => notified.add(List.of(v)));

      expect(list.toList(), [1, 2]);

      list.add(3);

      expect(list.toList(), [1, 2, 3]);
      expect(notified.length, 1);
      expect(notified.single, [1, 2, 3]);
    });

    test('cada mutador emite exatamente uma notificação', () {
      final list = SynapxList<int>([1, 2, 3]);
      var calls = 0;
      list.on((_) => calls++);

      list.add(4);
      expect(calls, 1);

      list.addAll([5, 6]);
      expect(calls, 2);

      list.insert(0, 0);
      expect(calls, 3);

      list[0] = 9;
      expect(calls, 4);

      list.remove(9);
      expect(calls, 5);

      list.removeAt(0);
      expect(calls, 6);

      list.removeLast();
      expect(calls, 7);

      list.sort();
      expect(calls, 8);

      list.clear();
      expect(calls, 9);
    });

    test('no-ops não notificam', () {
      final list = SynapxList<int>([1, 2]);
      var calls = 0;
      list.on((_) => calls++);

      list[0] = 1; // mesmo valor
      expect(calls, 0);

      list.remove(99); // ausente
      expect(calls, 0);

      list.removeWhere((e) => e > 100); // sem match
      expect(calls, 0);

      SynapxList<int>().clear(); // limpar vazio (sem assinante relevante)
      expect(calls, 0);

      list.length = 2; // mesmo tamanho
      expect(calls, 0);
    });

    test('removeWhere com match remove e notifica uma vez', () {
      final list = SynapxList<int>([1, 2, 3, 4]);
      var calls = 0;
      list.on((_) => calls++);

      list.removeWhere((e) => e.isEven);

      expect(list.toList(), [1, 3]);
      expect(calls, 1);
    });

    test('length= altera e notifica; shrinking descarta o fim', () {
      final list = SynapxList<int>([1, 2, 3]);
      var calls = 0;
      list.on((_) => calls++);

      list.length = 2;

      expect(list.toList(), [1, 2]);
      expect(calls, 1);
    });

    test('batch condensa N mutações em uma notificação', () {
      final list = SynapxList<int>();
      var calls = 0;
      final seen = <List<int>>[];
      list.on((_) {
        calls++;
        seen.add(list.toList());
      });

      list.batch((l) {
        l.add(1);
        l.add(2);
        l[0] = 9;
      });

      expect(list.toList(), [9, 2]);
      expect(calls, 1);
      expect(seen, [
        [9, 2],
      ]);
    });

    test('batch aninhado emite uma única notificação no nível externo', () {
      final list = SynapxList<int>();
      var calls = 0;
      list.on((_) => calls++);

      list.batch((outer) {
        outer.add(1);
        outer.batch((inner) {
          inner.add(2);
        });
        outer.add(3);
      });

      expect(list.toList(), [1, 2, 3]);
      expect(calls, 1);
    });

    test('exceção no batch descarrega o parcial e não trava o contador', () {
      final list = SynapxList<int>();
      var calls = 0;
      final seen = <List<int>>[];
      list.on((_) {
        calls++;
        seen.add(list.toList());
      });

      expect(
        () => list.batch((l) {
          l.add(1);
          throw StateError('falha no lote');
        }),
        throwsStateError,
      );

      list.add(2);

      expect(list.toList(), [1, 2]);
      expect(calls, 2);
      expect(seen, [
        [1],
        [1, 2],
      ]);
    });

    test('value= substitui o conteúdo e notifica', () {
      final list = SynapxList<int>([1]);
      var calls = 0;
      list.on((_) => calls++);

      list.value = [7, 8];

      expect(list.toList(), [7, 8]);
      expect(calls, 1);
    });

    test('setRange, replaceRange, sort e shuffle respeitam no-op', () {
      final single = SynapxList<int>([1]);
      var singleCalls = 0;
      single.on((_) => singleCalls++);

      single.sort();
      single.shuffle();
      single.setRange(0, 0, const <int>[]);
      single.replaceRange(0, 0, const <int>[]);

      expect(singleCalls, 0);

      final empty = SynapxList<int>();
      var emptyCalls = 0;
      empty.on((_) => emptyCalls++);
      empty.sort();
      empty.shuffle();
      expect(emptyCalls, 0);
    });
  });

  group('SynapxMap', () {
    test('[]= com chave nova notifica; mesmo valor não notifica', () {
      final map = SynapxMap<String, int>({'a': 1});
      var calls = 0;
      map.on((_) => calls++);

      map['b'] = 2;
      expect(calls, 1);

      map['b'] = 2;
      expect(calls, 1);

      map['b'] = 3;
      expect(calls, 2);
      expect(map['b'], 3);
    });

    test('remove existente notifica e devolve o valor; ausente é no-op', () {
      final map = SynapxMap<String, int>({'a': 1});
      var calls = 0;
      map.on((_) => calls++);

      expect(map.remove('a'), 1);
      expect(calls, 1);
      expect(map.remove('a'), isNull);
      expect(calls, 1);
    });

    test('addAll e update notificam uma vez por chamada', () {
      final map = SynapxMap<String, int>({'a': 1});
      var calls = 0;
      map.on((_) => calls++);

      map.addAll({'b': 2, 'c': 3});
      expect(calls, 1);

      map.update('a', (v) => v + 10);
      expect(map['a'], 11);
      expect(calls, 2);

      map.putIfAbsent('d', () => 4);
      expect(calls, 3);

      map.putIfAbsent('d', () => 99);
      expect(calls, 3);
      expect(map['d'], 4);
    });

    test('removeWhere e clear vazia respeitam no-op', () {
      final map = SynapxMap<String, int>({'a': 1, 'b': 2});
      var calls = 0;
      map.on((_) => calls++);

      map.removeWhere((k, _) => k == 'z');
      expect(calls, 0);

      map.removeWhere((k, _) => k == 'a');
      expect(calls, 1);
      expect(map.keys, ['b']);

      SynapxMap<String, int>().clear();
      expect(calls, 1);
    });

    test('batch condensa mutações do mapa em uma notificação', () {
      final map = SynapxMap<String, int>();
      var calls = 0;
      map.on((_) => calls++);

      map.batch((m) {
        m['a'] = 1;
        m['b'] = 2;
        m.remove('a');
      });

      expect(map.keys, ['b']);
      expect(calls, 1);
    });

    test('update com mesmo valor em chave existente é no-op', () {
      final map = SynapxMap<String, int>({'a': 1});
      var calls = 0;
      map.on((_) => calls++);

      map.update('a', (v) => v);
      expect(calls, 0);

      map.update('a', (v) => v + 1);
      expect(calls, 1);
      expect(map['a'], 2);
    });
  });

  group('Atalhos .rx', () {
    test('lista.rx envolve cópia mutável e independente', () {
      final source = [1, 2];
      final rx = source.rx;
      var calls = 0;
      rx.on((_) => calls++);

      rx.add(3);

      expect(source, [1, 2]);
      expect(rx.toList(), [1, 2, 3]);
      expect(calls, 1);
    });

    test('mapa.rx envolve cópia mutável e independente', () {
      final source = {'a': 1};
      final rx = source.rx;
      var calls = 0;
      rx.on((_) => calls++);

      rx['b'] = 2;

      expect(source, {'a': 1});
      expect(rx['b'], 2);
      expect(calls, 1);
    });
  });
}
