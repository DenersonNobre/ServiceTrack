import 'dart:async';

import 'package:dnolib/dnolib.dart';
import 'package:flutter_test/flutter_test.dart';

class _E1Controller extends SynapxController {
  _E1Controller({
    Duration debounceDuration = const Duration(milliseconds: 20),
  }) {
    debounce<String>(
      query,
      debouncedQueries.add,
      duration: debounceDuration,
    );
    onEver<int>(count, everCounts.add);
    onOnce<int>(count, onceCounts.add);
  }

  late final Observable<int> count = obs(0);
  late final Observable<String> query = obs('');
  late final SynapxList<String> items = list(['a']);
  late final SynapxMap<String, int> scores = map({'x': 1});
  late final SynapxComputed<int> doubled = derived(() => count.value * 2);

  final List<String> debouncedQueries = [];
  final List<int> everCounts = [];
  final List<int> onceCounts = [];
}

void main() {
  group('Slice E1 — SynapxList.assign e SynapxMap.assign', () {
    test(
      'SynapxList.assign substitui conteúdo com exatamente 1 notificação',
      () {
        final rx = SynapxList<int>([1, 2]);
        addTearDown(rx.dispose);

        var notifications = 0;
        final token = rx.on((_) => notifications++);
        addTearDown(token.cancel);

        rx.assign([10, 20, 30]);
        expect(rx, [10, 20, 30]);
        expect(notifications, 1);

        // Auto-atribuição não perde elementos.
        rx.assign(rx);
        expect(rx, [10, 20, 30]);
        expect(notifications, 2);

        // Vazio -> vazio é no-op silencioso.
        rx.clear();
        notifications = 0;
        rx.assign(const <int>[]);
        expect(rx, isEmpty);
        expect(notifications, 0);
      },
    );

    test(
      'SynapxMap.assign substitui conteúdo com exatamente 1 notificação',
      () {
        final rx = SynapxMap<String, int>({'a': 1});
        addTearDown(rx.dispose);

        var notifications = 0;
        final token = rx.on((_) => notifications++);
        addTearDown(token.cancel);

        rx.assign({'b': 2, 'c': 3});
        expect(rx, {'b': 2, 'c': 3});
        expect(notifications, 1);

        // Auto-atribuição não perde entradas.
        rx.assign(rx);
        expect(rx, {'b': 2, 'c': 3});
        expect(notifications, 2);

        // Vazio -> vazio é no-op silencioso.
        rx.clear();
        notifications = 0;
        rx.assign(const <String, int>{});
        expect(rx, isEmpty);
        expect(notifications, 0);
      },
    );
  });

  group('Slice E1 — Helpers e guarda de execução no SynapxController', () {
    test(
      'obs, list, map, derived e workers são rastreados e descartados no dispose',
      () async {
        final controller = _E1Controller(
          debounceDuration: const Duration(milliseconds: 10),
        );

        expect(controller.isActive, isTrue);
        expect(controller.doubled.value, 0);

        controller.count.value = 3;
        expect(controller.doubled.value, 6);
        expect(controller.everCounts, [3]);
        expect(controller.onceCounts, [3]);

        controller.count.value = 4;
        expect(controller.everCounts, [3, 4]);
        expect(controller.onceCounts, [3]);

        controller.query.value = 'ana';
        await Future<void>.delayed(const Duration(milliseconds: 25));
        expect(controller.debouncedQueries, ['ana']);

        controller.dispose();
        expect(controller.isActive, isFalse);

        // Após dispose, workers e observables não disparam mais.
        controller.query.value = 'depois';
        await Future<void>.delayed(const Duration(milliseconds: 25));
        expect(controller.debouncedQueries, ['ana']);
      },
    );

    test(
      'runIfActive ignora retorno após dispose e antes de iniciar',
      () async {
        final controller = _E1Controller();
        final completer = Completer<String>();

        final inFlight = controller.runIfActive(() => completer.future);
        controller.dispose();
        completer.complete('ok');

        expect(await inFlight, isNull);
        expect(await controller.runIfActive(() async => 'nao-roda'), isNull);
      },
    );
  });
}
