import 'package:dnolib/dnolib.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_test/flutter_test.dart';

class _CounterController extends SynapxController {
  late final Observable<int> count = obs(0);
}

class _ReactiveCounterPage extends SynapxReactivePage<_CounterController> {
  const _ReactiveCounterPage();

  @override
  Widget buildReactive(BuildContext context) {
    return Text('count:${controller.count.value}');
  }
}

void main() {
  group('Slice E2 — SynapxObserver', () {
    testWidgets(
      'renderiza valor inicial, reage a mutações e cancela assinatura no dispose',
      (tester) async {
        final rx = Observable<int>(10);
        addTearDown(rx.dispose);

        await tester.pumpWidget(
          Directionality(
            textDirection: TextDirection.ltr,
            child: SynapxObserver<int>(
              observable: rx,
              builder: (_, value) => Text('v:$value'),
            ),
          ),
        );

        expect(find.text('v:10'), findsOneWidget);

        rx.value = 25;
        await tester.pump();
        expect(find.text('v:25'), findsOneWidget);

        // Troca de observable em didUpdateWidget cancela o antigo e assina o novo.
        final rx2 = Observable<int>(100);
        addTearDown(rx2.dispose);

        await tester.pumpWidget(
          Directionality(
            textDirection: TextDirection.ltr,
            child: SynapxObserver<int>(
              observable: rx2,
              builder: (_, value) => Text('v:$value'),
            ),
          ),
        );
        expect(find.text('v:100'), findsOneWidget);

        rx.value = 999;
        await tester.pump();
        expect(find.text('v:100'), findsOneWidget);

        rx2.value = 101;
        await tester.pump();
        expect(find.text('v:101'), findsOneWidget);

        // Desmontar não vaza nem lança ao mutar depois.
        await tester.pumpWidget(const SizedBox.shrink());
        rx2.value = 202;
        await tester.pump();
      },
    );
  });

  group('Slice E2 — SynapxReactivePage', () {
    testWidgets(
      'resolve controller via SynapxProvider e reconstrói ao mudar observable',
      (tester) async {
        final scope = SynapxModuleScope()
          ..registerLazySingleton<_CounterController>(
            (_) => _CounterController(),
          );
        addTearDown(scope.dispose);

        await tester.pumpWidget(
          Directionality(
            textDirection: TextDirection.ltr,
            child: SynapxProvider.value(
              value: scope,
              child: const _ReactiveCounterPage(),
            ),
          ),
        );

        expect(find.text('count:0'), findsOneWidget);

        scope.get<_CounterController>().count.value = 7;
        await tester.pump();
        expect(find.text('count:7'), findsOneWidget);
      },
    );
  });
}
