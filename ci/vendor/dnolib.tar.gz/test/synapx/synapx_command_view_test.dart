import 'dart:async';

import 'package:dnolib/dnolib.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('SynapxCommandView', () {
    testWidgets(
      'renderiza onIdle antes da execucao e fallback para onLoading quando omitido',
      (tester) async {
        final command = Command<String, String, void>(
          (_) async => const Success('ok'),
          mapException: (e, _) => '$e',
        );
        addTearDown(command.dispose);

        await tester.pumpWidget(
          Directionality(
            textDirection: TextDirection.ltr,
            child: SynapxCommandView<String, String, void>(
              command: command,
              onIdle: (_) => const Text('idle'),
              onLoading: (_) => const Text('loading'),
              onSuccess: (_, data) => Text('data:$data'),
            ),
          ),
        );

        expect(find.text('idle'), findsOneWidget);

        await tester.pumpWidget(
          Directionality(
            textDirection: TextDirection.ltr,
            child: SynapxCommandView<String, String, void>(
              command: command,
              onLoading: (_) => const Text('loading'),
              onSuccess: (_, data) => Text('data:$data'),
            ),
          ),
        );

        expect(find.text('loading'), findsOneWidget);
      },
    );

    testWidgets(
      'transiciona de onLoading para onSuccess quando Command conclui',
      (tester) async {
        final completer = Completer<IResult<String, String>>();
        final command = Command<String, String, void>(
          (_) => completer.future,
          mapException: (e, _) => '$e',
        );
        addTearDown(command.dispose);

        await tester.pumpWidget(
          Directionality(
            textDirection: TextDirection.ltr,
            child: SynapxCommandView<String, String, void>(
              command: command,
              onIdle: (_) => const Text('idle'),
              onLoading: (_) => const Text('loading'),
              onSuccess: (_, data) => Text('data:$data'),
            ),
          ),
        );

        unawaited(command.run());
        await tester.pump();
        expect(find.text('loading'), findsOneWidget);

        completer.complete(const Success('pronto'));
        await tester.pumpAndSettle();
        expect(find.text('data:pronto'), findsOneWidget);
      },
    );

    testWidgets(
      'renderiza onEmpty para colecao vazia ou predicado isEmpty customizado',
      (tester) async {
        var nextItems = <String>[];
        final command = Command<List<String>, String, void>(
          (_) async => Success(nextItems),
          mapException: (e, _) => '$e',
        );
        addTearDown(command.dispose);

        await tester.pumpWidget(
          Directionality(
            textDirection: TextDirection.ltr,
            child: SynapxCommandView<List<String>, String, void>(
              command: command,
              onEmpty: (_) => const Text('vazio'),
              onSuccess: (_, items) => Text('qtd:${items.length}'),
            ),
          ),
        );

        await command.run();
        await tester.pump();
        expect(find.text('vazio'), findsOneWidget);

        nextItems = ['a', 'b'];
        await command.run();
        await tester.pump();
        expect(find.text('qtd:2'), findsOneWidget);

        // Predicado customizado sobrescreve deteccao padrao
        await tester.pumpWidget(
          Directionality(
            textDirection: TextDirection.ltr,
            child: SynapxCommandView<List<String>, String, void>(
              command: command,
              isEmpty: (items) => items.length < 3,
              onEmpty: (_) => const Text('insuficiente'),
              onSuccess: (_, items) => Text('qtd:${items.length}'),
            ),
          ),
        );

        expect(find.text('insuficiente'), findsOneWidget);
      },
    );

    testWidgets(
      'renderiza onSuccess quando lista esta vazia mas onEmpty foi omitido',
      (tester) async {
        final command = Command<List<String>, String, void>(
          (_) async => const Success(<String>[]),
          mapException: (e, _) => '$e',
        );
        addTearDown(command.dispose);

        await tester.pumpWidget(
          Directionality(
            textDirection: TextDirection.ltr,
            child: SynapxCommandView<List<String>, String, void>(
              command: command,
              onSuccess: (_, items) => Text('qtd:${items.length}'),
            ),
          ),
        );

        await command.run();
        await tester.pump();
        expect(find.text('qtd:0'), findsOneWidget);
      },
    );

    testWidgets(
      'renderiza onError tipado e retry reexecuta o Command com retryParam',
      (tester) async {
        var attempts = 0;
        final receivedParams = <int?>[];
        final command = Command<String, String, int>((param) async {
          attempts++;
          receivedParams.add(param);
          if (attempts == 1) {
            return const Failure('falha-rede');
          }
          return Success('ok-$param');
        }, mapException: (e, _) => '$e');
        addTearDown(command.dispose);

        await tester.pumpWidget(
          Directionality(
            textDirection: TextDirection.ltr,
            child: SynapxCommandView<String, String, int>(
              command: command,
              retryParam: 42,
              onSuccess: (_, data) => Text('data:$data'),
              onError: (_, failure, retry) =>
                  GestureDetector(onTap: retry, child: Text('erro:$failure')),
            ),
          ),
        );

        await command.run(42);
        await tester.pump();
        expect(find.text('erro:falha-rede'), findsOneWidget);

        await tester.tap(find.text('erro:falha-rede'));
        await tester.pump();

        expect(find.text('data:ok-42'), findsOneWidget);
        expect(receivedParams, [42, 42]);
      },
    );
  });
}
