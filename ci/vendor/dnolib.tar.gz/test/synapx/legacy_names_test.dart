// Gate de ausência de legado do Synapx (slice E0): os nomes antigos não podem
// sobreviver em código (`lib/`, `test/`, `example/lib`, `example/test`). Inclui
// prova negativa para garantir que o gate realmente reprova um nome legado.
//
// Exceções deliberadas: este próprio arquivo (contém a lista) e registros
// históricos em LEARNINGS/CHANGELOG (fora do escopo do scan, que é só `.dart`).
//
// Dependências: SDK (`dart:io`) e `package:test`.

import 'dart:io';

import 'package:test/test.dart';

const _legacyNames = <String>[
  'ModuleScope',
  'ScopeBinder',
  'ScopeWidget',
  'ScopeRouteObserver',
  'ScopeRouteBuilder',
  'Disposable',
  'CompositeDisposable',
  'RxList',
  'RxMap',
  'RxTracker',
  'RxCallback',
  'Computed',
  'SynapxContextX',
  'SynapxDialogsX',
  'RouteContext',
  'RouteGuard',
  'RouteGuardRunner',
  'GuardResult',
  'GuardAllow',
  'GuardReject',
  'GuardRedirect',
  'debounceRx',
  'intervalRx',
];

final RegExp _legacy = RegExp(
  '(?<![\\w.])(${_legacyNames.map(RegExp.escape).join('|')})(?!\\w)',
);

// Nomes que também são funções top-level: só acusam uso como chamada.
final RegExp _legacyCalls = RegExp(r'(?<![\w.])(ever|once)\s*[<(]');

/// Ocorrências de legado em um texto (para prova negativa e scan real).
List<String> legacyViolations(String text) {
  final found = <String>[];
  for (final match in _legacy.allMatches(text)) {
    found.add(match.group(1)!);
  }
  for (final line in text.split('\n')) {
    final staticAt = line.indexOf('static ');
    for (final match in _legacyCalls.allMatches(line)) {
      // `static ... ever<T>(`/`once<T>(` são métodos canônicos de SynapxEffect,
      // não as funções top-level antigas.
      if (staticAt != -1 && match.start > staticAt) {
        continue;
      }
      found.add('${match.group(1)}(');
    }
  }
  return found;
}

void main() {
  test('gate reprova nomes legados (prova negativa)', () {
    expect(legacyViolations('final scope = ModuleScope();'), ['ModuleScope']);
    expect(legacyViolations('final list = RxList<int>();'), ['RxList']);
    expect(legacyViolations('ever<int>(rx, (_) {});'), ['ever(']);
    expect(legacyViolations('once<int>(rx, (_) {});'), ['once(']);
    expect(legacyViolations('final list = SynapxList<int>();'), isEmpty);
    expect(legacyViolations('SynapxEffect.ever<int>(rx, (_) {});'), isEmpty);
  });

  test('nenhum nome legado remanescente em código', () {
    final dirs = [
      Directory('lib'),
      Directory('test'),
      Directory('example/lib'),
      Directory('example/test'),
    ];

    final offenders = <String>[];
    for (final dir in dirs) {
      if (!dir.existsSync()) {
        continue;
      }
      final files =
          dir
              .listSync(recursive: true)
              .whereType<File>()
              .where((file) => file.path.endsWith('.dart'))
              .where((file) => !file.path.endsWith('legacy_names_test.dart'))
              .toList()
            ..sort((a, b) => a.path.compareTo(b.path));
      for (final file in files) {
        final found = legacyViolations(file.readAsStringSync());
        if (found.isNotEmpty) {
          offenders.add('${file.path}: ${found.toSet().join(', ')}');
        }
      }
    }

    expect(offenders, isEmpty, reason: 'Nomes legados encontrados: $offenders');
  });
}
