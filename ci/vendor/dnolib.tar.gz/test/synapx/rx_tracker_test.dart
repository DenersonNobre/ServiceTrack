// Contrato do SynapxTracker por instância via Zone (slice 0.1b).

import 'dart:async';

import 'package:dnolib/core/core.dart';
import 'package:dnolib/synapx/synapx.dart';
import 'package:test/test.dart';

void main() {
  group('SynapxTracker', () {
    test(
      'fora de track, SynapxTracker.current é null e leituras são ignoradas',
      () {
        final rx = Observable<int>(1);
        expect(SynapxTracker.current, isNull);
        expect(rx.value, 1);
      },
    );

    test(
      'registra apenas os Observables lidos durante computação síncrona',
      () {
        final a = Observable<int>(10);
        final b = Observable<String>('x');
        final unread = Observable<bool>(false);
        final read = <Observable<dynamic>>{};
        final tracker = SynapxTracker();

        final result = tracker.track(() => '${a.value}:${b.value}', read.add);

        expect(result, '10:x');
        expect(read, {a, b});
        expect(read.contains(unread), isFalse);
        expect(SynapxTracker.current, isNull);
      },
    );

    test('escopos aninhados e sobrepostos mantêm isolamento estrito', () {
      final outerRx = Observable<int>(1);
      final innerRx = Observable<int>(2);
      final outerReads = <Observable<dynamic>>{};
      final innerReads = <Observable<dynamic>>{};

      final outer = SynapxTracker();
      final inner = SynapxTracker();

      outer.track(() {
        outerRx.value;
        inner.track(() {
          innerRx.value;
        }, innerReads.add);
      }, outerReads.add);

      expect(outerReads, {outerRx});
      expect(innerReads, {innerRx});
    });

    test(
      'invariante síncrona: callback assíncrono tardio não registra leitura',
      () async {
        final rx = Observable<int>(42);
        final lateRx = Observable<int>(99);
        final read = <Observable<dynamic>>{};
        final tracker = SynapxTracker();
        late Future<void> scheduled;

        tracker.track(() {
          rx.value;
          scheduled = Future<void>.microtask(() {
            lateRx.value;
          });
        }, read.add);

        await scheduled;

        expect(read, {rx});
        expect(read.contains(lateRx), isFalse);
      },
    );

    test(
      'leituras em SynapxList e SynapxMap registram a coleção observável',
      () {
        final list = SynapxList<int>([1, 2]);
        final map = SynapxMap<String, int>({'k': 3});
        final read = <Observable<dynamic>>{};
        final tracker = SynapxTracker();

        final sum = tracker.track(() => list[0] + (map['k'] ?? 0), read.add);

        expect(sum, 4);
        expect(read, {list, map});
      },
    );
  });
}
