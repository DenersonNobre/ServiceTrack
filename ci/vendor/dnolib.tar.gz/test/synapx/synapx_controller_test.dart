// Contrato do SynapxController (slice ergonômico, Dart puro).

import 'dart:async';

import 'package:dnolib/dnolib.dart';
import 'package:fake_async/fake_async.dart';
import 'package:test/test.dart';

class _ChildDisposable implements SynapxDisposable {
  var disposed = false;

  @override
  void dispose() => disposed = true;
}

class _SampleController extends SynapxController {
  _SampleController(this.log) {
    onDispose(() => log.add('callback'));
    autoDispose(child);
    count = trackObservable(Observable<int>(0));
    token = trackToken(count.on((_) => log.add('obs')));
    command = trackCommand(
      Command<int, String, void>(
        (_) async => Success(1),
        mapException: (_, __) => 'err',
      ),
    );
  }

  final List<String> log;
  final _ChildDisposable child = _ChildDisposable();
  late final Observable<int> count;
  late final ObservableToken<int> token;
  late final Command<int, String, void> command;
  var onCloseCalls = 0;

  void scheduleTimer(void Function() fn) {
    trackTimer(Timer(const Duration(milliseconds: 50), fn));
  }

  @override
  void onClose() {
    onCloseCalls++;
    log.add('onClose');
  }
}

void main() {
  group('SynapxController', () {
    test('descarta todos os recursos rastreados e chama onClose uma vez', () {
      fakeAsync((async) {
        final log = <String>[];
        var timerFired = false;
        final controller = _SampleController(log);
        controller.scheduleTimer(() => timerFired = true);

        expect(controller.isDisposed, isFalse);

        controller.dispose();
        controller.dispose();

        expect(controller.isDisposed, isTrue);
        expect(controller.onCloseCalls, 1);
        expect(controller.child.disposed, isTrue);
        expect(controller.token.isActive, isFalse);

        // Alterar observable ou avançar timer após dispose não dispara nada.
        controller.count.value = 10;
        async.elapse(const Duration(milliseconds: 100));
        expect(timerFired, isFalse);
        expect(log, ['onClose', 'callback']);
      });
    });

    test('integra com SynapxModuleScope para auto-dispose', () {
      final log = <String>[];
      final scope = SynapxModuleScope()
        ..registerLazySingleton<_SampleController>(
          (_) => _SampleController(log),
        );

      final controller = scope.get<_SampleController>();
      expect(controller.isDisposed, isFalse);

      scope.dispose();
      expect(controller.isDisposed, isTrue);
      expect(controller.onCloseCalls, 1);
    });
  });
}
