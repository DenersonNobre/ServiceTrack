// Contrato de SynapxModule e SynapxTestScope (módulos declarativos e overrides).

import 'package:dnolib/dnolib.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

class _Repo {
  _Repo(this.source);
  final String source;
}

class _Service implements SynapxDisposable {
  _Service(this.repo);
  final _Repo repo;
  var disposed = false;

  @override
  void dispose() => disposed = true;
}

class _CoreModule extends SynapxModule {
  const _CoreModule();

  @override
  void binds(SynapxModuleScope scope) {
    scope.registerInstance<_Repo>(_Repo('prod'));
  }
}

class _FeatureModule extends SynapxModule {
  const _FeatureModule();

  @override
  List<SynapxModule> get imports => const [_CoreModule(), _CoreModule()];

  @override
  void binds(SynapxModuleScope scope) {
    scope.registerLazySingleton<_Service>((s) => _Service(s.get<_Repo>()));
  }
}

class _SharedModule extends SynapxModule {
  const _SharedModule();

  static var bindsCalls = 0;

  @override
  void binds(SynapxModuleScope scope) {
    bindsCalls++;
    scope.registerInstance<_Repo>(_Repo('shared'));
  }
}

class _LeftModule extends SynapxModule {
  const _LeftModule();

  @override
  List<SynapxModule> get imports => const [_SharedModule()];

  @override
  void binds(SynapxModuleScope scope) {}
}

class _RightModule extends SynapxModule {
  const _RightModule();

  @override
  List<SynapxModule> get imports => const [_SharedModule()];

  @override
  void binds(SynapxModuleScope scope) {}
}

class _TopModule extends SynapxModule {
  const _TopModule();

  @override
  List<SynapxModule> get imports => const [_LeftModule(), _RightModule()];

  @override
  void binds(SynapxModuleScope scope) {}
}

void main() {
  group('SynapxModule e SynapxTestScope', () {
    test('applyModule resolve imports e evita duplicidade no mesmo escopo', () {
      final scope = SynapxModuleScope()..applyModule(const _FeatureModule());

      final service = scope.get<_Service>();
      expect(service.repo.source, 'prod');

      scope.dispose();
      expect(service.disposed, isTrue);
    });

    test('SynapxTestScope aplica module e overrides declarativos', () {
      final testScope = SynapxTestScope(
        module: const _FeatureModule(),
        overrides: (s) => s.registerInstance<_Repo>(_Repo('fake')),
      );

      final service = testScope.get<_Service>();
      expect(service.repo.source, 'fake');

      testScope.dispose();
      expect(service.disposed, isTrue);
    });

    test('diamante: import transitivo compartilhado aplica uma vez', () {
      _SharedModule.bindsCalls = 0;
      final scope = SynapxModuleScope()..applyModule(const _TopModule());

      expect(scope.get<_Repo>().source, 'shared');
      expect(_SharedModule.bindsCalls, 1);

      scope.dispose();
    });

    testWidgets('SynapxApp e SynapxRouteScope aceitam module diretamente', (
      tester,
    ) async {
      await tester.pumpWidget(
        SynapxApp(
          module: const _CoreModule(),
          builder: (_, __, observer) => MaterialApp(
            navigatorObservers: [observer],
            home: SynapxRouteScope(
              module: const _FeatureModule(),
              builder: (ctx) => Text(ctx.get<_Service>().repo.source),
            ),
          ),
        ),
      );

      expect(find.text('prod'), findsOneWidget);
    });
  });
}
