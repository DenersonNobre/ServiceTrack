// Contrato de SynapxDisposable e SynapxCompositeDisposable (slice 0.1c).

import 'dart:async';

import 'package:dnolib/core/core.dart';
import 'package:dnolib/synapx/synapx.dart';
import 'package:fake_async/fake_async.dart';
import 'package:test/test.dart';

class _SpyDisposable implements SynapxDisposable {
  _SpyDisposable(this.id, this.log, {this.shouldThrow = false});

  final String id;
  final List<String> log;
  final bool shouldThrow;
  var disposeCount = 0;

  @override
  void dispose() {
    disposeCount++;
    log.add(id);
    if (shouldThrow) {
      throw StateError('erro em $id');
    }
  }
}

void main() {
  group('SynapxCompositeDisposable', () {
    test('descarta em ordem reversa e é idempotente', () {
      final log = <String>[];
      final composite = SynapxCompositeDisposable();
      final a = _SpyDisposable('a', log);
      final b = _SpyDisposable('b', log);

      composite.add(a);
      composite.add(b);
      composite.addCallback(() => log.add('cb'));

      composite.dispose();
      composite.dispose();

      expect(log, ['cb', 'b', 'a']);
      expect(a.disposeCount, 1);
      expect(b.disposeCount, 1);
      expect(composite.isDisposed, isTrue);
    });

    test('cancela ObservableToken e Timer no dispose', () {
      fakeAsync((async) {
        final composite = SynapxCompositeDisposable();
        final rx = Observable<int>(0);
        var obsCalls = 0;
        var timerCalls = 0;

        composite.addToken(rx.on((_) => obsCalls++));
        composite.addTimer(
          Timer(const Duration(milliseconds: 50), () => timerCalls++),
        );

        composite.dispose();

        rx.value = 1;
        async.elapse(const Duration(milliseconds: 100));

        expect(obsCalls, 0);
        expect(timerCalls, 0);
      });
    });

    test('adicionar recurso após dispose descarta imediatamente', () {
      final log = <String>[];
      final composite = SynapxCompositeDisposable()..dispose();
      final lateDisposable = _SpyDisposable('late', log);
      final rx = Observable<int>(0);
      final token = rx.on((_) {});

      composite.add(lateDisposable);
      composite.addToken(token);
      composite.addCallback(() => log.add('lateCb'));

      expect(lateDisposable.disposeCount, 1);
      expect(token.isActive, isFalse);
      expect(log, ['late', 'lateCb']);
    });

    test('erro em um disposable não impede o descarte dos demais', () {
      final log = <String>[];
      final errors = <Object>[];
      final composite = SynapxCompositeDisposable();
      composite.add(_SpyDisposable('first', log));
      composite.add(_SpyDisposable('boom', log, shouldThrow: true));
      composite.add(_SpyDisposable('last', log));

      runZonedGuarded(composite.dispose, (error, _) => errors.add(error));

      expect(log, ['last', 'boom', 'first']);
      expect(errors, hasLength(1));
    });
  });
}
