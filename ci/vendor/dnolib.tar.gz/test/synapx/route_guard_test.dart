// Matriz de testes do SynapxRouteGuardRunner (slice 0.2):
// 1. Autorizado (SynapxGuardAllow)
// 2. Negado (SynapxGuardReject)
// 3. Redirecionamento (SynapxGuardRedirect)
// 4. Concorrência / duplo tap / cancelamento
// 5. Exceção lançada pelo guard
// 6. Timeout do guard
// 7. Loop de redirect (A -> B -> A)

import 'dart:async';

import 'package:dnolib/synapx/synapx.dart';
import 'package:fake_async/fake_async.dart';
import 'package:test/test.dart';

class _FnGuard implements SynapxRouteGuard {
  _FnGuard(this._fn);

  final Future<SynapxGuardResult> Function(SynapxRouteContext context) _fn;

  @override
  Future<SynapxGuardResult> canActivate(SynapxRouteContext context) =>
      _fn(context);
}

void main() {
  group('SynapxRouteGuardRunner', () {
    test(
      '1. autorizado quando todos os guards retornam SynapxGuardAllow',
      () async {
        final runner = SynapxRouteGuardRunner();
        final order = <int>[];

        final result = await runner.evaluate(
          SynapxRouteContext(uri: Uri.parse('/vendas')),
          [
            _FnGuard((_) async {
              order.add(1);
              return const SynapxGuardAllow();
            }),
            _FnGuard((_) async {
              order.add(2);
              return const SynapxGuardAllow();
            }),
          ],
        );

        expect(result, isA<SynapxGuardAllow>());
        expect(order, [1, 2]);
      },
    );

    test('2. negado interrompe cadeia no primeiro SynapxGuardReject', () async {
      final runner = SynapxRouteGuardRunner();
      var secondCalled = false;

      final result = await runner.evaluate(
        SynapxRouteContext(uri: Uri.parse('/admin')),
        [
          _FnGuard((_) async => const SynapxGuardReject('sem_permissao')),
          _FnGuard((_) async {
            secondCalled = true;
            return const SynapxGuardAllow();
          }),
        ],
      );

      expect(result, isA<SynapxGuardReject>());
      expect((result as SynapxGuardReject).reason, 'sem_permissao');
      expect(secondCalled, isFalse);
    });

    test(
      '3. redirecionamento devolve SynapxGuardRedirect com URI destino',
      () async {
        final runner = SynapxRouteGuardRunner();

        final result = await runner.evaluate(
          SynapxRouteContext(uri: Uri.parse('/checkout')),
          [_FnGuard((_) async => SynapxGuardRedirect(Uri.parse('/login')))],
        );

        expect(result, isA<SynapxGuardRedirect>());
        expect((result as SynapxGuardRedirect).target, Uri.parse('/login'));
      },
    );

    test('4. concorrência / cancelamento descarta execução obsoleta', () async {
      final runner = SynapxRouteGuardRunner();
      final firstCompleter = Completer<SynapxGuardResult>();
      final secondCompleter = Completer<SynapxGuardResult>();

      final firstFuture = runner.evaluate(
        SynapxRouteContext(uri: Uri.parse('/a')),
        [
          _FnGuard((_) => firstCompleter.future),
        ],
      );
      final secondFuture = runner.evaluate(
        SynapxRouteContext(uri: Uri.parse('/b')),
        [
          _FnGuard((_) => secondCompleter.future),
        ],
      );

      firstCompleter.complete(const SynapxGuardAllow());
      secondCompleter.complete(const SynapxGuardAllow());

      final first = await firstFuture;
      final second = await secondFuture;

      expect(first, isA<SynapxGuardReject>());
      expect((first as SynapxGuardReject).reason, 'cancelled');
      expect(second, isA<SynapxGuardAllow>());

      // Cancelamento explícito (ex.: pop durante await).
      final thirdCompleter = Completer<SynapxGuardResult>();
      final thirdFuture = runner.evaluate(
        SynapxRouteContext(uri: Uri.parse('/c')),
        [
          _FnGuard((_) => thirdCompleter.future),
        ],
      );
      runner.cancel();
      thirdCompleter.complete(const SynapxGuardAllow());

      final third = await thirdFuture;
      expect(third, isA<SynapxGuardReject>());
      expect((third as SynapxGuardReject).reason, 'cancelled');
    });

    test(
      '5. exceção lançada pelo guard é convertida em SynapxGuardReject seguro',
      () async {
        final runner = SynapxRouteGuardRunner();

        final result = await runner.evaluate(
          SynapxRouteContext(uri: Uri.parse('/erro')),
          [_FnGuard((_) async => throw StateError('falha inesperada'))],
        );

        expect(result, isA<SynapxGuardReject>());
        expect(
          (result as SynapxGuardReject).reason,
          contains('falha inesperada'),
        );
      },
    );

    test('6. timeout interrompe guard lento dentro do SLA configurado', () {
      fakeAsync((async) {
        final runner = SynapxRouteGuardRunner(
          timeout: const Duration(milliseconds: 50),
        );
        SynapxGuardResult? outcome;

        runner
            .evaluate(SynapxRouteContext(uri: Uri.parse('/lento')), [
              _FnGuard((_) => Completer<SynapxGuardResult>().future),
            ])
            .then((value) => outcome = value);

        async.elapse(const Duration(milliseconds: 50));

        expect(outcome, isA<SynapxGuardReject>());
        expect((outcome! as SynapxGuardReject).reason, 'timeout');
      });
    });

    test(
      '7. loop de redirect A -> B -> A é detectado e interrompido',
      () async {
        final runner = SynapxRouteGuardRunner();

        final result = await runner.resolveRedirectChain(
          initialContext: SynapxRouteContext(uri: Uri.parse('/a')),
          guardsForUri: (uri) {
            if (uri.path == '/a') {
              return [
                _FnGuard((_) async => SynapxGuardRedirect(Uri.parse('/b'))),
              ];
            }
            if (uri.path == '/b') {
              return [
                _FnGuard((_) async => SynapxGuardRedirect(Uri.parse('/a'))),
              ];
            }
            return const [];
          },
        );

        expect(result, isA<SynapxGuardReject>());
        expect((result as SynapxGuardReject).reason, contains('redirect_loop'));
      },
    );
  });
}
