// Contrato do estado derivado SynapxComputed<T> / synapxComputed() (Dart puro).

import 'package:dnolib/dnolib.dart';
import 'package:test/test.dart';

void main() {
  group('SynapxComputed', () {
    test('calcula valor inicial e recalcula quando dependência muda', () {
      final price = Observable<int>(10);
      final qty = Observable<int>(2);
      final total = synapxComputed(() => price.value * qty.value);

      expect(total.value, 20);

      final seen = <int>[];
      total.on(seen.add);

      qty.value = 3;
      expect(total.value, 30);
      expect(seen, [30]);

      price.value = 5;
      expect(total.value, 15);
      expect(seen, [30, 15]);

      total.dispose();
    });

    test('não notifica assinantes se o valor derivado permanecer igual', () {
      final count = Observable<int>(2);
      final isEven = synapxComputed(() => count.value.isEven);
      var notifications = 0;
      isEven.on((_) => notifications++);

      count.value = 4; // continua par
      expect(isEven.value, isTrue);
      expect(notifications, 0);

      count.value = 5; // virou ímpar
      expect(isEven.value, isFalse);
      expect(notifications, 1);

      isEven.dispose();
    });

    test('reconcilia dependências condicionais e funciona com SynapxList', () {
      final useDiscount = Observable<bool>(false);
      final discount = Observable<int>(5);
      final items = SynapxList<int>([10, 20]);

      var recomputations = 0;
      final total = synapxComputed(() {
        recomputations++;
        final sum = items.fold<int>(0, (acc, v) => acc + v);
        return useDiscount.value ? sum - discount.value : sum;
      });

      expect(total.value, 30);
      expect(recomputations, 1);

      // discount não foi lido ainda; mudar não deve recomputar.
      discount.value = 8;
      expect(recomputations, 1);

      useDiscount.value = true;
      expect(total.value, 22);
      expect(recomputations, 2);

      items.add(10);
      expect(total.value, 32);
      expect(recomputations, 3);

      // Desliga desconto: discount volta a ser ignorado.
      useDiscount.value = false;
      expect(total.value, 40);
      expect(recomputations, 4);

      discount.value = 1;
      expect(recomputations, 4);

      total.dispose();
    });

    test('suporta cadeia de SynapxComputed aninhados', () {
      final base = Observable<int>(2);
      final doubled = synapxComputed(() => base.value * 2);
      final plusOne = synapxComputed(() => doubled.value + 1);

      expect(plusOne.value, 5);

      base.value = 10;
      expect(plusOne.value, 21);

      plusOne.dispose();
      doubled.dispose();
    });

    test('value= lança UnsupportedError e dispose interrompe recomputação', () {
      final source = Observable<int>(1);
      var runs = 0;
      final derived = synapxComputed(() {
        runs++;
        return source.value * 10;
      });

      expect(() => derived.value = 99, throwsUnsupportedError);
      expect(runs, 1);

      derived.dispose();
      source.value = 2;
      expect(runs, 1);
    });
  });
}
