// Teste de fuga e ciclo de vida do SynapxProvider e SynapxRouteObserver (slice 0.1c).

import 'dart:async';

import 'package:dnolib/dnolib.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

class _LeakController implements SynapxDisposable {
  _LeakController(this.observable) {
    _resources.addToken(observable.on((_) {}));
    _resources.addTimer(Timer(const Duration(seconds: 30), () {}));
  }

  final Observable<int> observable;
  final SynapxCompositeDisposable _resources = SynapxCompositeDisposable();
  var disposed = false;

  @override
  void dispose() {
    if (disposed) {
      return;
    }
    disposed = true;
    _resources.dispose();
  }
}

void main() {
  group('SynapxProvider e SynapxRouteObserver', () {
    testWidgets(
      'SynapxProvider descarta escopo criado ao desmontar e preserva em reassemble',
      (tester) async {
        late SynapxModuleScope created;
        var creates = 0;

        await tester.pumpWidget(
          SynapxProvider(
            create: (_) {
              creates++;
              created = SynapxModuleScope()
                ..registerLazySingleton<_LeakController>(
                  (_) => _LeakController(Observable<int>(0)),
                );
              return created;
            },
            child: Builder(
              builder: (context) {
                SynapxProvider.of(context).get<_LeakController>();
                return const SizedBox.shrink();
              },
            ),
          ),
        );

        final controller = created.get<_LeakController>();
        expect(creates, 1);
        expect(controller.disposed, isFalse);

        // Simula hot reload (reassemble): não recria nem descarta o escopo.
        unawaited(tester.binding.reassembleApplication());
        await tester.pump();
        expect(creates, 1);
        expect(controller.disposed, isFalse);

        // Desmontar a árvore descarta o escopo e seus recursos.
        await tester.pumpWidget(const SizedBox.shrink());
        expect(controller.disposed, isTrue);
      },
    );

    testWidgets(
      'SynapxProvider.value não descarta escopo externo (ownsScope: false)',
      (tester) async {
        final external = SynapxModuleScope()
          ..registerInstance<_LeakController>(
            _LeakController(Observable<int>(0)),
            owned: true,
          );
        final controller = external.get<_LeakController>();

        await tester.pumpWidget(
          SynapxProvider.value(value: external, child: const SizedBox.shrink()),
        );
        await tester.pumpWidget(const SizedBox.shrink());

        expect(controller.disposed, isFalse);
        external.dispose();
        expect(controller.disposed, isTrue);
      },
    );

    testWidgets(
      'N ciclos de push/pop/pushReplacement zeram controladores e timers pendentes',
      (tester) async {
        final observer = SynapxRouteObserver();
        final sharedRx = Observable<int>(0);
        final createdControllers = <_LeakController>[];
        final navKey = GlobalKey<NavigatorState>();

        await tester.pumpWidget(
          MaterialApp(
            navigatorKey: navKey,
            navigatorObservers: [observer],
            home: const SizedBox.shrink(),
          ),
        );

        for (var i = 0; i < 5; i++) {
          unawaited(
            navKey.currentState!.push(
              MaterialPageRoute<void>(
                builder: (_) => SynapxProvider(
                  create: (_) =>
                      SynapxModuleScope()
                        ..registerLazySingleton<_LeakController>((_) {
                          final c = _LeakController(sharedRx);
                          createdControllers.add(c);
                          return c;
                        }),
                  child: Builder(
                    builder: (context) {
                      SynapxProvider.of(context).get<_LeakController>();
                      return const SizedBox.shrink();
                    },
                  ),
                ),
              ),
            ),
          );
          await tester.pumpAndSettle();

          if (i.isEven) {
            unawaited(
              navKey.currentState!.pushReplacement(
                MaterialPageRoute<void>(
                  builder: (_) => const SizedBox.shrink(),
                ),
              ),
            );
            await tester.pumpAndSettle();
          }

          navKey.currentState!.pop();
          await tester.pumpAndSettle();
        }

        expect(createdControllers, hasLength(5));
        expect(createdControllers.every((c) => c.disposed), isTrue);
        expect(observer.activeRoutesCount, 1); // apenas a rota home
        sharedRx.dispose();
      },
    );
  });
}
