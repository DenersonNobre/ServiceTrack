import 'dart:io';

import 'package:test/test.dart';

/// Invariante de consumo da facade: o app de exemplo consome a biblioteca
/// exclusivamente através da facade `package:dnolib/dnolib.dart`.
///
/// Barrels internos (`package:dnolib/core/...`, `package:dnolib/widgets/...`) e
/// arquivos privados (`src/...`) não podem ser importados por consumidores.
void main() {
  test('example consome apenas a facade package:dnolib/dnolib.dart', () {
    final violacoes = <String>[];

    for (final arquivo in _fontesDart(Directory('example'))) {
      final conteudo = arquivo.readAsStringSync();
      for (final match in _diretivaDnolib.allMatches(conteudo)) {
        final uri = match.group(1)!;
        if (uri != 'package:dnolib/dnolib.dart') {
          violacoes.add('${arquivo.path.replaceAll(r'\', '/')}: $uri');
        }
      }
    }

    expect(
      violacoes,
      isEmpty,
      reason:
          'O exemplo deve consumir apenas a facade package:dnolib/dnolib.dart; '
          'violações: $violacoes',
    );
  });

  test('o gate detecta import direto de barrel ou arquivo src', () {
    const barrel = "import 'package:dnolib/core/core.dart';\n";
    const srcPrivado = "import 'package:dnolib/widgets/src/button.dart';\n";
    const facadeValida =
        "import 'package:dnolib/dnolib.dart' show Command, IResult;\n";

    expect(_temViolacaoFacade(barrel), isTrue);
    expect(_temViolacaoFacade(srcPrivado), isTrue);
    expect(_temViolacaoFacade(facadeValida), isFalse);
  });
}

bool _temViolacaoFacade(String fonte) {
  final matches = _diretivaDnolib.allMatches(fonte);
  for (final match in matches) {
    if (match.group(1) != 'package:dnolib/dnolib.dart') {
      return true;
    }
  }
  return false;
}

final _diretivaDnolib = RegExp(
  r'''^\s*(?:import|export)\s+['"](package:dnolib/[^'"]+)['"]''',
  multiLine: true,
);

Iterable<File> _fontesDart(Directory diretorio) sync* {
  if (!diretorio.existsSync()) {
    return;
  }
  for (final entrada in diretorio.listSync()) {
    if (entrada is Directory) {
      final nome = entrada.uri.pathSegments.reversed.skip(1).first;
      if (nome == '.dart_tool' || nome == 'build') {
        continue;
      }
      yield* _fontesDart(entrada);
    }
    if (entrada is File && entrada.path.endsWith('.dart')) {
      yield entrada;
    }
  }
}
