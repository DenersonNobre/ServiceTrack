import 'package:dnolib/dnolib.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('a facade expo tipos dos módulos públicos', () {
    expect(const KeyValue(key: 'id', value: '1'), isA<KeyValue>());
    expect(Migration(version: 1, scripts: const []), isA<Migration>());
    expect(const RestConfig(), isA<RestConfig>());
    expect(const ActionBar(actions: []), isA<ActionBar>());
    expect(StateMachine<int>(initial: 0).currentState, 0);
    expect(
      Money.fromMinorUnits(100, currencyCode: 'BRL', scale: 2),
      isA<Money>(),
    );
    expect(CpfValidator.isValid('529.982.247-25'), isTrue);
    expect(Document.parse('529.982.247-25').isValid, isTrue);
    expect(ValidEmail().validate('user@example.com'), isNull);
    expect(SynapxList<int>([1, 2]).length, 2);
    expect(SynapxMap<String, int>({'a': 1})['a'], 1);
    expect([1, 2].rx, isA<SynapxList<int>>());
    expect({'a': 1}.rx, isA<SynapxMap<String, int>>());
    void takesCallback(SynapxCallback<int> callback) {}
    void takesBinder(SynapxBinder binder) {}
    expect(takesCallback, isA<Function>());
    expect(takesBinder, isA<Function>());

    final rx = Observable<int>(0);
    final doubled = synapxComputed(() => rx.value * 2);
    expect(doubled.value, 0);
    doubled.dispose();
    SynapxEffect.ever<int>(rx, (_) {});
    SynapxEffect.once<int>(rx, (_) {});
    SynapxEffect.debounce<int>(rx, (_) {}, duration: Duration.zero).cancel();
    SynapxEffect.interval<int>(rx, (_) {}, duration: Duration.zero).cancel();
    expect(SynapxTracker(), isA<SynapxTracker>());
    expect(
      SynapxScope(builder: (_) => const ActionBar(actions: [])),
      isA<SynapxScope>(),
    );
    expect(
      SynapxObserver<int>(
        observable: rx,
        builder: (_, __) => const ActionBar(actions: []),
      ),
      isA<SynapxObserver<int>>(),
    );
    final facadeCommand = Command<int, String, void>(
      (_) async => const Success(1),
      mapException: (e, _) => '$e',
    );
    expect(
      SynapxCommandView<int, String, void>(
        command: facadeCommand,
        onSuccess: (_, __) => const ActionBar(actions: []),
      ),
      isA<SynapxCommandView<int, String, void>>(),
    );
    facadeCommand.dispose();
    expect(SynapxCompositeDisposable(), isA<SynapxCompositeDisposable>());
    final testScope = SynapxTestScope();
    expect(testScope, isA<SynapxTestScope>());
    testScope.dispose();
    expect(SynapxModuleScope(), isA<SynapxModuleScope>());
    expect(
      SynapxProvider.value(
        value: SynapxModuleScope(),
        child: const ActionBar(actions: []),
      ),
      isA<SynapxProvider>(),
    );
    expect(SynapxRouteObserver(), isA<SynapxRouteObserver>());
    expect(SynapxRouteContext(uri: Uri.parse('/')), isA<SynapxRouteContext>());
    expect(const SynapxGuardAllow(), isA<SynapxGuardResult>());
    expect(SynapxRouteGuardRunner(), isA<SynapxRouteGuardRunner>());
    expect(
      SynapxApp(builder: (_, __, ___) => const ActionBar(actions: [])),
      isA<SynapxApp>(),
    );
    expect(
      SynapxRouteScope(
        createScope: (_) => SynapxModuleScope(),
        builder: (_) => const ActionBar(actions: []),
      ),
      isA<SynapxRouteScope>(),
    );

    final command = Command<int, String, void>(
      (_) async => Success(1),
      mapException: (_, __) => 'erro',
    );
    expect(command, isA<Command<int, String, void>>());
    expect(Success(1).getOrNull(), 1);
    expect(const NotFoundFailure('x'), isA<IFailure>());
    command.dispose();
  });
}
