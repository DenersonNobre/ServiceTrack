# LEARNINGS — dnolib

## 2026-11-19 — Synapx E0: identidade canônica (`Synapx*`, `*Extension`, sem aliases)

- **Rename limpo, sem shim**: todos os componentes públicos de `lib/synapx/` passaram
  ao prefixo `Synapx` e as extensions ao sufixo `Extension`; nomes antigos foram
  removidos e `example/`, testes e docs migrados no mesmo slice. Decisão do
  mantenedor: identidade > compatibilidade retroativa neste ciclo (breaking change
  registrada no CHANGELOG).
- **Workers como fachada**: funções top-level (`ever`, `once`, `debounceRx`,
  `intervalRx`) viraram `SynapxEffect.ever/once/debounce/interval` — top-levels não
  têm um namespace natural para o prefixo; a classe estática dá a identidade sem
  perder a chamada tipada.
- **Gates mecânicos, não disciplina**: `test/synapx/identity_test.dart` varre
  `lib/synapx/src/**` e reprova declaração pública sem prefixo `Synapx`;
  `test/synapx/legacy_names_test.dart` varre `lib/`, `test/`, `example/lib`,
  `example/test` e reprova nomes antigos. Ambos têm prova negativa (fixture que
  deve reprovar) — gate que nunca falhou não foi exercitado.
- **Armadilha do próprio gate**: o scan de `ever(`/`once(` acusava as declarações
  canônicas `static ... ever<T>(` de `SynapxEffect`. Fix: ignorar matches em linha
  `static` (métodos da fachada), mantendo a detecção de chamadas top-level antigas.
- **Medição**: `puro flutter analyze --fatal-infos lib test` limpo (raiz e
  `example/`), suíte raiz **440** testes verdes, `example/` **19** testes verdes;
  gates de identidade/legado verdes.

## 2026-11-18 — POC Synapx em `./example` (VSA, Desktop SQLite e gates no Windows)

- **SQLite no Windows Desktop (`sqflite_common_ffi`)**: manter `sqflite_common_ffi` apenas em `dev_dependencies` passa nos testes mas falha ao executar o app ao vivo no desktop; movê-lo para `dependencies` e inicializar `sqfliteFfiInit()` + `databaseFactoryFfi` quando `!kIsWeb && (Platform.isWindows || Platform.isLinux || Platform.isMacOS)` habilita execução real sem afetar mobile.
- **Lock de `build\unit_test_assets` no Windows**: executar `flutter analyze` e `flutter test` em paralelo no mesmo subprojeto (`example/`) causa erro de permissão/acesso em `build\unit_test_assets`; rodar em sequência evita o conflito.
- **VSA em `example/` com retrocompatibilidade**: ao extrair `CustomerApp` (`app/`) e `CustomerPage` (`features/customers/`), reexportá-los em `example/lib/main.dart` mantém o bootstrap enxuto sem quebrar imports de testes existentes.

## 2026-11-18 — Remoção do `.modelo/` aninhado e adoção do `./example` como POC do Synapx

- O diretório `.modelo/` rastreado dentro da `dnolib` foi removido do repositório (resolvendo o Gap 3.5 de `docs/analise-2026-10-13.md`); o `./example` assumiu o papel de POC viva do módulo `synapx` dentro do workspace.

## 2026-11-18 — Synapx slice 0.2: `RouteGuardRunner` e adapter `ScopeRouteBuilder`

- Usar um contador monotônico `_generation` em `RouteGuardRunner` (incrementado em `evaluate` e `cancel`) descarta automaticamente execuções assíncronas obsoletas (duplo tap ou `pop` durante `await`), sem depender de `CancelableOperation` externo.
- Manter o roteamento como adapter fino (`ScopeRouteBuilder` sobre `ScopeWidget.value` + `RouteGuardRunner`) acopla `ModuleScope` e guards ao roteador já escolhido pelo app (`RouterConfig` / `go_router`), evitando competir com `RouterDelegate`.

## 2026-11-18 — Synapx slice 0.1c: ciclo de vida com `ModuleScope` e `reassembleApplication` em testes

- Em `ModuleScope.registerLazySingleton`, rastrear `materialized` antes de encapsular `LazyProxy` evita instanciar um singleton preguiçoso apenas para descartá-lo quando o escopo fecha sem que ele tenha sido lido.
- Em testes de widget (`testWidgets`), `await tester.binding.reassembleApplication()` aguarda o próximo frame — chamá-lo com `await` antes de `await tester.pump()` trava o teste; usar `unawaited(tester.binding.reassembleApplication())` seguido de `await tester.pump()`.
- `NavigatorState.push` e `pushReplacement` retornam `Future` resolvido apenas no pop: sob `flutter analyze --fatal-infos` (`unawaited_futures`), envolver em `unawaited(...)` quando o teste não aguarda o retorno da rota.

## 2026-11-18 — Synapx slice 0.1b: RxTracker via Zone sem dependência circular `core -> synapx`

- Para evitar que `lib/core/patterns/observable.dart` importe `lib/synapx/` (o que inverteria a hierarquia de camadas), `Observable` expõe apenas `Observable.readTrackerZoneKey` e consulta `Zone.current[readTrackerZoneKey]` em `get value`.
- `RxTracker` (em `lib/synapx/src/reactive/synapx_tracker.dart`) injeta seu `recordRead` nessa chave durante `runZoned` e desliga `_active` no `finally` — garantindo isolamento entre escopos aninhados/concorrentes e bloqueando leituras tardias em `Future`/`Timer` que herdaram a `Zone`.
- `SynapxScope` reconcilia o delta de assinaturas por frame (`_reconcile`), cancelando tokens de observáveis que deixaram de ser lidos e limpando tudo no `dispose()`.

## 2026-10-13 — Estado da Wiki no Gitea e autenticação API × Git

- Nesta instalação, não tratar `tea wiki list` sem páginas como prova de que a Wiki não existe: o
  mantenedor informou que ela foi criada, enquanto `tea wiki create --title Home` respondeu que
  `Home.md` já existe. Na mesma sessão, `tea wiki view Home` retornou “The target couldn't be found”.
  São respostas incompatíveis; conferir a interface web antes de criar ou editar para evitar duplicar
  conteúdo.
- A leitura da API pelo perfil `denerson` e a autenticação do clone Git da Wiki são caminhos distintos.
  O clone de `http://gitea.lan/DartFlutter/DNOLib.wiki.git` falhou com `Authentication failed`; ter um
  login listado no `tea` não comprova que o helper de credenciais do Git esteja autorizado para esse
  repositório `.wiki.git`.
- Limite da evidência: não foi possível verificar pela interface web o conteúdo de `Home.md`, nem
  confirmar se a falha do clone é escopo, credencial ou configuração do servidor. O `HANDOFF.md`
  registra o estado operacional para a próxima sessão.

## 2026-10-01 — Adaptação de utilitários recusados

- Separe regras regionais brasileiras da biblioteca geral: algoritmos puros
  e formatters de input vivem em `lib/brlib`, fora da facade e fora do `core`.
  Isso mantém a dependência de framework na borda do módulo, não no núcleo.
- CNPJ alfanumérico tem 14 posições: as 12 primeiras aceitam `A-Z` e `0-9`, e
  as duas últimas são dígitos verificadores numéricos. No cálculo, converta
  cada caractere ASCII subtraindo 48, como especifica a Receita Federal. Fonte:
  https://www.gov.br/receitafederal/pt-br/centrais-de-conteudo/publicacoes/documentos-tecnicos/cnpj
- Um tipo monetário reutilizável deve explicitar código da moeda e escala; usar
  `BigInt` para unidades menores evita erro binário de `double`. Parsing textual
  deve receber separadores e política de arredondamento explicitamente.
- `ValueNotifier` torna `Command` uma abstração de apresentação Flutter. A API
  resultante não substitui diretamente uma implementação anterior baseada em
  GetX; contratos e migração precisam ser verificados no consumidor.

## 2026-10-02 — Observer não é Rx: vocabulário antes de pattern
- `update()` no legado é CRUD HTTP (`datasource.update`, `unit_of_work.update`),
  não GoF Observer. O único Observer do legado é `EventBus`, com `emit`/`on`, e
  ele não tem `update`. Antes de tratar dois nomes como sinônimos, confirme a
  assinatura no código: o nome parecido esconde o pattern diferente.
- `subscribe`/`unsubscribe` é vocabulário ReactiveX (`rxdart`,
  `BehaviorSubject`, GetX). Este repo não tem `rxdart` nem `get`; o precedente é
  `on(listener) -> token`. Adotar `subscribe` seria importar a nomenclatura de um
  ecossistema que o projeto não usa, criando uma terceira via onde já havia uma.
- `ValueListenable` do Flutter já substituiu a interface `Observer`: listeners
  são closures, canceladas por identidade. O que faltava não era uma classe
  `Observer`, era o handle equivalente ao `StreamSubscription`.
- Dart tem tipagem nominal: `Observable<T>` NÃO satisfaz `ValueListenable<T>`.
  O adapter é obrigatório, não conveniência.
- O adapter precisa mapear `closure -> token` para que `removeListener` cancele
  a assinatura correta. Um `List` paralelo ou um `removeWhere(isActive)` cancela
  a errada quando há mais de um listener.
- Cuidado ao escrever teste de cancelamento com cascade: `..value = 1 ..cancel()`
  notifica ANTES de cancelar. Um `[1]` inesperado é o teste errado, não a
  implementação — leia a intenção antes de mexer na implementação.
- Gate precisa de prova de que falha: insira uma violação real (`import
  'package:flutter/...'` sob `lib/core`), confirme que reprova, e remova. Sem
  isso, um gate quebrado é indistinguível de um gate verde.
- Um documento de decisão viva pode registrar o resultado **antigo** enquanto o
  código registra o **novo**: `WIDGETS_FILTER.md` (depois removido com os
  demais filtros) listava `PillField` entre os rejeitados e `HANDOFF.md` o
  tratava como aceito, com o arquivo implementado e testado. Quando docs
  divergem, quem decide é a leitura
  da implementação — não a data nem a autoridade do documento.
- Critério de rejeição que contradiz a política do próprio pacote é sinal de
  decisão desatualizada, não de exceção legítima: o motivo de recusa de
  `PillField` era "não há evidência de necessidade em mais de um projeto", mas a
  política afirma que a falta de dois consumidores não bloqueia abstração com
  contrato genérico. Antes de manter uma recusa, teste o motivo contra a regra
  que o documento vizinho escreveu.
- Dependência declarada em `pubspec.yaml` e nunca importada é contrato falso:
  promete uma relação que o código não usa. Corrigir em um sentido — remover ou
  passar a usar — nunca deixar como está, porque o próximo leitor conclui errado
  sobre a arquitetura.

## 2026-10-02 — Validators genéricos e fim dos pacotes Pub

- Wrappers de validator no core seguem o padrão do arquivo, não override: a
  classe base expõe `validate` como campo (`final String? Function(T)`), então
  a subclasse passa closure no `super` e NÃO pode ser `const`. Tentar método
  `validate` + `const` quebra em dois erros (conflito campo/método e super não
  constante) — o precedente (`NotEmpty`, `MinLength`) já mostrava o caminho.
- Semântica opcional por padrão: `ValidEmail`/`ValidPassword`/`ValidDate`
  retornam `null` para vazio e compõem com `NotEmpty` quando obrigatório —
  igual aos wrappers `Valid*` do legado. Algoritmo puro (`isValid*`/`PasswordPolicy`)
  separado de política (parâmetros) e mensagem (argumento `message`).
- `passwordStrength('Abcdefgh1!')` de 10 chars é `weak` pelo corte legado
  (`length < 11`): teste que espera `strong` com senha curta testa o dado
  errado, não a implementação — contar os caracteres antes de acusar o código.
- Módulo regional e pacote Pub são coisas distintas: `lib/brlib/` é biblioteca
  do pacote único (mesmo resolvedor, barrel próprio fora da facade);
  `packages/` era distribuição independente (pubspec próprio, Dart puro sem
  Flutter). Fundir os pacotes em módulos elimina a dependência fantasma, mas
  o barrel único (`brlib.dart`) passa a importar Flutter via
   `input_formatters/` — por isso ele mora fora do `core`, sob o mesmo
  argumento do `widgets`.
- Diretório vazio com lock do analysis server não sai nem com `rmdir`: 4
  `language-server` simultâneos (IDE + sessões de agente) seguram handles de
  diretório. O da IDE se identifica por `--client-id=VS-Code`; os órfãos de
  agente são `language-server --lsp` nus. Encerre os órfãos e o lock solta sem
  reiniciar a IDE (foi o que liberou o último `packages/dnolib_money`).
  Derrubar o LSP da própria sessão só cega os diagnósticos LSP — `puro flutter
  analyze`/`test` pelo shell continuam verificando tudo.
- Módulo de um arquivo só é sinal de recorte errado, não de encapsulamento:
  `lib/money/` tinha barrel + 1 unit e não justificava residência própria.
  Fundir no módulo que casa com a natureza do tipo (`Money` → `core/models`)
  reduz fragmentação sem perder o barrel público — a visibilidade no import
  é o mecanismo de corte, não a existência de diretório.
- Criar `lib/utils/` ao lado de `core` = dois baldios para o mesmo escopo
  genérico (`core/helpers` já é o bucket). Antes de nomear um módulo novo,
  procure onde o conteúdo genérico já cabe — se `core` abriga, não nasça um
  segundo diretório.
- Facade única exportando tudo + `show`/`hide` no import do consumidor
  substitui "módulo fora da facade": neutralidade decide **onde o código
  mora**, o app decide **o que enxerga**. Isso dissolve o trade-off
  "incluir na facade pesa quem não usa" — o corte é do consumidor, e a
  facade vira o único contrato público do pacote.
- Provar facade por teste de símbolo: `facade_test` instancia um tipo de
  cada módulo exportado (`Money`, `CpfValidator`, `ValidEmail` incluídos) —
  um export esquecido vira vermelho, não silêncio de compilação.

## 2026-10-02 — Teste de formatter: simular o mecanismo, não o resultado
- Ao escrever teste de `TextInputFormatter`, o `newValue` precisa simular o
  que o `EditableText` entrega: backspace remove o caractere **antes** do caret
  e o caret vira `caret - 1`; digitar com seleção substitui o trecho e colapsa
  o caret no ponto de inserção. Derivar o `newValue` "de cabeça" produz
  cenários impossíveis (ex.: backspace apagando um separador que está **depois**
  do caret) e o teste falha por erro do input, não do código — 4 das 6 falhas
  iniciais da cobertura dos formatters eram desse tipo.
- Antes de concluir que o código está errado num Red, conferir se o `newValue`
  do teste é um estado que o mecanismo real pode produzir (comprimento, caret,
  posição do caractere removido). O formatter só roda quando **o texto muda**
  (`editable_text.dart`, `_formatAndSetValue`): mudança só de seleção não passa
  por `formatEditUpdate`.
- Backspace sobre separador de máscara (`.`, `-`, `/`) era no-op + caret
  andava 1: a remascaração reinsere o separador e o dígito vizinho exigia
  dois toques. Fix: detectar deleção de exatamente um caractere não
  alfanumérico e remover também o dígito anterior ao cursor — um toque sempre
  apaga um dígito. Deleção de letra (CNPJ alfanumérico) não entra na regra.

## 2026-10-02 — Revisão de utilitários legados: nada a portar
- `numbers.dart` inteiro é redundante com `Money`: `strToDouble`/`doubleToStrBr`/
  `formatarNumero`/`formatarValor` operam em `double` (erro binário por
  construção) e dois deles puxam `intl`; `Money.tryParse`/`Money.format` com
  separadores explícitos cobrem os casos sem `intl` e sem float.
  `isNumber`/`isNotNumber` é one-liner usado só por `strToDouble` — sem valor
  como API pública.
- `dates.dart`: `dataDMA` é `DateTime(a, m, d)`; `dateToUnix`/`unixToDate` são
  `millisecondsSinceEpoch` com um `.abs()` suspeito (corrompe datas pré-1970);
  `weekNumber`/`today`/`formatarData` puxam `intl`; `weekDay` tem o mapeamento
  errado — indexa `DateTime.weekday` (segunda=1) numa tabela domingo-primeiro,
  então devolve `'Terça'` para quarta-feira (25/12/2024, `isoweekday()=3`) e
  erra os 7 dias da semana. Nenhuma das 7 funções foi portada.
- `maps.dart`/`consts.dart`/`enums.dart` (utils) são dados de UI em português
  (`MESES_ANO_EXT`, `DIAS_SEMANA_EXT`, `ESTADOS_BR_EXT`, `TIPOS_PESSOAS`,
  `SEXOS`, `Ambiente.homeOffice`…) — fora do escopo de lib agnóstica com
  identificadores em inglês. O que tinha valor de domínio já existe:
  `UfValidator` (UFs), `PasswordStrength`, máscaras como literais nos
  formatters.

## 2026-10-02 — Teste de UI desacoplado de SQLite (DIP) e gate de consumo da facade
- No Flutter, `testWidgets` roda sob `FakeAsync`. O `databaseFactoryFfi` padrão
  spawna um `Isolate` de I/O em background. Mensagens do isolado e callbacks de
  fechamento dependem de microtasks que o `FakeAsync` intercepta; chamadas assíncronas
  ao banco dentro do ciclo de vida ou no teardown (`provider.close()`) travam
  indefinidamente em silêncio (timeout de 10 min).
- Teste de widget deve testar a UI, binding de formulário, formatação, validação e
  apresentação do `Command`. A persistência SQLite real deve ser testada em `test()`
  puro (fora de `testWidgets`), onde o event loop real drena o isolate sem travas.
- Aplicar o Princípio de Inversão de Dependência (DIP): a interface `CustomerRepository`
  desacopla a tela do `CustomerStore` (SQLite). No teste de widget, injeta-se um
  `FakeCustomerRepository` em memória (puro-Dart); no app real, injeta-se o `CustomerStore`.
  Resultado: teste de UI executa em 4 segundos, sem locks de SQLite nem falhas de teardown.
- Gate mecânico de consumo da facade: consumidores reais devem importar estritamente
  `package:dnolib/dnolib.dart` com `show`/`hide`. Barrels internos (`dnolib/core/...`,
  `dnolib/widgets/...`) e arquivos privados (`src/...`) são proibidos. O gate
  `test/example_facade_consumption_test.dart` garante essa invariante inspecionando
  as diretivas import/export do `example/`.

## 2026-10-06 — Lock resolvido pelo env errado: PATH flutter ≠ env do `.puro.json`

- O repo fixa `{"env": "v3-38-10"}` no `.puro.json`, mas o `flutter` no PATH desta
  máquina apontava para outro env (`v3-35-1`): os gates da F1 (F0–F1 da decisao-001)
  commitaram o `pubspec.lock` resolvido pelo env errado (meta 1.16.0, test_api 0.7.6,
  test 1.26.2) e o próximo `puro flutter` (env pinado) reescrevia o lock com upgrades
  (meta 1.17.0, test_api 0.7.7, test 1.26.3, test_core 0.6.12) — ping-pong de lock.
- Evidência: `Get-Command flutter` → `A:\Desenvolvimento\Puro\envs\v3-35-1\flutter\bin\flutter.bat`;
  `.puro.json` → `v3-38-10`; `git diff pubspec.lock` mostrava só a cadeia
  `test`/`meta` subindo, com gates verdes nos dois envs.
- Correção/prevenção: `pub get` e gates sempre via `puro flutter` (lê o `.puro.json`),
  nunca o binário solto do PATH. Commitar o lock re-resolvido no env pinado encerra o
  ping-pong — restaurar o lock errado só adia a reescrita para o próximo gate.
- O mesmo vale ao consumir esta lib nos apps: o env que resolve o lock do **app** é o do
  `.puro.json` daquele app; locks de dependências git mudam de resolução junto com o env.

## 2026-10-11 - `melos version` pulava o package privado: chave no lugar errado

- A lib é `publish_to: none` (privada), e o `melos version` a PULAVA em silêncio
  ("No packages were found that required versioning"), sintoma que se confundia com
  "nada a versionar". Causa raiz: `versionPrivatePackages: true` estava no TOPO de
  `melos:`; o melos 8.9.0 lê a chave de `command/version` (`VersionCommandConfigs.fromYaml`),
  então no topo ela é ignorada. `melos version --all` contornava sem depender da config.
- Corrigido: `command.version.versionPrivatePackages: true` no `pubspec.yaml`.
  Provado numa branch-sonda (nunca publicada) com commit real tocando `lib/`: sem `--all`,
  versionou `dnolib 0.4.0 -> 0.4.1`.
- Gotcha da sonda: commit vazio (`--allow-empty`) NÃO é atribuído a package nenhum (o melos
  atribui commits pelos arquivos tocados), então uma sonda com commit vazio dá falso "nada a
  versionar" mesmo com a config correta.
- Aprendizado transversal (tópico Flutter dos dotfiles): local canônico da chave, `-y`
  inválido (a flag é `--yes`) e sonda exige arquivo tocado.

## 2026-10-13 — Retry drena a resposta: decorator externo nunca a vê

- **O `RetryClient` descarta as respostas intermediárias**: `send()` faz
  `await response.stream.drain()` antes de reenviar. Logo, para registrar **cada
  tentativa**, o logging precisa ficar **DENTRO** do retry — decorator externo a ele
  só vê a resposta final. A análise original afirmava o **contrário**; quem escreveu a
  correção também inverteu antes de medir. Medido com 2 tentativas (1 `503` + 1 `200`):

  ```text
  retry > logging > base          2 linhas  ← registra cada tentativa
  logging > retry > base          1 linha
  logging > CB > retry > base     1 linha
  logging > retry > CB > base     1 linha
  ```

  **Lição**: um decorator que faz fast-fail (drain + retry) consome o valor que os
  decorators externos tentam observar. A posição relativa só se resolve por medição —
  ler o código dá a resposta intuitiva, e a intuitiva está errada.
- **O circuit breaker fica por fora do retry de propósito**: entre o retry e o base, cada
  tentativa interna contaria como falha separada, saturando o `failureThreshold` antes do
  que o chamador espera.
- **Um teste verde pode validar o comportamento errado**: `middleware_test.dart` fixava
  `.retrying().logging()` e afirmava `hasLength(1)` — congelava a composição que perdia
  evidência. Antes de aceitar um teste como contrato, perguntar *que efeito ele mede*, não
  apenas *se ele passa*. Hoje o teste verifica o conteúdo (503 na primeira linha, 200 na
  última) e há um teste de contrato que compara três ordens de registro.

## 2026-10-13 — Falha transitória vs definitiva: o `catch (_)` come o fast-fail

- **`RetryClient` tratava `CircuitOpenException` como erro de transporte** e rodava o
  backoff inteiro sobre uma falha já definitiva. Com os defaults do `ClientStack.retrying()`
  (3 tentativas, 200 ms, fator 2): `200 × 2^0 + 200 × 2^1 = 600 ms` — porque a última
  tentativa não espera (`if (attempt >= maxAttempts) rethrow` antes do `_wait`). Medido
  em teste: **158 ms → < 50 ms** com a guarda `on CircuitOpenException { rethrow; }`.
- **Aritmética de backoff: o expoente é `attempt - 1`, e a última tentativa não espera.**
  Somar "1 + 2 + 4" dá 7× o delay real. Sempre conferir a ordem entre o `_wait` e a
  condição de saída do laço.
- **`catch (_)` genérico esconde a semântica das exceções.** Quando um decorator parceiro
  define uma exceção com significado próprio (circuito aberto, auth expirada, quota), ela
  merece uma clause `on` explícita antes do genérico.
- **Teste que isola a unidade**: o primeiro teste do `CircuitOpenException` usava
  `maxAttempts: 3`, e o próprio retry abria o circuito *dentro da mesma chamada* — media a
  coisa errada e falhava mesmo com a correção. Abrir o circuito por chamada direta ao
  breaker, fora do retry, isola a asserção.

## 2026-10-13 — Gate que não cobre o que parece cobrir

- **`melos list` via só o pacote raiz**: o bloco `melos:` não declarava `packages` e o
  `example/` não era membro de workspace pub. Consequência: `example/pubspec.lock` ficava
  fora do `enforceLockfile` e derivava sem ninguém notar (mudou sozinho de `dnolib 0.4.0`
  para `0.4.1` durante a sessão). Corrigido com `workspace: [example]` no pubspec raiz +
  `resolution: workspace` no exemplo; o lock único sobe para a raiz.
- **`require_trailing_commas` pressupõe o formatter, mas o formatter não era gate**:
  37 de 136 arquivos estavam fora do `dart format`. O analyzer sinalizava estilo e a
  formatação nunca era verificada — lint e formatter são gates distintos.
- **Cabeçalho de script que documenta um caminho que o código não usa**: `plan-gate.ps1`
  descrevia `docs/plan/epics/` no cabeçalho e resolvia `Join-Path $PlanDir 'Epics'` no
  código. O comment foi escrito na migração e a linha de código não acompanhou.
  **Ao renomear pasta, `grep` por texto não acha link relativo** — `(Epics/epic-xx.md)`
  não menciona a pasta-raiz. Procurar pelo nome do subdiretório também.
- **Renomear pasta quebra o release**: `release.ps1` passava `-PlanPath 'Docs/Plan'`, que
  deixa de existir. O gate de paridade falhou e impediu o commit — o valor do gate estava
  em pegar isso, não em ser burocracia.
- **Pastas em minúsculas é convenção de portabilidade**: em volume compartilhado entre
  Linux e Windows, `Docs/` e `docs/` coexistem em NTFS e colidem em Linux. Exceções que
  valem: pastas impostas por plataforma (`Android/`, `iOS/`, `Runner/`) e o conteúdo de
  arquivos de projeto (`.lpi`, `.dpr`), onde o casing é do projeto do usuário.
- **Log com duração no texto não é comparável por `==`**: a linha do `LoggingClient`
  termina em `(5ms)`, e o tempo varia entre execuções. Um teste que comparava as listas
  inteiras com `==` passava na suíte completa (execuções adjacentes, mesmo ms) e falhava
  isolado (`5ms` vs `0ms`). **Comparar o campo que o contrato determina** — aqui, os
  status — e deixar o volátil de fora. Teste que passa na suíte e falha isolado costuma
  ser dependência de ordem ou comparação de valor não determinístico.

## 2026-10-14 — melos version calculou patch com feats no range

- **Fato**: `melos version --yes` 8.9.0, em `main`, com `feat(core)` e `feat(rest)`
  entre `v0.4.1` e HEAD, bumpou `dnolib 0.4.1→0.4.2` ("minor changes") em vez de
  `0.5.0`. O CHANGELOG gerado listava os FEATs corretamente — só o número veio
  errado. Em `0.x`, feat exige minor pela política do repo (decisao-001 §2).
- **Ação**: revertido antes de qualquer publicação (`git tag -d` das duas tags
  locais + `reset --hard` do commit do melos — nada havia saído da máquina) e
  refeito manual equivalente: bump `0.5.0`/`0.2.0` (example), CHANGELOG,
  `chore(release)`, tags anotadas a partir de `main`.
- **Regra**: conferir o número calculado pelo melos antes de aceitar — o conteúdo
  do CHANGELOG pode estar certo com o bump errado. Reverter tag **local e não
  publicada** não viola a regra de imutabilidade de tag (ela protege a âncora
  consumida pelos apps).

## 2026-10-14 — Promoção Document via Jornada A (piloto)

- **Origem**: `Document` nasceu no `.modelo` (backlog item 1, extension types) e foi
  promovido para `lib/brlib/src/document.dart` — arquivo único no `src/`, sem
  diretório próprio, conforme a regra de topologia. Imports relativos internos,
  export alfabético no barrel, asserção em `facade_test.dart`.
- **Passo 4 no app**: cópia local apagada, consumo via facade; 54 testes verdes
  no modelo, 299 na lib. Release com o tipo (0.6.0) em ciclo próprio.

## 2026-10-17 — Evidências do app `.modelo` como consumidor de teste

- **Papel**: `.modelo` é um app Flutter de teste da dnolib. O diretório foi movido
  para dentro deste checkout; preservá-lo como consumidor mantém uma prova de
  integração real, além dos testes unitários da biblioteca.
- **Imports seletivos**: no app, sub-barrels (`.domain.dart`/`.features.dart`)
  mantêm o grafo de domínio sem UI; testes e presentation usam barrels com `show`.
  `--fatal-infos` detecta símbolos omitidos e nomes sobrando. Isso é uma escolha
  interna do consumidor, não um contrato novo da facade.
- **Goldens**: a prova visual usa viewport, datas e estado determinísticos;
  inspecionar PNGs antes de atualizar referências. Falhas em
  `test/goldens/failures/` são descartáveis.
- **SQLite**: no histórico do app (300 pedidos × 3 itens), N+1 fez 301 queries em
  180–255 ms; um `LEFT JOIN` fez o mesmo caminho em 46 ms. O mapeamento de 900
  linhas levou 9,1 ms inline e 11,2 ms via `compute`; para essa escala, manter
  inline. São medidas do consumidor, não garantia de desempenho geral da lib.
- **Paginação/scroll**: o port do app aceita `Paginate?`, com `null` preservando a
  consulta integral; InMemory e SQLite compartilham contrato. Estado de
  carregamento fica no presenter; o widget detém e descarta o `ScrollController`.
- **Limite para abstrair scroll**: survey de cinco apps irmãos encontrou zero
  consumidores adicionais da dnolib; `contatos_jr` usa GetX, sem compatibilidade
  direta com `Observable`/`Command`. Não extrair widget genérico de scroll até
  existir um segundo consumidor compatível.
- **Histórico aninhado**: o repositório `.modelo` estava limpo em `develop`, commit
  `456d55c`, 36 commits à frente de `main` e sem remote. O histórico foi importado
  para o Git de `.dnolib` nas refs locais `archive/modelo/develop`,
  `archive/modelo/main` e `modelo/v0.1.0`…`modelo/v0.2.2`. Assim, remover
  `.modelo/.git` não apaga os objetos/refs importados; excluir a pasta inteira
  ainda removeria o app de teste. As refs importadas foram publicadas em `origin`
  em 2026-10-18 junto com o histórico de `main` e `develop`.
## 2026-11-18 — Slice 0.1a Synapx: `lib/synapx/` nasce com Red-Before-Green

- **Red medido**: stubs (assinaturas sem comportamento) + 29 testes novos em
  `test/synapx/` -> `+8 -21`, falhando exatamente os comportamentos novos
  (notificação de coleções, `onCancel`, isolamento de erro, debounce/interval).
  Green: `+29` no slice; suite completa `+378, All tests passed!`;
  `analyze --fatal-infos` limpo; format aplicado no slice.
- **`RxList`/`RxMap` via mixin, não via delegação manual**: `extends
  Observable<List<E>> with ListMixin<E>` reaproveita notificação/tokens/descarte
  e exige sobrescrever só os mutadores (uma notificação por chamada efetiva).
  Expor a coleção viva em `value` é decisão documentada: leitura direta não
  notifica — mutar sempre pela API do `Rx`.
- **`batch` abortado descarrega o parcial**: exceção em `action` notifica o estado
  real acumulado antes de propagar (via `finally`), em vez de engolir a
  notificação. Contrato fixado em teste (`seen == [[1], [1, 2]]`).
- **`Observable` ganhou 3 APIs aditivas (sem quebra)**: `on(..., {onCancel})`
  (gancho único em `cancel()` e `dispose()`, erros para a `Zone`),
  `notify()` público e isolamento de erro em `_notify` (listener que lança não
  cala os demais — erro vai para `Zone.current.handleUncaughtError`).
- **Armadilhas de lint**: `avoid_renaming_method_parameters` exige os nomes exatos
  do SDK nos overrides (`fillRange(..., [E? fill])`,
  `addEntries(Iterable<MapEntry<K, V>> newEntries)`); `dart format` só nos arquivos
  do slice — formatar a árvore inteira arrastaria drift pré-existente de
  `test/widgets/` para o commit.
- **`pubspec.lock` com churn de ambiente** (downgrades transitivos só por rodar o
  `puro` aqui) ficou fora do commit do slice: lock estranho ao slice não entra.
## 2026-11-18 — Ergonomia Synapx: typedefs, `.rx` e diálogos com contexto

- **Red**: falhas de compilação nos símbolos novos (`.rx`, `confirm`,
  `notifySuccess`/`notifyError`) + teste diamante como trava de regressão.
  Green: `+36` no recorte; suíte completa `+440, All tests passed!`;
  `analyze --fatal-infos` limpo.
- **Typedefs com adoção imediata**: `RxCallback<T>` nas 4 assinaturas de workers
  e `ScopeBinder` em `ScopeRouteBuilder.bind`, `SynapxApp.bind` e
  `SynapxTestScope.overrides` — typedef sem uso é peso morto; adotar no mesmo
  commit prova o valor.
- **`.rx` sem risco de colisão**: extensions vivem no escopo do import; conflito
  futuro com outro pacote falha em compilação (ambiguous extension), nunca em
  silêncio; `hide RxListBind` é a válvula. Cópia documentada: origem não é
  afetada.
- **SnackBar exige Scaffold descendente**: `ScaffoldMessenger.showSnackBar`
  falha sem `Scaffold` na árvore — teste de `notifySuccess`/`notifyError`
  precisa de `Scaffold(body: ...)`. Primeira hipótese (match exato vs texto
  `'$title\n$message'` do Alert) estava errada; a evidência (assertion do
  gesture) apontou a causa real.
- **Facade e typedefs**: declaração local `RxCallback<int> f(_) {}` quebra em
  `body_might_complete_normally`; usar o typedef como tipo de parâmetro
  (`void takesCallback(RxCallback<int> callback) {}`) compila limpo.
## 2026-11-18 — Form sem TextEditingController no example (draft + reset)

- **Fonte de verdade no modelo, mecanismo no `Form`**: `CustomerDraft` mutável
  recebe cada tecla via `onChanged` (`initialValue: ''`); submit lê o draft e
  limpa com `draft.clear()` + `FormState.reset()`. Cinco controllers e cinco
  `onDispose` sumiram do `CustomerController`; `GlobalKey<FormState>` continua
  (chave não tem lifecycle).
- **Por que não reconstruir controller por build**: controller guarda cursor,
  seleção e composição do IME — recriá-lo a cada tecla quebra a digitação.
  Sem controller não há nada para recriar: o campo guarda o próprio estado
  até o `reset()`.
- **Prova de equivalência**: testes de widget do fluxo (CPF inválido, cliente
  válido, synapx_poc) passaram **sem alteração**; só o teste unitário novo do
  draft entrou (`+11` -> `+13`).
## 2026-11-19 — Controllers na UI, casos de uso em commands (example)

- **Controller é presentation**: `CustomerController`/`CustomerOrdersController`
  seguram estado de tela (draft, `error`, `FormState`) e orquestram — moram em
  `modules/<m>/ui/`. `commands/` guarda um caso de uso por arquivo, puro sobre
  a porta (`submitCustomerForm`, `submitCustomerOrder`), sem UI nem Synapx.
- **Caso de uso devolve `IResult<Entidade, String>`**, não bool: falha carrega
  a mensagem, sucesso carrega a entidade com o id atribuído. Controller só
  mapeia para observável e recarrega.
- **Red antes do move**: teste unitário do caso de uso (saldo inválido falha
  sem tocar o repositório) escrito contra arquivo inexistente; `+13` -> `+15`
  verdes com os fluxos de widget inalterados.
## 2026-11-19 — Delete com confirm e debounce sem parâmetro (example)

- **Confirm é UI, caso de uso é puro**: o botão chama `context.confirm` e só
  com `true` + `mounted` dispara `controller.deleteCustomer`, que delega a
  `deleteCustomer()` puro e recarrega. `deleteCommand` novo na porta + store
  (via `delete(KeyValue)` do CRUD), com `Failure` gracioso em id nulo.
- **Teste widget exige `ensureVisible`**: botão abaixo da dobra falha no tap com
  aviso de off-screen e o diálogo nunca abre — mesmo padrão já usado no POC.
- **Parâmetro de tuning virou constante**: `searchDebounce` saiu do construtor
  (ruído antecipatório — nenhum teste digitava na busca e widget test roda em
  tempo fake). `static const` documenta a decisão sem custo no teste. Regra:
  construtor carrega colaboradores; constante documenta tuning.
## 2026-11-19 — Imports relativos com barrels nas fronteiras (example)

- **`package:` só de fora**: `test/` continua `package:dnolib_example/...`;
  dentro de `lib/`, tudo relativo (lint `prefer_relative_imports` travando).
- **Barrel na fronteira, direto dentro da camada**: `domain/`, `data/`,
  `commands/` e `ui/` expõem `.index.dart` para quem está fora; dentro da
  mesma camada, import direto no arquivo. Sem essa disciplina o barrel vira
  indireção gratuita — ou ciclo (arquivo importando o barrel que o exporta).
- **Ordem das seções cobra pedágio**: `package:` (dnolib, flutter) antes dos
  relativos, e `../..` antes de `./` (comparação lexicográfica). Migração
  mecânica validada por analyze + `+19` testes verdes sem tocar em lógica.
## 2026-11-19 — Norma anti-linha-longa: trailing_commas preserve

- **Três peças, uma norma**: `formatter: trailing_commas: preserve` (a vírgula
  final força a quebra) + lint `require_trailing_commas` (cobra a vírgula em
  lista já quebrada) + `puro dart format` em modo escrita antes do commit.
  Registrado em `AGENTS.md` como convenção.
- **Por que quebrou antes**: lint cobra, mas quem quebra é o formatador — e a
  geração antiga (SDK do PATH/IDE) *apagava* a vírgula ao juntar a linha,
  enquanto a nova (Puro pinado) a preserva. `include` + `analyzer` sem o bloco
  `formatter:` deixava as duas gerações brigando no mesmo repo.
- **Custo único**: 1 arquivo requebrado (`route_guard_test`, 42 linhas);
  raiz `+440` e example `+19` verdes após a normalização.
## 2026-11-19 — Ergonomia Synapx (E1–E3)

- **Workers no `SynapxController` (`onEver`/`onOnce`)**: nomear `onEver`/`onOnce`
  (alinhado a `onDispose`/`onClose`) evita colisão com o gate mecânico
  `legacy_names_test.dart`, que proíbe chamadas top-level não qualificadas
  `ever(...)` e `once(...)` em `lib/` e `test/`.
- **`SynapxReactivePage<T>` mantém `Expando` do `SynapxPage<T>`**: `build` delega
  a `SynapxScope(builder: buildReactive)`, e `_SynapxPageElement.update`
  reassocia o novo widget ao `BuildContext` antes de `SynapxScope` reconstruir.
- **`SynapxModuleScope` sem aliases paralelos (E3 §7.2)**: optou-se por manter
  apenas `registerInstance`/`registerLazySingleton`/`registerFactory` em vez de
  duplicar com `instance`/`lazy`/`factory`, preservando API única e legível em
  cascata no `example/`.
- **`SynapxApp.appBuilder`**: `assert((builder == null) != (appBuilder == null))`
  garante exclusividade sem quebrar `builder` existente; `example/` eliminou
  placeholders `(_, __, observer)` e reduziu o boilerplate de controllers de
  `14` para `0` ocorrências (`trackObservable`/`trackToken`/`batch`/`isDisposed`).
## 2026-11-19 — Consolidação semântica de `lib/widgets/`

- **Fronteira preservada (`widgets` × `synapx`)**: `lib/widgets/` permanece
  100% independente de `lib/synapx/` (`widgets` → `core` apenas).
- **Fusão por função real, não só por arquivo**:
  - `SearchPanel` absorveu `DebouncedSearch`; `SectionTitle` absorveu `TitleBar`
    e `TitlePanel.text` absorveu `TitlePage`; `DetailItem` (com `direction` e
    `DetailItem.keyValue`) unificou `DetailLine`, `DetailColumn` e
    `KeyValueText`.
  - Removidos wrappers sem valor próprio: `NoRecordMessage` (`=> Text(...)`) e
    `ModalDialog` (repasse 1:1 de `AlertDialog` coberto por `DialogThemeData`).
- **`ModalHeader` + `ModalSheet` em `modals.dart`**: `TitleModal` tinha nome
  ambíguo e quebrava sob altura ilimitada (`BoxConstraints(minHeight: infinity)`);
  separar em `ModalHeader` + `ModalSheet` (com guarda `constraints.maxHeight.isFinite`)
  e renomear `dialogs.dart` → `modals.dart` (enquanto `Alert` em `alert.dart`
  permanece separado por ser `SnackBar`, não diálogo) alinhou nome e função.
