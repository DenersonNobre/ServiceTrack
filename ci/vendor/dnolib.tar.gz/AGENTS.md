# AGENTS.md — dnolib

Biblioteca base Flutter/Dart agnóstica de domínio. Pacote único `dnolib`, docs
em pt-BR (README, CHECKPOINT, LEARNINGS). Git desde 2026-10-02: fluxo `develop`
(trabalho) → `main` (releases); commitar em `develop` e só migrar para `main`
quando o ciclo fechar verde. Remote `origin` = `http://gitea.lan/DartFlutter/DNOLib.git`
— push somente com pedido explícito do mantenedor; tag anotada `vX.Y.Z`
publicada a partir de `main`. O histórico legado está em `A:\Projetos\flutter\.dnolib`.

## Comandos (raiz do repo; SDK via Puro — ver AGENTS.md do workspace)

```bash
puro flutter test                                        # suíte completa (baseline evolui; conferir saída)
puro flutter test test/core/money_test.dart              # arquivo único
puro flutter analyze --fatal-infos lib test              # análise (falha em info)
puro dart format --output=none --set-exit-if-changed lib test   # formatação (falha em drift)
```

Sem CI, codegen, migrations de ferramenta nem task runner. Rodar analyze,
test e format antes de concluir qualquer mudança; os três precisam ficar
verdes.

## Arquitetura — o que se erra sem isto

- `lib/dnolib.dart` é a **única facade** e exporta todos os módulos
  (`core`, `rest`, `sqlite`, `widgets`, `brlib`). O consumidor corta com
  `show`/`hide` no import — **não** criar módulo "opcional" fora da facade.
- Módulo de arquivo único não ganha diretório próprio: fundir no módulo de
  natureza equivalente (ex.: `Money` → `core/models/money.dart`). Não criar
  `lib/utils/` — `core/helpers|logging|models|patterns|validator|services` já
  é o bucket genérico.
- Invariante **INV-AGNOSTICIDADE**: `lib/core/**` não pode conter
  `import`/`export` de `package:flutter` — enforcement mecânico em
  `test/core/core_is_agnostic_test.dart`. Código Flutter-dependente vai para
  `widgets`; `brlib` fica fora do core por causa de `input_formatters/`.
- Não existe módulo `presentation`: `Command`/`Observable` são padrões puros
  em `core`; adapter Flutter (`ObservableAdapter`, builders) fica em `widgets`.
- Ao exportar símbolo novo pela facade, adicionar asserção em
  `test/facade_test.dart` (instancia 1 tipo por módulo; export esquecido fica
  vermelho, não silêncio de compilação).
- Não portar direto do legado: `Environment`, `Auth`, `IRepository`/
  `BaseRepository`, `RestProvider`, `RestResult`, `Kripton`.

## Convenções

- Identificador público em inglês (`isValidEmail`, `Money`, `readAll`);
  comentários, docstrings e descrições de teste em pt-BR.
- `analysis_options.yaml` inclui `package:flutter_lints/flutter.yaml` — o gate
  é `puro flutter analyze --fatal-infos lib test` e **falha em info** (estilo
  é blocking desde 2026-10-02). Ao adicionar lint novo, corrigir o repo no
  mesmo commit.
- Testes de sqlite rodam no desktop via `sqflite_common_ffi` (sem device);
  testes de widget exigem `flutter test` (não `dart test`).
- Vírgula final sempre que a lista quebrar linha: `formatter: trailing_commas:
  preserve` + lint `require_trailing_commas` (norma anti-linha-longa; ver
  LEARNINGS 2026-11-19). Rodar `puro dart format` (modo escrita) antes de
  commitar, não só o check.
- O projeto `./example` é o ambiente oficial para POCs e validação viva de
  novos recursos da `dnolib` (consumindo exclusivamente pela facade).

## Docs

- `docs/decisao-001.md` — **decisão de consumo versionado**: git+tag por app,
  versionamento com melos single-package, regras duras e plano de adoção (F0–F4).
- `README.md` — estrutura, módulos e regras de consumo da facade.
- `CHECKPOINT.md` — continuidade entre sessões (ponteiro, ≤60 linhas; não espelha estado).
- `LEARNINGS.md` — aprendizados do repo; consultar antes de refatorar
  (inclui lock de diretório do analysis server e divergência doc×código).
