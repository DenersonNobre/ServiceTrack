# CHECKPOINT — dnolib

## Contexto
- Biblioteca base Flutter/Dart agnóstica de domínio (`dnolib`, `v0.7.0`, workspace com `example/`).
- Branch de trabalho: `develop` (releases em `main`, tags `vX.Y.Z` a partir de `main`). Remote: `http://gitea.lan/DartFlutter/DNOLib.git` (push só com pedido explícito).
- Módulo Synapx (`0.1a`–`0.2`) integrado em `develop`; `example/` é POC/canônica consumindo a facade (`package:dnolib/dnolib.dart`). E0 (identidade canônica `Synapx*`) concluído em `develop`.

## Estado real (verificar por evidência)
- Ponto de entrada da sessão: `git log -1 --oneline` e `git status -sb` (confirmar árvore limpa e HEAD vigente).
- Gates do projeto (antes de concluir mudança): `puro flutter analyze --fatal-infos lib test`, `puro flutter test`, `puro dart format --output=none --set-exit-if-changed lib test` (ver `AGENTS.md`).
- Suite/baseline evolui com o histórico — não duplicar contagens aqui; fonte: saída dos comandos acima e registros em `LEARNINGS.md`.

## Fontes de verdade (ponteiros)
- Governança/convencões/comandos: `AGENTS.md`
- Consumo, módulos e API pública: `README.md`
- Decisão de consumo versionado (git+tag, melos, F0–F4): `docs/decisao-001.md`
- Synapx (conceito/considerações/análise/plano): `docs/synapx/`
- Diário técnico e aprendizados: `LEARNINGS.md`
- Histórico e releases: `git log`, `CHANGELOG.md`, tags

## Próximo passo / backlog
- Sem UC/fatia em andamento registrada neste checkpoint.
- Antes de retomar desenvolvimento: validar vigência de pendências históricas no `git log`/`LEARNINGS.md`/`docs/` (evitar reabrir item já resolvido em histórico) e, se houver trabalho novo, registrar o recorte/slice aplicável.

## Travas vivas
- Push remoto e publicação de tag/release: somente com pedido explícito do mantenedor.
- Manter invariantes do repo: core sem `package:flutter`, export novo pela facade + asserção em teste, docs/LEARNINGS no mesmo commit da mudança observável (conforme `AGENTS.md`).
