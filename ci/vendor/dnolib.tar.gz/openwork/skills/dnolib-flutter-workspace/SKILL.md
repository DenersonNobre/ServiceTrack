---
name: dnolib-flutter-workspace-xdt93e5d
description: 'Use for the DNOLib Flutter/Dart library workspace at A:\Projetos\flutter\.dnolib: orientation, implementation, verification, documentation, and Git workflow. This is the current Flutter package, not the legacy DNOLib Delphi/Lazarus project or its build procedures.'
---

# DNOLib Flutter/Dart workspace

Apply this skill only to the current DNOLib Flutter/Dart package. The legacy DNOLib Delphi/Lazarus project is a separate codebase with separate tools and procedures. Do not apply Delphi package, DUnitX, Lazarus, or Delphi release instructions here. If the user means the legacy project, clarify the target before acting.

## Source of truth and orientation

- Treat the repository's `AGENTS.md` as the canonical project-specific instructions. Read it before implementation.
- Read `HANDOFF.md` for current branch, release, pending work, and session continuity. Consult `LEARNINGS.md` before refactoring or when relevant.
- Respect the current Git state before editing: inspect branch and staged, unstaged, and untracked changes; preserve user work and stage only files belonging to the requested change.
- This workspace is the Flutter/Dart DNOLib package. It uses Puro; invoke Flutter and Dart commands through `puro`.
- Do not claim local workspace access merely because this Skill is available in OpenWork. Use a connected/local OpenCode workspace only when it is actually available; otherwise provide instructions or ask the user to run the local step.

## Architecture and conventions

- `lib/dnolib.dart` is the only public facade and exports all modules. Add facade assertions in `test/facade_test.dart` for newly exported symbols.
- Keep `lib/core/**` free of Flutter imports and exports; `test/core/core_is_agnostic_test.dart` enforces this invariant.
- Put Flutter-dependent adapters in `widgets`; keep Brazilian-specific functionality in `brlib`.
- Do not create a standalone module for a single file when it belongs in an existing module. Do not introduce `lib/utils/` or a `presentation` module.
- Do not port legacy Delphi concepts such as `Environment`, `Auth`, `IRepository`/`BaseRepository`, `RestProvider`, `RestResult`, or Kripton directly.
- Public identifiers are English. Comments, docstrings, and test descriptions are pt-BR.
- Follow the repository's Result/failure conventions, feature cohesion, dependency inversion, validation, and existing tests.

## Change procedure

1. Restate the requested outcome and acceptance criteria. Identify the smallest coherent feature slice and affected module.
2. Inspect existing implementation and tests before proposing changes. For behavior changes, add or update a focused test that expresses the expected behavior before implementation when feasible.
3. Implement only the requested scope. Keep code, tests, and relevant documentation together.
4. If adding a public API, update the module barrel, facade, and facade test. Preserve core agnosticism.
5. Update `HANDOFF.md` for meaningful backlog/session state changes and `LEARNINGS.md` for reusable project findings.
6. Before finishing a code change, run all three repository gates from the repo root:
   - `puro flutter analyze --fatal-infos lib test`
   - `puro flutter test`
   - `puro dart format --output=none --set-exit-if-changed lib test`
   Report actual outcomes; do not claim green gates without running them.
7. Review `git status`, the complete relevant diff, and recent history before committing. Commit only when the requested unit is complete and gates pass, using one conventional, atomic commit on `develop`. Do not push unless the user explicitly asks.
8. When no local checkout/tool access is available, do not simulate verification, edits, commits, or release actions; give the user the concrete local command or request the needed workspace connection.

## Release boundaries

- Normal development happens on `develop`; releases are promoted to `main` only when the release cycle is ready and green.
- Do not push, publish, or create remote releases without an explicit user request.
- Follow `docs/decisao-001.md` for package consumption and versioning. Treat release version calculations as requiring review against the project's compatibility policy.
- Keep this Flutter/Dart release process separate from the legacy Delphi/Lazarus DNOLib process.
