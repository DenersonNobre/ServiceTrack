function useTheme(hostContext) {
  const variables = hostContext?.styles?.variables;
  const scheme = hostContext?.theme ?? "light dark";
  return React.useMemo(() => ({ ...(variables ?? {}), colorScheme: scheme }), [variables, scheme]);
}

const CHECKS = [
  { id: "test", command: "puro flutter test", label: "Testes", description: "Suíte completa de testes do repositorio (baseline 302 testes; verificado em 2026-10-18)." },
  { id: "analyze", command: "puro flutter analyze --fatal-infos lib test", label: "Analise estatica", description: "Analise estatica com --fatal-infos; falha em info." },
  { id: "format", command: "puro dart format --output=none --set-exit-if-changed lib test", label: "Formatacao", description: "Formatacao com --set-exit-if-changed; falha em drift." },
];

function statusText(status) {
  return status === "pass" ? "Verde" : status === "fail" ? "Falhou" : "Nao verificado";
}

function statusTone(status) {
  return status === "pass" ? "ok" : status === "fail" ? "danger" : "muted";
}

function nowIso() {
  return new Date().toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
}

export default function App({ input, hostContext }) {
  const theme = useTheme(hostContext);
  const [checks, setChecks] = React.useState(() => CHECKS.map(c => ({ id: c.id, status: "unset" })));
  const [message, setMessage] = React.useState(null);

  const passes = checks.filter(c => c.status === "pass").length;
  const fails = checks.filter(c => c.status === "fail").length;
  const total = checks.length;
  const allPass = passes === total && total > 0;

  function setStatus(id, status) {
    setChecks(prev => prev.map(c => c.id === id ? { ...c, status, updatedAt: nowIso() } : c));
    setMessage(null);
  }

  function resetAll() {
    setChecks(CHECKS.map(c => ({ id: c.id, status: "unset" })));
    setMessage(null);
  }

  return (
    <main className="app" style={theme}>
      <div className="summary">
        <span className="count">{passes} de {total} verificacoes verdes</span>
        {fails > 0 ? <span className="count warn">{fails} falhou(am)</span> : null}
        {(passes > 0 || fails > 0) ? <span className="meta">atualizado {nowIso()}</span> : null}
      </div>

      <p className="notice">Checklist manual: execute os comandos no workspace e marque cada resultado conforme a saída. Este App não executa nem confirma os comandos.</p>

      {message ? <p className="notice" data-tone="danger" role="alert">{message}</p> : null}

      <div className="cards">
        {CHECKS.map((check) => {
          const item = checks.find(c => c.id === check.id);
          const status = item ? item.status : "unset";
          return (
            <article key={check.id} className="card">
              <div className="card-head">
                <span className="command">{check.command}</span>
                <span className={'badge tone-' + statusTone(status)}>{statusText(status)}</span>
              </div>
              <p className="desc">{check.description}</p>
              {(status !== "unset" && item && item.updatedAt) ? (
                <p className="meta">verificado {item.updatedAt}</p>
              ) : null}
              <div className="controls">
                <button type="button" onClick={() => setStatus(check.id, "pass")} disabled={status === "pass"}>Marcar verde</button>
                <button type="button" onClick={() => setStatus(check.id, "fail")} disabled={status === "fail"}>Marcar falhou</button>
                <button type="button" className="quiet" onClick={() => setStatus(check.id, "unset")} disabled={status === "unset"}>Limpar</button>
              </div>
            </article>
          );
        })}
      </div>

      <div className="footer">
        <button type="button" className="quiet" onClick={resetAll} disabled={(passes === 0 && fails === 0)}>Resetar tudo</button>
        {allPass ? <p className="notice tone-ok">Os três itens foram marcados verdes. Confirme as saídas reais antes de commitar.</p> : null}
        {!allPass && (passes > 0 || fails > 0) ? <p className="notice">Nem todas as verificacoes estao verdes. Revise as falhas antes de commitar.</p> : null}
      </div>
    </main>
  );
}
