# Apps OpenWork — DNOLib Flutter/Dart

## `dnolib: status da suíte de verificação`

- **App ID:** `cob_01m57hh6myehcrvqp6pcn7yw7d`
- **Plugin ID:** `plg_01m57hh6fbe25b4nwqx5hf4j16`
- **Revisão atual:** `cov_01m586g6ybeyfvaryqn53mhexb`
- **Estado:** objeto Cloud existente e descobrível para abrir no OpenWork.
- **Finalidade:** checklist visual para os comandos Flutter de teste, analyze e
  format.
- **Espelho local do código:** `dnolib-verification-checklist/App.jsx` e
  `dnolib-verification-checklist/App.css`.

### Limites observados

O App não tem ferramentas vinculadas (`tools: []`) e não executa comandos. Ele
apenas permite marcar cada verificação como verde ou falha na interface. Marcar
verde não prova que o comando foi executado nem que passou; use a saída real dos
comandos como evidência.

O texto da revisão consultada e o `AGENTS.md` agora registram baseline de 302
testes, confirmado por `puro flutter test` em 2026-10-18. O `HANDOFF.md` mantém
295 como resultado histórico da sessão de 2026-10-14; não é a contagem atual.

Os arquivos locais são uma cópia da revisão Cloud consultada. Para alterar o
App, atualize os arquivos locais e publique uma nova revisão no OpenWork Cloud;
depois registre aqui a nova revisão.
