# Artefatos OpenWork — DNOLib Flutter/Dart

Esta pasta reúne o catálogo e as cópias versionadas dos artefatos do OpenWork
relacionados ao workspace DNOLib Flutter/Dart. Ela fica dentro do checkout para
aparecer no OW Desktop e manter referências no Git.

## Limite entre workspace e OpenWork Cloud

- O workspace **DNOLib (Dart/Flutter)** no OW Desktop aponta para este projeto.
- Arquivos desta pasta pertencem ao repositório e aparecem no workspace local.
- Skills, Workflows e Automations criados no OpenWork Cloud são objetos da conta;
  não são arquivos dentro do checkout. A Skill abaixo também tem uma cópia de
  referência neste repositório.
- O `AGENTS.md` da raiz continua sendo a fonte canônica para regras do projeto.
  Ao mudar o fluxo da Skill, atualizar a cópia local e publicar uma nova versão
  Cloud da Skill.
- `catalog.json` registra os IDs dos objetos Cloud e o resultado da última
  descoberta. IDs e revisões Cloud são referências, não arquivos controlados
  pelo Git.

## Inventário

| Tipo | Nome | Local/ID | Estado |
|---|---|---|---|
| Skill | `dnolib-flutter-workspace` (`dnolib-flutter-workspace-xdt93e5d` no catálogo Cloud) | `skills/dnolib-flutter-workspace/SKILL.md` | Cópia local de referência; publicada no OpenWork Cloud |
| Skill Cloud | `dnolib-flutter-workspace` | Plugin `plg_01m585sb04e6kv9wjsg6paxdt9`, Skill `cob_01m585sb1pehstw0dzz4nv3e5d` | Privada, pronta para uso |
| App Cloud | `dnolib: status da suíte de verificação` | App `cob_01m57hh6myehcrvqp6pcn7yw7d`, Plugin `plg_01m57hh6fbe25b4nwqx5hf4j16` | Checklist manual; código espelhado em `apps/dnolib-verification-checklist/` |
| Skill de outro projeto | `dnolib-build-test` | Plugin `DNOLib Dev` | Delphi; não pertence a este workspace Flutter |
| Workflow | — | — | Nenhum criado |
| Automation | — | — | Nenhuma criada |

Use Workflows apenas quando um procedimento recorrente estiver estável. Crie
Automations somente se houver uma rotina que precise de agendamento explícito.

## Estrutura

- `skills/`: cópias locais das Skills Cloud deste workspace.
- `apps/`: notas e limites dos Apps Cloud associados ao projeto.
- `catalog.json`: inventário legível por ferramenta dos objetos locais e Cloud.
